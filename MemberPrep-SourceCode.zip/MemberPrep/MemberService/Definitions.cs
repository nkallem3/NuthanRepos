﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

namespace MemberService
{
	[DataContract]
	public class SearchQuery
	{
		private static DataContractJsonSerializer mySerializer = new DataContractJsonSerializer(typeof(SearchQuery));

		public static string Serialize(SearchQuery graph)
		{
			using (MemoryStream myStream = new MemoryStream())
			{
				mySerializer.WriteObject(myStream, graph);
				myStream.Seek(0, SeekOrigin.Begin);
				using (StreamReader myReader = new StreamReader(myStream))
				{
					return myReader.ReadToEnd();
				}
			}
		}

		public static SearchQuery Deserialize(string jsondata)
		{
			using (MemoryStream myStream = new MemoryStream(Encoding.Unicode.GetBytes(jsondata)))
			{
				return mySerializer.ReadObject(myStream) as SearchQuery;
			}
		}

		[DataMember(Order = 0)]
		public string NameFirst;
		[DataMember(Order = 1)]
		public string NameMiddle;
		[DataMember(Order = 2)]
		public string NameLast;
		[DataMember(Order = 3)]
		public string Gender;
		[DataMember(Order = 4)]
		public string DOB;
		[DataMember(Order = 5)]
		public string HICN;
		[DataMember(Order = 6)]
		public string SSN;
		[DataMember(Order = 7)]
		public string MedicaidID;
		[DataMember(Order = 8)]
		public string MemberID;
		[DataMember(Order = 9)]
		public string MainNumber;
		[DataMember(Order = 10)]
		public string AlternateNumber;
		[DataMember(Order = 11)]
		public DataBureauAddress Address;
		[DataMember(Order = 12)]
		public string MBI;
		[DataMember(Order = 13)]
		public int SetID;
	}

	[DataContract]
	public class DataBureauAddress
	{
		public DataBureauAddress()
		{
			Address1 = string.Empty;
			Address2 = string.Empty;
			Suite = string.Empty;
			City = string.Empty;
			State = string.Empty;
			ZIP5 = string.Empty;
			Plus4 = string.Empty;
			County = string.Empty;
			CountyFIPSCode = string.Empty;
			ZIP11 = string.Empty;
			Latitude = string.Empty;
			Longitude = string.Empty;
		}
		[DataMember(Order = 0)]
		public string Address1;
		[DataMember(Order = 1)]
		public string Address2;
		[DataMember(Order = 2)]
		public string Suite;
		[DataMember(Order = 3)]
		public string City;
		[DataMember(Order = 4)]
		public string State;
		[DataMember(Order = 5)]
		public string ZIP5;
		[DataMember(Order = 6)]
		public string Plus4;
		[DataMember(Order = 7)]
		public string County;
		[DataMember(Order = 8)]
		public string CountyFIPSCode;
		[DataMember(Order = 9)]
		public string ZIP11;
		[DataMember(Order = 10)]
		public string Latitude;
		[DataMember(Order = 11)]
		public string Longitude;
		[DataMember(Order = 12)]
		public string Message;
	}

	[DataContract]
	public class DataBureauPhoneNumber
	{
		public DataBureauPhoneNumber()
		{
			Number = string.Empty;
			Extension = string.Empty;
		}
		[DataMember(Order = 0)]
		public string Number;
		[DataMember(Order = 1)]
		public string Extension;
	}

	[DataContract]
	public class MemberTruth
	{
		public MemberTruth()
		{
			DataBureauID = -1;
			LastRefresh = string.Empty;
			NameFirst = string.Empty;
			NameMiddle = string.Empty;
			NameLast = string.Empty;
			Gender = string.Empty;
			DOB = string.Empty;
			SSN = string.Empty;
			HICN = string.Empty;
			MBI = string.Empty;
			MedicaidID = string.Empty;
			ticket = Guid.Empty;
			ExPayload = string.Empty;
		}
		[DataMember(Order = 0)]
		public long DataBureauID;
		[DataMember(Order = 1)]
		public string LastRefresh;
		[DataMember(Order = 2)]
		public string NameFirst;
		[DataMember(Order = 3)]
		public string NameMiddle;
		[DataMember(Order = 4)]
		public string NameLast;
		[DataMember(Order = 5)]
		public string Gender;
		[DataMember(Order = 6)]
		public string DOB;
		[DataMember(Order = 7)]
		public string SSN;
		[DataMember(Order = 8)]
		public string HICN;
		[DataMember(Order = 9)]
		public string MedicaidID;
		[DataMember(Order = 10)]
		public DataBureauPhoneNumber MainNumber;
		[DataMember(Order = 11)]
		public DataBureauPhoneNumber AlternateNumber;
		[DataMember(Order = 12)]
		public DataBureauAddress Address;
		[DataMember(Order = 13)]
		public Guid ticket;
		[DataMember(Order = 14)]
		public string ExPayload;
		[DataMember(Order = 15)]
		public string MBI;
	}

	[DataContract]
	public class SearchResult
	{
		[DataMember(Order = 0)]
		public bool AutomaticMatch;
		[DataMember(Order = 1)]
		public decimal adjustedScore;
		[DataMember(Order = 2)]
		public MemberTruth MemberInformation;
	}

	[DataContract]
	public class SystemSynchronizationStatistics
	{
		[DataMember(Order = 0)]
		public string LastClientRequestTimestamp;
		[DataMember(Order = 1)]
		public string NextDataBureauID;
	}

}
