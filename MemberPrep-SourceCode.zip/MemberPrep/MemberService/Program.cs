﻿using System;
using System.Configuration.Install;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.ServiceModel;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

using Logging;
using MemberProcessing;

namespace MemberService
{
	public class Program
	{
		public static string ServiceName = "MemberService";
		public static bool RunningAsApp = false;
		public static string EndpointForTestHTML = "";

		public static void Main(string[] args)
		{
			// Handle the install/uninstall logic
			if (args.Count() > 0)
			{
				if (args[0].ToUpper() == "-INSTALL")
				{
					if (ServiceController.GetServices().Any(s => s.ServiceName == ServiceName))
						MessageBox.Show("Service is already installed", ServiceName);
					else
						ManagedInstallerClass.InstallHelper(new string[] { Assembly.GetExecutingAssembly().Location });
					return;
				}
				else if (args[0].ToUpper() == "-UNINSTALL")
				{
					if (ServiceController.GetServices().Any(s => s.ServiceName == ServiceName) == false)
						MessageBox.Show("Service is not installed");
					else
						ManagedInstallerClass.InstallHelper(new string[] { "/u", Assembly.GetExecutingAssembly().Location });
					return;
				}
			}

			MemberService program = new MemberService();
			RunningAsApp = true;

			try
			{
				ProcessArgs.Initialize(args);

				// Check if we're running as a service or an application
				if (ServiceController.GetServices().Any(s => s.ServiceName == ServiceName))
				{
					ServiceController svcControl = new ServiceController(ServiceName);
					if (svcControl != null && (svcControl.Status == ServiceControllerStatus.StartPending))
						RunningAsApp = false;
				}

				if (RunningAsApp)
				{
					program.RunAsApplication(args);
				}
				else
				{
					ServiceBase.Run(program);
				}
			}
			catch (Exception)
			{
				if (RunningAsApp)
				{
					Console.WriteLine("Press any key to exit...");
					Console.ReadKey();
				}
			}
			finally
			{
				program.Stop();
			}
		}
	}

	[ServiceContract]
	[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
	public class MemberService : ServiceBase
	{
		private ServiceHost WCFService = null;
		private Thread BackgroundThread = null;
		private bool StopRequested = false;

		public MemberService()
		{
			ServiceName = Program.ServiceName;
		}

		internal void RunAsApplication(string[] args)
		{
			OnStart(args);

			while (true)
			{
				string Line = Console.ReadLine();
				if (string.IsNullOrEmpty(Line))
					break;
			}

			OnStop();
		}

		protected override void OnStart(string[] args)
		{
			// disable custom errors, instead marshal actual exceptions
			System.Runtime.Remoting.RemotingConfiguration.CustomErrorsMode = System.Runtime.Remoting.CustomErrorsModes.Off;

			WCFService = new ServiceHost(typeof(WCFMemberService));
			try
			{
				Logger.LoggerInit("", Program.RunningAsApp);
				WCFService.Open();
				string exe = Path.GetFullPath(Assembly.GetEntryAssembly().Location);
				Logger.LogString(string.Format("###############  MemberService started  ###############"));
				Logger.LogString(string.Format("Executable = {0} ({1})", exe, File.GetLastWriteTime(exe).ToShortDateString()));
				Logger.LogString(string.Format("Port = {0} ({1})", WCFService.BaseAddresses[0].AbsoluteUri, Program.RunningAsApp ? "Application" : "Service"));
				Program.EndpointForTestHTML = System.Configuration.ConfigurationManager.AppSettings["EndpointForTestHTML"];
				if (string.IsNullOrEmpty(Program.EndpointForTestHTML))
					Program.EndpointForTestHTML = WCFService.BaseAddresses[0].AbsoluteUri;

				Thread BackgroundThread = new Thread(x => BackgroundProcessing());
				BackgroundThread.Name = "MemberService Background Thread";
				BackgroundThread.IsBackground = true;
				BackgroundThread.Start();
			}
			catch (Exception ex)
			{
				WCFService = null;
				Logger.LogException("Service initialization failed", ex);
				throw;
			}
		}

		protected override void OnStop()
		{
			StopRequested = true;
			if (WCFService != null)
			{
				Logger.LogString("Service shutting down", LogLevel.Info);
				WCFService.Close();
				WCFService = null;
			}
			if (BackgroundThread != null)
			{
				BackgroundThread.Abort();
				BackgroundThread = null;
			}
			Logger.LoggerClose();
		}

		private void BackgroundProcessing()
		{
			if (string.IsNullOrEmpty(ProcessArgs.Config.MelissaUpdaterStartTime))
				return;

			DateTime NextUpdateTime = DateTime.Now;
			TimeSpan UpdateTime;
			if (TimeSpan.TryParse(ProcessArgs.Config.MelissaUpdaterStartTime, out UpdateTime) == false)
				UpdateTime = new TimeSpan(0, 0, 0);
			NextUpdateTime = DateTime.Now.Date + UpdateTime;

			while (!StopRequested)
			{
				if (DateTime.Now >= NextUpdateTime)
				{
					NextUpdateTime = DateTime.Now.Date.AddDays(1) + UpdateTime;
					MelissaDataUpdater(ProcessArgs.Config.MelissaUpdaterDuration);
				}

				Thread.Sleep(1000);
			}
		}

		private static void MelissaDataUpdater(int MaxRunMinutes)
		{
			// Update the address/phone historical data with the latest Melissa Data
			// Only process if the timestamp for Melissa Data is newer than the file
			// Time limit the total processing time so the update doesn't interfere with daily processing
			DateTime dtStart = DateTime.Now;
			DateTime dtMelissa = new FileInfo(Path.Combine(ProcessArgs.MelissaDataPath, "mdAddr.dat")).LastWriteTime;
			foreach (string folder in Directory.GetDirectories(ProcessArgs.Config.HistoryFolder, "*.*"))
			{
				foreach (string file in Directory.GetFiles(folder, "DS*-PhoneData.txt"))
				{
					if (ProcessArgs.Config.ForceUpdate || dtMelissa > new FileInfo(file).LastWriteTime)
					{
						HistoricalData History = new HistoricalData();
						History.UpdateAllPhoneHistory(file);
					}
				}
				foreach (string file in Directory.GetFiles(folder, "DS*-AddressData.txt"))
				{
					if (ProcessArgs.Config.ForceUpdate || dtMelissa > new FileInfo(file).LastWriteTime)
					{
						HistoricalData History = new HistoricalData();
						History.UpdateAllAddressHistory(file);
					}
				}
				if (MaxRunMinutes > 0 && DateTime.Now > dtStart.AddMinutes(MaxRunMinutes))
					break;
			}
		}
	}

	// Installer for service
	[System.ComponentModel.RunInstaller(true)]
	public class PersonManagerServiceInstaller : Installer
	{
		public PersonManagerServiceInstaller()
		{
			ServiceProcessInstaller serviceProcessInstaller = new ServiceProcessInstaller();
			ServiceInstaller serviceInstaller = new ServiceInstaller();

			// service account will need to be changed after installation
			serviceProcessInstaller.Account = ServiceAccount.LocalService;
			serviceProcessInstaller.Username = null;
			serviceProcessInstaller.Password = null;

			MemberService myService = new MemberService();
			serviceInstaller.DisplayName = myService.ServiceName;
			serviceInstaller.StartType = ServiceStartMode.Manual;

			serviceInstaller.ServiceName = "MemberService";
			serviceInstaller.Description = "MemberService";

			this.Installers.Add(serviceProcessInstaller);
			this.Installers.Add(serviceInstaller);
		}
	}
}
