﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using MemberProcessing;
using ContactDataLib;

namespace MemberService
{
	[ServiceBehavior(InstanceContextMode=InstanceContextMode.Single, ConcurrencyMode=ConcurrencyMode.Multiple)]
    [ServiceContract]
    public class WCFMemberService
    {
		private long NextDataBureauID = 1;
		private string NextDataBureauIDFileName = null;
		private Guid MMSReferral = new Guid("0041E8CF-E7E9-41B7-A267-4CBEF8B516D7");
		private DateTime TimeOfLastRequest = DateTime.Now;

		public WCFMemberService()
		{
			if (!string.IsNullOrEmpty(NextDataBureauIDFileName) && File.Exists(NextDataBureauIDFileName))
			{
				string NextID = File.ReadAllText(NextDataBureauIDFileName);
				long.TryParse(NextID.Trim(), out NextDataBureauID);
			}
		}

		internal long GetNextDataBureauID(long Increment = 1)
		{
			long NextID;
			lock (this)
			{
				NextID = NextDataBureauID;
				NextDataBureauID = NextDataBureauID + Increment;
				if (!string.IsNullOrEmpty(NextDataBureauIDFileName))
					File.WriteAllText(NextDataBureauIDFileName, NextDataBureauID.ToString());
			}
			return NextID;
		}

		[WebGet(UriTemplate = "test/address")]
		public Stream GetAddressForm()
		{
			string HTML = File.ReadAllText(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "TestAddress.html"));
			HTML = HTML.Replace("$$EndpointForTestHTML$$", Program.EndpointForTestHTML);
			WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
			return new MemoryStream(Encoding.UTF8.GetBytes(HTML ?? ""));
		}

		[WebGet(UriTemplate = "test/searchmms")]
		public Stream GetSearchMMSForm()
		{
			string HTML = File.ReadAllText(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "TestSearchMMS.html"));
			HTML = HTML.Replace("$$EndpointForTestHTML$$", Program.EndpointForTestHTML);
			WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
			return new MemoryStream(Encoding.UTF8.GetBytes(HTML ?? ""));
		}

		[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "system")]
		public SystemSynchronizationStatistics GetSystemStats()
		{
			SystemSynchronizationStatistics myRes = new SystemSynchronizationStatistics();
			myRes.LastClientRequestTimestamp = TimeOfLastRequest.ToString("yyyy-MM-dd hh:mm:ss");
			myRes.NextDataBureauID = NextDataBureauID.ToString();
			return myRes;
		}

		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json,
			BodyStyle = WebMessageBodyStyle.WrappedRequest, UriTemplate = "address")]
		public DataBureauAddress NormalizeAddress(DataBureauAddress InputAddress)
		{
			DataBureauAddress Result = new DataBureauAddress();
			CDAddress AddressIn = new CDAddress();
			CDAddress AddressOut = new CDAddress();

			Result.Message = string.Empty;
			TimeOfLastRequest = DateTime.Now;
			System.Diagnostics.Stopwatch myWatch = new System.Diagnostics.Stopwatch();
			myWatch.Reset();
			myWatch.Start();

			try
			{
				AddressIn.Line1 = InputAddress.Address1;
				AddressIn.Line2 = InputAddress.Address2;
				AddressIn.Suite = InputAddress.Suite;
				AddressIn.City = InputAddress.City;
				AddressIn.State = InputAddress.State;
				AddressIn.Zip = InputAddress.ZIP5;

				ProcessArgs.MelissaData.AddressVerify(AddressIn, out AddressOut);

				Result.Address1 = AddressOut.Line1;
				Result.Address2 = AddressOut.Line2;
				Result.Suite = AddressOut.Suite;
				Result.City = AddressOut.City;
				Result.State = AddressOut.State;
				Result.ZIP5 = AddressOut.Zip5;
				Result.Plus4 = AddressOut.Plus4;
				Result.County = AddressOut.County;
				Result.CountyFIPSCode = AddressOut.FIPSCode;
				Result.ZIP11 = AddressOut.Zip11;
				Result.Latitude = AddressOut.Latitude;
				Result.Longitude = AddressOut.Longitude;
				Result.Message += "normalization time: " + myWatch.Elapsed.TotalSeconds.ToString("0.000000 seconds");
			}
			catch
			{
				Result.Message += "Address check failed: " + AddressOut.Notes;
			}
			return Result;
		}

		[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json,
			BodyStyle = WebMessageBodyStyle.WrappedRequest, UriTemplate = "personmms")]
		public SearchResult[] SearchMemberMMS(SearchQuery InputQuery)
		{
			List<SearchResult> Result = new List<SearchResult>();
			TimeOfLastRequest = DateTime.Now;
			MemberTruth MemberInfo = new MemberTruth();
			MemberInfo.DataBureauID = GetNextDataBureauID();
			MemberInfo.LastRefresh = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss");
			MemberInfo.NameFirst = InputQuery.NameFirst.Trim();
			MemberInfo.NameMiddle = InputQuery.NameMiddle.Trim();
			MemberInfo.NameLast = InputQuery.NameLast.Trim();
			MemberInfo.Gender = FieldValidator.FormatField(InputQuery.Gender, FieldType.TGender);
			MemberInfo.SSN = FieldValidator.FormatField(InputQuery.SSN, FieldType.TSSN);
			MemberInfo.HICN = FieldValidator.FormatField(InputQuery.HICN, FieldType.THICNumber);
			MemberInfo.MBI = FieldValidator.FormatField(InputQuery.MBI, FieldType.TMBI);
			MemberInfo.MedicaidID = InputQuery.MedicaidID.Trim();
			MemberInfo.MainNumber = new DataBureauPhoneNumber();
			MemberInfo.MainNumber.Number = FieldValidator.FormatField(InputQuery.MainNumber, FieldType.TUSPhoneNumber);
			MemberInfo.AlternateNumber = new DataBureauPhoneNumber();
			MemberInfo.AlternateNumber.Number = FieldValidator.FormatField(InputQuery.AlternateNumber, FieldType.TUSPhoneNumber);
			MemberInfo.Address = InputQuery.Address == null ? new DataBureauAddress() : NormalizeAddress(InputQuery.Address);
			DateTime DOB = DateTime.MinValue;
			if (!string.IsNullOrEmpty(InputQuery.DOB))
			{
				if (!DateTime.TryParseExact(InputQuery.DOB, FieldValidator.DATE_ARRAY, null, System.Globalization.DateTimeStyles.None, out DOB))
				{
					DateTime.TryParse(InputQuery.DOB, out DOB);
				}
			}
			MemberInfo.DOB = DOB == DateTime.MinValue ? "" : DOB.ToString("yyyy-MM-dd");
			MemberInfo.ticket = Guid.Empty;
			MemberInfo.ExPayload = "";

			SearchResult myResult = new SearchResult();
			myResult.adjustedScore = 1M;
			myResult.AutomaticMatch = true;
			myResult.MemberInformation = MemberInfo;
			Result.Add(myResult);

			return Result.ToArray();
		}
	}
}
