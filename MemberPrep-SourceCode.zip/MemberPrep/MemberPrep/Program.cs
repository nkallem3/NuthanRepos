﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

using MemberProcessing;

namespace MemberPrep
{
	public enum ProcessingResult
	{
		Success = 0,
		FailedConnection = -97,
		UserAbort = -98,
		FatalError = -99,
	}

	class Program
    {
        [DllImport("kernel32.dll")]
        private static extern bool AllocConsole();

        [DllImport("kernel32.dll")]
        private static extern bool FreeConsole();

        [STAThread]
        static int Main(string[] args)
        {
			ProcessingResult ResultCode = ProcessingResult.Success;
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			try
			{
				ProcessArgs.Initialize(args);

				if (ProcessArgs.Config.ConsoleExecute)
                {
					ConsoleExecute();
				}
				else
				{
					MainForm Mainform = new MainForm();
					Mainform.ShowDialog();
				}
			}
			catch (Exception ex)
            {
                if (ProcessArgs.Config.ConsoleExecute == false)
                    MessageBox.Show(ex.Message, Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().Location));
                if (ResultCode == ProcessingResult.Success)
					ResultCode = ProcessingResult.FatalError;
            }

            return (int) ResultCode;
        }

		private static void ConsoleExecute()
		{
			// Process a file via a console
			if (string.IsNullOrEmpty(ProcessArgs.Config.InputFile))
				throw new Exception("No input file specified");
			AllocConsole();
			MemberProcess Processor = new MemberProcess();
			LoadInfo Load = new LoadInfo();
			if (ProcessArgs.Config.InputFile.ToUpper().EndsWith(".DEMO"))
				Load.GetLoadInfoForDemoFile(ProcessArgs.Config.InputFile);
			else if (ProcessArgs.Config.InputFile.ToUpper().EndsWith("TOBEENRICHED.TXT"))
				Load.GetLoadInfoForEnrichmentFile(ProcessArgs.Config.InputFile);
			Console.Title = string.Format("MemberPrep - {0}", Path.GetFileName(ProcessArgs.Config.InputFile));
			Processor.ProcessLoad(Load, null);
		}
	}
}
