﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

using Logging;
using MemberProcessing;

namespace MemberPrep
{
	public partial class MainForm : Form
	{
		private ListView ActiveListView = null;
		private ListViewItem SelectedItem = null;
		private List<LoadInfo> AllDemoLoads = new List<LoadInfo>();
		private List<LoadInfo> AllEnrichLoads = new List<LoadInfo>();
		private List<LoadHistory> AllLoadsProcessed = new List<LoadHistory>();
		private Thread MainThread = null;

		public MainForm()
		{
			InitializeComponent();

			MainThread = Thread.CurrentThread;
			ActiveListView = listViewDemos;

			Logger.LoggerInit(null, false, LogLevel.Default);
			Logger.LoggingCallback = OnLogString;
			LogString(string.Format("Input Path = {0}", ProcessArgs.Config.InputFolder));
			LogString(string.Format("Output Path = {0}", ProcessArgs.Config.OutputFolder));
			LogString(string.Format("Archive Path = {0}", ProcessArgs.Config.ArchiveFolder));
			LogString(string.Format("Config Path = {0}", ProcessArgs.Config.ConfigFolder));
			LogString(string.Format("Melissa Path = {0}", ProcessArgs.MelissaDataPath));
		}

		private void DataLoaderForm_Load(object sender, EventArgs e)
		{
			btnRefresh_Click(null, null);
		}

		private void tabControl1_TabIndexChanged(object sender, EventArgs e)
		{
			ActiveListView = tabControl1.SelectedIndex == 0 ? listViewDemos : listViewEnrich;
		}

		private void btnRefresh_Click(object sender, EventArgs e)
		{
			// Read the process log to get a list of all previously processed loads
			if (File.Exists(ProcessArgs.Config.ProcessLogFile))
			{
				string[] Loads = File.ReadAllLines(ProcessArgs.Config.ProcessLogFile);
				foreach (string Line in Loads)
				{
					LoadHistory Load = new LoadHistory();
					int n = -1;
					long count = 0;
					string[] parms = Line.Split(',');
					if (parms.Count() > ++n)
						Load.DemoFile = parms[n];
					if (parms.Count() > ++n)
						DateTime.TryParse(parms[n], out Load.ProcessedDate);
					if (parms.Count() > ++n)
						long.TryParse(parms[n], out count);
					if (parms.Count() > ++n)
						Enum.TryParse<LoadStatus>(parms[n], out Load.Status);
					if (Load.Status == LoadStatus.Complete)
						Load.RecordCount = count;

					if (!string.IsNullOrEmpty(Load.DemoFile))
					{
						// Only keep the most recent
						LoadHistory hist = AllLoadsProcessed.FirstOrDefault(x => string.Compare(Path.GetFileName(x.DemoFile), Path.GetFileName(Load.DemoFile), true) == 0);
						if (hist != null)
							AllLoadsProcessed.Remove(hist);
						AllLoadsProcessed.Add(Load);
					}
				}
			}

			// Get all the DEMO files in the input folder
			foreach (string file in Directory.GetFiles(ProcessArgs.Config.InputFolder, "*.demo"))
			{
				try
				{
					// skip any *.DEMO files that are aborted output demos
					if (AllDemoLoads.FirstOrDefault(x => string.Compare(x.OutputFile, file, true) == 0) != null)
						continue;

					LoadInfo Load = new LoadInfo();
					Load.GetLoadInfoForDemoFile(file);

					LoadInfo ExistingLoad = AllDemoLoads.FirstOrDefault(x => string.Compare(Path.GetFileName(x.InputFile), Path.GetFileName(Load.InputFile), true) == 0);
					if (ExistingLoad == null)
					{
						// If this load is in the load history, update it
						LoadHistory hist = AllLoadsProcessed.FirstOrDefault(x => string.Compare(Path.GetFileName(x.DemoFile), Path.GetFileName(Load.DemoFile), true) == 0);
						if (hist != null)
						{
							Load.RecordCount = hist.RecordCount > Load.RecordCount ? hist.RecordCount : Load.RecordCount;
							Load.ProcessedDate = hist.ProcessedDate > Load.ProcessedDate ? hist.ProcessedDate : Load.ProcessedDate;
						}
						AllDemoLoads.Add(Load);

						ListViewItem lvItem = new ListViewItem();
						lvItem.Tag = Load;
						lvItem.Text = Path.GetFileName(Load.DemoFile);
						listViewDemos.Items.Add(lvItem);
						UpdateListItem(lvItem);
					}
					else
					{
						foreach (ListViewItem lvItem in listViewDemos.Items)
						{
							if (lvItem.Tag == ExistingLoad)
								UpdateListItem(lvItem);
						}
					}
				}
				catch (Exception ex)
				{
					LogString(ex.Message, LogLevel.Error);
				}
			}

			// Get all the enrichment files in the enrich folder
			foreach (string file in Directory.GetFiles(ProcessArgs.Config.EnrichFolder, "*.ToBeEnriched.txt"))
			{
				try
				{
					LoadInfo Load = new LoadInfo();
					Load.GetLoadInfoForEnrichmentFile(file);

					LoadInfo ExistingLoad = AllEnrichLoads.FirstOrDefault(x => string.Compare(Path.GetFileName(x.InputFile), Path.GetFileName(Load.InputFile), true) == 0);
					if (ExistingLoad == null)
					{
						AllEnrichLoads.Add(Load);

						ListViewItem lvItem = new ListViewItem();
						lvItem.Tag = Load;
						lvItem.Text = Path.GetFileName(Load.DemoFile);
						listViewEnrich.Items.Add(lvItem);
						UpdateListItem(lvItem);
					}
				}
				catch (Exception ex)
				{
					LogString(ex.Message, LogLevel.Error);
				}
			}

			UpdateUI(null, null);
		}

		private void UpdateUI(object sender, EventArgs e)
		{
			if (btnProcess.Text == "Aborting")
				btnProcess.Enabled = false;
			else if (btnProcess.Text == "Abort")
				btnProcess.Enabled = true;
			else
			{
				bool Enabled = true;
				foreach (ListViewItem lvItem in ActiveListView.SelectedItems)
				{
					if ((lvItem.Tag as LoadInfo).Status != LoadStatus.Ready)
						Enabled = false;
				}
				btnProcess.Enabled = ActiveListView.SelectedIndices.Count > 0 && Enabled;
			}
		}

		private void UpdateListItem(ListViewItem lvItem)
		{
			LoadInfo load = (LoadInfo) (lvItem.Tag);
			string itemtext1 = string.Format("{0}  ({1})", load.DataSourceID, load.DataSourceName);
			string itemtext2 = load.EffectiveDate.ToString("yyyy-MM-dd");
			string itemtext3 = (load.FileSize / 1024 + 1).ToString("N0");
			string itemtext4 = load.RecordCount == 0 ? "?" : load.RecordCount.ToString("N0");
			string itemtext5 = load.GetStatusString();
			if (lvItem.SubItems.Count <= 1)
			{
				lvItem.SubItems.Add(itemtext1);
				lvItem.SubItems.Add(itemtext2);
				lvItem.SubItems.Add(itemtext3);
				lvItem.SubItems.Add(itemtext4);
				lvItem.SubItems.Add(itemtext5);
			}
			else
			{
				lvItem.SubItems[1].Text = itemtext1;
				lvItem.SubItems[2].Text = itemtext2;
				lvItem.SubItems[3].Text = itemtext3;
				lvItem.SubItems[4].Text = itemtext4;
				lvItem.SubItems[5].Text = itemtext5;
			}
		}

		private void contextMenu_Opening(object sender, System.ComponentModel.CancelEventArgs e)
		{
			LoadInfo Load = ActiveListView.SelectedItems.Count == 1 ? (LoadInfo) ActiveListView.SelectedItems[0].Tag : null;
			ToolStripItem menuitem = null;

			// build the context menu
			contextMenu.Items.Clear();
			contextMenu.ShowImageMargin = false;

			if (Load != null)
			{
				menuitem = null;
				menuitem = contextMenu.Items.Add("View Log File", null, menuItemViewLogFile);
				menuitem.Enabled = File.Exists(Load.LogFile);
				menuitem = contextMenu.Items.Add("Reset to Ready", null, menuItemReset);
				menuitem.Enabled = ActiveListView == listViewDemos && Load != null && Load.Status != LoadStatus.Ready && Load.Status != LoadStatus.Complete;
			}

			e.Cancel = contextMenu.Items.Count == 0;
		}

		private void menuItemViewLogFile(object sender, EventArgs e)
		{
			try
			{
				string viewer = ProcessArgs.Config.LogFileViewer;
				if (string.IsNullOrEmpty(viewer))
					viewer = "Notepad.exe";
				Process Notepad = Process.Start(viewer, ((LoadInfo) ActiveListView.SelectedItems[0].Tag).LogFile);
			}
			catch (Exception E)
			{
				Logger.LogException("", E);
			}
		}

		private void menuItemReset(object sender, EventArgs e)
		{
			foreach (ListViewItem item in ActiveListView.SelectedItems)
			{
				LoadInfo Load = (LoadInfo) item.Tag;
				if (File.Exists(Load.OutputFile))
				{
					if (MessageBox.Show("Temporary processing files exist and need to be removed in order to reset this load.  OK to remove these file?", "Member Prep", MessageBoxButtons.OKCancel) != DialogResult.OK)
						return;
					break;
				}
			}
			foreach (ListViewItem item in ActiveListView.SelectedItems)
			{
				LoadInfo Load = (LoadInfo) item.Tag;
				Load.Cleanup();
				Load.Status = LoadStatus.Ready;
				Load.Progress = new LoadProgress();
				if (File.Exists(Load.DemoFile) && string.Compare(Path.GetDirectoryName(Load.DemoFile), ProcessArgs.Config.InputFolder, 0) != 0)
					File.Move(Load.DemoFile, Path.Combine(ProcessArgs.Config.InputFolder, Path.GetFileName(Load.DemoFile)));
				UpdateListItem(item);
			}
		}

		private void btnProcess_Click(object sender, EventArgs e)
		{
			if (btnProcess.Text == "Abort")
			{
				LoadInfo Load = SelectedItem.Tag as LoadInfo;
				btnProcess.Text = "Aborting";
				btnProcess.Enabled = false;
				Load.Status = LoadStatus.Aborted;
				UpdateUI(null, null);
			}
			else if (btnProcess.Text == "Process")
			{
				if (ActiveListView == listViewDemos)
				{
					foreach (ListViewItem item in ActiveListView.SelectedItems)
					{
						LoadInfo Load = (LoadInfo) item.Tag;
						if (File.Exists(Load.OutputFile))
						{
							if (MessageBox.Show("Temporary files exist from a previous run.\r\nRemove these files and continue?", "Member Prep", MessageBoxButtons.YesNo) != DialogResult.Yes)
								return;
							break;
						}
					}
				}

				ProcessingOptions dlg = new ProcessingOptions();
				dlg.Loadtype = (ActiveListView.SelectedItems[0].Tag as LoadInfo).Loadtype;
				if (dlg.ShowDialog(this) != DialogResult.OK)
					return;

				Stopwatch timer = new Stopwatch();
				timer.Start();
				long TotalRecords = 0;
				ActiveListView.Enabled = false;
				btnRefresh.Enabled = false;
				btnProcess.Text = "Abort";

				// Process the load(s)
				foreach (ListViewItem item in ActiveListView.SelectedItems)
				{
					SelectedItem = item;
					LoadInfo Load = SelectedItem.Tag as LoadInfo;
					Load.LoadOptions = dlg.Options;
					if (Load.Loadtype == LoadType.DEMO)
						Load.OutputFormat = FormatFile.Load(dlg.OutputFormat);

					// Process the data set in a spearate thread so we can handle UI updates from this one
					MemberProcess Processor = new MemberProcess();
					Thread ProcThread = new Thread(x => Processor.ProcessLoad(Load, OnLogString));
					ProcThread.Name = "ProcessingThread";
					ProcThread.Start();
					while (ProcThread.IsAlive)
					{
						UpdatePendingLogs(Load);
						Thread.Sleep(250);
					}

					TotalRecords += Load.RecordCount;
					UpdatePendingLogs(Load);
					if (Load.IsAborted)
						break;
				}

				timer.Stop();
				LogString(string.Format("Processing summary: {0:N0} records, {1:N0} seconds, {2:N0} records/sec",
					TotalRecords, timer.Elapsed.TotalSeconds, (double) TotalRecords / timer.Elapsed.TotalSeconds), LogLevel.Info);
				SelectedItem = null;
				btnProcess.Text = "Process";
				btnRefresh.Enabled = true;
				ActiveListView.Enabled = true;
				btnRefresh_Click(null, null);
			}
		}

		// Callback processing and updating the UI:
		// The callback functions merely save data in private member variables
		// The UI is updated on a regular basis from the main UI thread
		private ConcurrentQueue<Tuple<string, LogLevel>> PendingLogs = new ConcurrentQueue<Tuple<string, LogLevel>>();

		public void OnLogString(string str, LogLevel level)
		{
			if (Thread.CurrentThread == MainThread)
			{
				Cursor cur = Cursor.Current;
				LogString(str, level);
				Cursor.Current = cur;
				Application.DoEvents();
			}
			else
			{
				PendingLogs.Enqueue(new Tuple<string, LogLevel>(str, level));
			}
		}

		private void UpdatePendingLogs(LoadInfo Load)
		{
			Cursor cur = Cursor.Current;

			// update the status for the current load
			UpdateListItem(SelectedItem);

			// update the logs
			Tuple<string, LogLevel> log;
			while (PendingLogs.TryDequeue(out log))
			{
				LogString(log.Item1, log.Item2);
			}

			Application.DoEvents();
			Cursor.Current = cur;
		}

		private void LogString(string str, LogLevel level = LogLevel.Always)
		{
			txtOutput.AppendText(str + "\r\n");
			txtOutput.Select(txtOutput.Text.Length - str.Length - 1, str.Length);
			switch (level)
			{
				case LogLevel.Warning:
					txtOutput.SelectionColor = Color.Blue;
					break;
				case LogLevel.Error:
					txtOutput.SelectionColor = Color.Red;
					break;
				default:
					txtOutput.SelectionColor = Color.Black;
					break;
			}
			txtOutput.Select(txtOutput.Text.Length, 0);
			txtOutput.ScrollToCaret();
		}
	}
}
