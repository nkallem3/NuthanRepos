﻿namespace MemberPrep
{
	partial class ProcessingOptions
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.chkPhoneValidation = new System.Windows.Forms.CheckBox();
			this.chkAddressValidation = new System.Windows.Forms.CheckBox();
			this.chkPhoneEnrich = new System.Windows.Forms.CheckBox();
			this.chkAddressEnrich = new System.Windows.Forms.CheckBox();
			this.chkEmailEnrich = new System.Windows.Forms.CheckBox();
			this.cbxOutputFormat = new System.Windows.Forms.ComboBox();
			this.groupExtract = new System.Windows.Forms.GroupBox();
			this.chkIncludeTermed = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupScrubbing = new System.Windows.Forms.GroupBox();
			this.chkEnableScrubbing = new System.Windows.Forms.CheckBox();
			this.groupEnrichment = new System.Windows.Forms.GroupBox();
			this.chkEnrichDeferred = new System.Windows.Forms.CheckBox();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.groupExtract.SuspendLayout();
			this.groupScrubbing.SuspendLayout();
			this.groupEnrichment.SuspendLayout();
			this.SuspendLayout();
			// 
			// chkPhoneValidation
			// 
			this.chkPhoneValidation.AutoSize = true;
			this.chkPhoneValidation.Checked = true;
			this.chkPhoneValidation.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkPhoneValidation.Location = new System.Drawing.Point(37, 23);
			this.chkPhoneValidation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkPhoneValidation.Name = "chkPhoneValidation";
			this.chkPhoneValidation.Size = new System.Drawing.Size(222, 21);
			this.chkPhoneValidation.TabIndex = 0;
			this.chkPhoneValidation.Text = "Melissa Data Phone Validation";
			this.chkPhoneValidation.UseVisualStyleBackColor = true;
			// 
			// chkAddressValidation
			// 
			this.chkAddressValidation.AutoSize = true;
			this.chkAddressValidation.Checked = true;
			this.chkAddressValidation.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkAddressValidation.Location = new System.Drawing.Point(37, 52);
			this.chkAddressValidation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkAddressValidation.Name = "chkAddressValidation";
			this.chkAddressValidation.Size = new System.Drawing.Size(233, 21);
			this.chkAddressValidation.TabIndex = 1;
			this.chkAddressValidation.Text = "Melissa Data Address Validation";
			this.chkAddressValidation.UseVisualStyleBackColor = true;
			// 
			// chkPhoneEnrich
			// 
			this.chkPhoneEnrich.AutoSize = true;
			this.chkPhoneEnrich.Checked = true;
			this.chkPhoneEnrich.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkPhoneEnrich.Location = new System.Drawing.Point(37, 52);
			this.chkPhoneEnrich.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkPhoneEnrich.Name = "chkPhoneEnrich";
			this.chkPhoneEnrich.Size = new System.Drawing.Size(231, 21);
			this.chkPhoneEnrich.TabIndex = 0;
			this.chkPhoneEnrich.Text = "Melissa Data Phone Enrichment";
			this.chkPhoneEnrich.UseVisualStyleBackColor = true;
			// 
			// chkAddressEnrich
			// 
			this.chkAddressEnrich.AutoSize = true;
			this.chkAddressEnrich.Checked = true;
			this.chkAddressEnrich.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkAddressEnrich.Location = new System.Drawing.Point(37, 23);
			this.chkAddressEnrich.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkAddressEnrich.Name = "chkAddressEnrich";
			this.chkAddressEnrich.Size = new System.Drawing.Size(242, 21);
			this.chkAddressEnrich.TabIndex = 1;
			this.chkAddressEnrich.Text = "Melissa Data Address Enrichment";
			this.chkAddressEnrich.UseVisualStyleBackColor = true;
			// 
			// chkEmailEnrich
			// 
			this.chkEmailEnrich.AutoSize = true;
			this.chkEmailEnrich.Checked = true;
			this.chkEmailEnrich.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkEmailEnrich.Location = new System.Drawing.Point(37, 80);
			this.chkEmailEnrich.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkEmailEnrich.Name = "chkEmailEnrich";
			this.chkEmailEnrich.Size = new System.Drawing.Size(224, 21);
			this.chkEmailEnrich.TabIndex = 2;
			this.chkEmailEnrich.Text = "Melissa Data Email Enrichment";
			this.chkEmailEnrich.UseVisualStyleBackColor = true;
			// 
			// cbxOutputFormat
			// 
			this.cbxOutputFormat.FormattingEnabled = true;
			this.cbxOutputFormat.Location = new System.Drawing.Point(119, 30);
			this.cbxOutputFormat.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.cbxOutputFormat.Name = "cbxOutputFormat";
			this.cbxOutputFormat.Size = new System.Drawing.Size(193, 24);
			this.cbxOutputFormat.TabIndex = 1;
			this.cbxOutputFormat.SelectedIndexChanged += new System.EventHandler(this.cbxOutputFormat_SelectedIndexChanged);
			// 
			// groupExtract
			// 
			this.groupExtract.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupExtract.Controls.Add(this.chkIncludeTermed);
			this.groupExtract.Controls.Add(this.label1);
			this.groupExtract.Controls.Add(this.cbxOutputFormat);
			this.groupExtract.Location = new System.Drawing.Point(16, 228);
			this.groupExtract.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupExtract.Name = "groupExtract";
			this.groupExtract.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupExtract.Size = new System.Drawing.Size(382, 98);
			this.groupExtract.TabIndex = 2;
			this.groupExtract.TabStop = false;
			this.groupExtract.Text = "Extraction";
			// 
			// chkIncludeTermed
			// 
			this.chkIncludeTermed.AutoSize = true;
			this.chkIncludeTermed.Location = new System.Drawing.Point(119, 62);
			this.chkIncludeTermed.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkIncludeTermed.Name = "chkIncludeTermed";
			this.chkIncludeTermed.Size = new System.Drawing.Size(190, 21);
			this.chkIncludeTermed.TabIndex = 2;
			this.chkIncludeTermed.Text = "Include Termed Members";
			this.chkIncludeTermed.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 34);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(103, 17);
			this.label1.TabIndex = 0;
			this.label1.Text = "Output Format:";
			// 
			// groupScrubbing
			// 
			this.groupScrubbing.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupScrubbing.Controls.Add(this.chkEnableScrubbing);
			this.groupScrubbing.Controls.Add(this.chkPhoneValidation);
			this.groupScrubbing.Controls.Add(this.chkAddressValidation);
			this.groupScrubbing.Location = new System.Drawing.Point(16, 14);
			this.groupScrubbing.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupScrubbing.Name = "groupScrubbing";
			this.groupScrubbing.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupScrubbing.Size = new System.Drawing.Size(382, 86);
			this.groupScrubbing.TabIndex = 0;
			this.groupScrubbing.TabStop = false;
			this.groupScrubbing.Text = "Scrubbing";
			// 
			// chkEnableScrubbing
			// 
			this.chkEnableScrubbing.AutoSize = true;
			this.chkEnableScrubbing.Checked = true;
			this.chkEnableScrubbing.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkEnableScrubbing.Location = new System.Drawing.Point(216, 0);
			this.chkEnableScrubbing.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkEnableScrubbing.Name = "chkEnableScrubbing";
			this.chkEnableScrubbing.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.chkEnableScrubbing.Size = new System.Drawing.Size(142, 21);
			this.chkEnableScrubbing.TabIndex = 6;
			this.chkEnableScrubbing.Text = "Enable Scrubbing";
			this.chkEnableScrubbing.UseVisualStyleBackColor = true;
			this.chkEnableScrubbing.CheckedChanged += new System.EventHandler(this.chkEnableScrubbing_CheckedChanged);
			// 
			// groupEnrichment
			// 
			this.groupEnrichment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupEnrichment.Controls.Add(this.chkEnrichDeferred);
			this.groupEnrichment.Controls.Add(this.chkPhoneEnrich);
			this.groupEnrichment.Controls.Add(this.chkAddressEnrich);
			this.groupEnrichment.Controls.Add(this.chkEmailEnrich);
			this.groupEnrichment.Location = new System.Drawing.Point(16, 108);
			this.groupEnrichment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupEnrichment.Name = "groupEnrichment";
			this.groupEnrichment.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.groupEnrichment.Size = new System.Drawing.Size(382, 112);
			this.groupEnrichment.TabIndex = 1;
			this.groupEnrichment.TabStop = false;
			this.groupEnrichment.Text = "Enrichment";
			// 
			// chkEnrichDeferred
			// 
			this.chkEnrichDeferred.AutoSize = true;
			this.chkEnrichDeferred.Checked = true;
			this.chkEnrichDeferred.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkEnrichDeferred.Location = new System.Drawing.Point(196, 0);
			this.chkEnrichDeferred.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.chkEnrichDeferred.Name = "chkEnrichDeferred";
			this.chkEnrichDeferred.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.chkEnrichDeferred.Size = new System.Drawing.Size(161, 21);
			this.chkEnrichDeferred.TabIndex = 5;
			this.chkEnrichDeferred.Text = "Deferred Enrichment";
			this.chkEnrichDeferred.UseVisualStyleBackColor = true;
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(88, 340);
			this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(100, 28);
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "Cancel";
			this.btnCancel.UseVisualStyleBackColor = true;
			// 
			// btnOK
			// 
			this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(227, 340);
			this.btnOK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(100, 28);
			this.btnOK.TabIndex = 4;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			// 
			// ProcessingOptions
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(414, 382);
			this.Controls.Add(this.btnOK);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.groupEnrichment);
			this.Controls.Add(this.groupScrubbing);
			this.Controls.Add(this.groupExtract);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ProcessingOptions";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Processing Options";
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ProcessingOptions_FormClosed);
			this.Load += new System.EventHandler(this.ProcessingOptions_Load);
			this.groupExtract.ResumeLayout(false);
			this.groupExtract.PerformLayout();
			this.groupScrubbing.ResumeLayout(false);
			this.groupScrubbing.PerformLayout();
			this.groupEnrichment.ResumeLayout(false);
			this.groupEnrichment.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.CheckBox chkPhoneValidation;
		private System.Windows.Forms.CheckBox chkAddressValidation;
		private System.Windows.Forms.CheckBox chkPhoneEnrich;
		private System.Windows.Forms.CheckBox chkAddressEnrich;
		private System.Windows.Forms.CheckBox chkEmailEnrich;
		private System.Windows.Forms.ComboBox cbxOutputFormat;
		private System.Windows.Forms.GroupBox groupExtract;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupScrubbing;
		private System.Windows.Forms.GroupBox groupEnrichment;
		private System.Windows.Forms.CheckBox chkIncludeTermed;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.CheckBox chkEnrichDeferred;
		private System.Windows.Forms.CheckBox chkEnableScrubbing;
	}
}