﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

using MemberProcessing;

namespace MemberPrep
{
	public partial class ProcessingOptions : Form
	{
		public LoadType Loadtype = LoadType.DEMO;
		public HashSet<LoadOption> Options = new HashSet<LoadOption>();
		public string OutputFormat = "";

		public ProcessingOptions()
		{
			InitializeComponent();

			// Load the output format combo box
			foreach (string file in Directory.GetFiles(ProcessArgs.Config.OutputFormatFolder, "*.xml"))
			{
				cbxOutputFormat.Items.Add(Path.GetFileNameWithoutExtension(file));
			}
			cbxOutputFormat.SelectedIndex = 0;
		}

		private void ProcessingOptions_Load(object sender, EventArgs e)
		{
			if (Loadtype == LoadType.DeferredEnrichment)
			{
				chkPhoneValidation.Checked = false;
				chkAddressValidation.Checked = false;
				groupScrubbing.Enabled = false;
				chkEnrichDeferred.Checked = false;
				chkEnrichDeferred.Visible = false;
				chkIncludeTermed.Checked = true;
				chkIncludeTermed.Visible = false;
				cbxOutputFormat.Text = "";
				cbxOutputFormat.Enabled = false;
			}

			UpdateUI(null, null);
		}

		private void ProcessingOptions_FormClosed(object sender, FormClosedEventArgs e)
		{
			Options = new HashSet<LoadOption>();
			if (chkEnableScrubbing.Checked == false)
				Options.Add(LoadOption.NoValidation);
			if (chkPhoneValidation.Checked)
				Options.Add(LoadOption.ValidatePhone);
			if (chkAddressValidation.Checked)
				Options.Add(LoadOption.ValidateAddress);
			if (chkAddressEnrich.Checked)
				Options.Add(LoadOption.EnrichAddress);
			if (chkPhoneEnrich.Checked)
				Options.Add(LoadOption.EnrichPhone);
			if (chkEmailEnrich.Checked)
				Options.Add(LoadOption.EnrichEmail);
			if (chkEnrichDeferred.Checked)
				Options.Add(LoadOption.EnrichDeferred);
			if (chkIncludeTermed.Checked)
				Options.Add(LoadOption.IncludeTermed);
			if (groupScrubbing.Enabled == false)
				Options.Add(LoadOption.NoValidation);
			if (groupEnrichment.Enabled == false)
				Options.Add(LoadOption.NoEnrichment);
			OutputFormat = Path.Combine(ProcessArgs.Config.OutputFormatFolder, cbxOutputFormat.Text + ".xml");
		}

		private void UpdateUI(object sender, EventArgs e)
		{
			btnOK.Enabled = cbxOutputFormat.SelectedIndex >= 0;
		}

		private void chkEnableScrubbing_CheckedChanged(object sender, EventArgs e)
		{
			chkPhoneValidation.Enabled = chkEnableScrubbing.Checked;
			chkAddressValidation.Enabled = chkEnableScrubbing.Checked;
		}

		private void cbxOutputFormat_SelectedIndexChanged(object sender, EventArgs e)
		{
			try
			{
				FormatFile fmt;
				if (!string.IsNullOrEmpty(cbxOutputFormat.Text))
					fmt = FormatFile.Load(Path.Combine(ProcessArgs.Config.OutputFormatFolder, cbxOutputFormat.Text + ".xml"));
				UpdateUI(null, null);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to load format file - " + ex.Message);
			}
		}
	}
}
