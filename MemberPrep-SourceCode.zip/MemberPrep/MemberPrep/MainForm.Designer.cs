﻿namespace MemberPrep
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.txtOutput = new System.Windows.Forms.RichTextBox();
			this.btnProcess = new System.Windows.Forms.Button();
			this.btnRefresh = new System.Windows.Forms.Button();
			this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPageDemo = new System.Windows.Forms.TabPage();
			this.listViewDemos = new System.Windows.Forms.ListView();
			this.columnDemoFile = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnDataSource = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnFilesize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnRecords = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.tabPageEnrich = new System.Windows.Forms.TabPage();
			this.listViewEnrich = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.tabControl1.SuspendLayout();
			this.tabPageDemo.SuspendLayout();
			this.tabPageEnrich.SuspendLayout();
			this.SuspendLayout();
			// 
			// txtOutput
			// 
			this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txtOutput.DetectUrls = false;
			this.txtOutput.Location = new System.Drawing.Point(6, 374);
			this.txtOutput.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.ReadOnly = true;
			this.txtOutput.Size = new System.Drawing.Size(967, 211);
			this.txtOutput.TabIndex = 0;
			this.txtOutput.Text = "";
			// 
			// btnProcess
			// 
			this.btnProcess.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnProcess.BackColor = System.Drawing.SystemColors.Control;
			this.btnProcess.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnProcess.Location = new System.Drawing.Point(858, 100);
			this.btnProcess.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnProcess.Name = "btnProcess";
			this.btnProcess.Size = new System.Drawing.Size(110, 43);
			this.btnProcess.TabIndex = 10;
			this.btnProcess.Text = "Process";
			this.btnProcess.UseVisualStyleBackColor = true;
			this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
			// 
			// btnRefresh
			// 
			this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnRefresh.BackColor = System.Drawing.SystemColors.Control;
			this.btnRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnRefresh.Location = new System.Drawing.Point(858, 36);
			this.btnRefresh.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnRefresh.Name = "btnRefresh";
			this.btnRefresh.Size = new System.Drawing.Size(110, 31);
			this.btnRefresh.TabIndex = 9;
			this.btnRefresh.Text = "Refresh";
			this.btnRefresh.UseVisualStyleBackColor = true;
			this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
			// 
			// contextMenu
			// 
			this.contextMenu.ImageScalingSize = new System.Drawing.Size(24, 24);
			this.contextMenu.Name = "contextMenu";
			this.contextMenu.Size = new System.Drawing.Size(61, 4);
			this.contextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenu_Opening);
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPageDemo);
			this.tabControl1.Controls.Add(this.tabPageEnrich);
			this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tabControl1.Location = new System.Drawing.Point(6, 12);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(845, 354);
			this.tabControl1.TabIndex = 12;
			this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_TabIndexChanged);
			// 
			// tabPageDemo
			// 
			this.tabPageDemo.Controls.Add(this.listViewDemos);
			this.tabPageDemo.Location = new System.Drawing.Point(4, 29);
			this.tabPageDemo.Name = "tabPageDemo";
			this.tabPageDemo.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageDemo.Size = new System.Drawing.Size(837, 321);
			this.tabPageDemo.TabIndex = 0;
			this.tabPageDemo.Text = "Demo Files";
			this.tabPageDemo.UseVisualStyleBackColor = true;
			// 
			// listViewDemos
			// 
			this.listViewDemos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnDemoFile,
            this.columnDataSource,
            this.columnDate,
            this.columnFilesize,
            this.columnRecords,
            this.columnStatus});
			this.listViewDemos.ContextMenuStrip = this.contextMenu;
			this.listViewDemos.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listViewDemos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.listViewDemos.FullRowSelect = true;
			this.listViewDemos.GridLines = true;
			this.listViewDemos.HideSelection = false;
			this.listViewDemos.Location = new System.Drawing.Point(3, 3);
			this.listViewDemos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.listViewDemos.Name = "listViewDemos";
			this.listViewDemos.ShowItemToolTips = true;
			this.listViewDemos.Size = new System.Drawing.Size(831, 315);
			this.listViewDemos.TabIndex = 11;
			this.listViewDemos.UseCompatibleStateImageBehavior = false;
			this.listViewDemos.View = System.Windows.Forms.View.Details;
			this.listViewDemos.SelectedIndexChanged += new System.EventHandler(this.UpdateUI);
			// 
			// columnDemoFile
			// 
			this.columnDemoFile.Tag = "int";
			this.columnDemoFile.Text = "Demo File";
			this.columnDemoFile.Width = 200;
			// 
			// columnDataSource
			// 
			this.columnDataSource.Text = "Data Source";
			this.columnDataSource.Width = 220;
			// 
			// columnDate
			// 
			this.columnDate.Tag = "date";
			this.columnDate.Text = "Eff. Date";
			this.columnDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnDate.Width = 80;
			// 
			// columnFilesize
			// 
			this.columnFilesize.Text = "Size (kb)";
			this.columnFilesize.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnFilesize.Width = 80;
			// 
			// columnRecords
			// 
			this.columnRecords.Tag = "int";
			this.columnRecords.Text = "Records";
			this.columnRecords.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnRecords.Width = 80;
			// 
			// columnStatus
			// 
			this.columnStatus.Text = "Status";
			this.columnStatus.Width = 150;
			// 
			// tabPageEnrich
			// 
			this.tabPageEnrich.Controls.Add(this.listViewEnrich);
			this.tabPageEnrich.Location = new System.Drawing.Point(4, 29);
			this.tabPageEnrich.Name = "tabPageEnrich";
			this.tabPageEnrich.Padding = new System.Windows.Forms.Padding(3);
			this.tabPageEnrich.Size = new System.Drawing.Size(837, 321);
			this.tabPageEnrich.TabIndex = 1;
			this.tabPageEnrich.Text = "To Be Enriched";
			this.tabPageEnrich.UseVisualStyleBackColor = true;
			// 
			// listViewEnrich
			// 
			this.listViewEnrich.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6});
			this.listViewEnrich.ContextMenuStrip = this.contextMenu;
			this.listViewEnrich.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listViewEnrich.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.listViewEnrich.FullRowSelect = true;
			this.listViewEnrich.GridLines = true;
			this.listViewEnrich.HideSelection = false;
			this.listViewEnrich.Location = new System.Drawing.Point(3, 3);
			this.listViewEnrich.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.listViewEnrich.Name = "listViewEnrich";
			this.listViewEnrich.ShowItemToolTips = true;
			this.listViewEnrich.Size = new System.Drawing.Size(831, 315);
			this.listViewEnrich.TabIndex = 12;
			this.listViewEnrich.UseCompatibleStateImageBehavior = false;
			this.listViewEnrich.View = System.Windows.Forms.View.Details;
			this.listViewEnrich.SelectedIndexChanged += new System.EventHandler(this.UpdateUI);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Tag = "int";
			this.columnHeader1.Text = "Demo File";
			this.columnHeader1.Width = 200;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Data Source";
			this.columnHeader2.Width = 220;
			// 
			// columnHeader3
			// 
			this.columnHeader3.Tag = "date";
			this.columnHeader3.Text = "Eff. Date";
			this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader3.Width = 80;
			// 
			// columnHeader4
			// 
			this.columnHeader4.Text = "Size (kb)";
			this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader4.Width = 80;
			// 
			// columnHeader5
			// 
			this.columnHeader5.Tag = "int";
			this.columnHeader5.Text = "Records";
			this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.columnHeader5.Width = 80;
			// 
			// columnHeader6
			// 
			this.columnHeader6.Text = "Status";
			this.columnHeader6.Width = 150;
			// 
			// MainForm
			// 
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
			this.ClientSize = new System.Drawing.Size(981, 591);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.btnProcess);
			this.Controls.Add(this.btnRefresh);
			this.Controls.Add(this.txtOutput);
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "MainForm";
			this.Text = "Member Prep";
			this.Load += new System.EventHandler(this.DataLoaderForm_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPageDemo.ResumeLayout(false);
			this.tabPageEnrich.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.RichTextBox txtOutput;
		private System.Windows.Forms.Button btnProcess;
		private System.Windows.Forms.Button btnRefresh;
		private System.Windows.Forms.ContextMenuStrip contextMenu;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPageDemo;
		private System.Windows.Forms.ListView listViewDemos;
		private System.Windows.Forms.ColumnHeader columnDemoFile;
		private System.Windows.Forms.ColumnHeader columnDataSource;
		private System.Windows.Forms.ColumnHeader columnDate;
		private System.Windows.Forms.ColumnHeader columnFilesize;
		private System.Windows.Forms.ColumnHeader columnRecords;
		private System.Windows.Forms.ColumnHeader columnStatus;
		private System.Windows.Forms.TabPage tabPageEnrich;
		private System.Windows.Forms.ListView listViewEnrich;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.ColumnHeader columnHeader3;
		private System.Windows.Forms.ColumnHeader columnHeader4;
		private System.Windows.Forms.ColumnHeader columnHeader5;
		private System.Windows.Forms.ColumnHeader columnHeader6;
	}
}

