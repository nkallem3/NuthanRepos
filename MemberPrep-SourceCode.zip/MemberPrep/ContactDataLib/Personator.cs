﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;

namespace ContactDataLib
{
    public class Personator
    {
		public static int MAX_PERSONATOR_BATCH_SIZE = 100;

		private static Uri PersonatorURL = new Uri("https://personator.melissadata.net/v3/WEB/ContactVerify/doContactVerify");
        private static PersonatorService.ServicemdContactVerifySOAPClient PersonatorService = null;

		public class RequestRecord
        {
            // input data
            public string Company = string.Empty;
            public string Line1 = string.Empty;
            public string Line2 = string.Empty;
			public string City = string.Empty;
            public string State = string.Empty;
            public string Zip = string.Empty;
			public string Country = string.Empty;
			public string FullName = string.Empty;
            public string FirstName = string.Empty;
			public string LastName = string.Empty;
            public string Phone = string.Empty;
            public string Email = string.Empty;

            // output data
            public bool Success = false;
			public string Results = "";
            public Dictionary<Column, string> OutputData = new Dictionary<Column, string>();
            public Dictionary<string, string> OutputNotes = new Dictionary<string, string>();

            public int RecordID = 0;
        }

        public class RequestData
        {
			public string CustomerID { get; set; }
            public bool UseSOAP { get; set; }
            public bool ActionCheck { get; set; }
            public bool ActionVerify { get; set; }
            public bool ActionAppend { get; set; }
            public bool ActionMove { get; set; }
            public bool UsePreferredCity { get; set; }
            public bool AdvancedAddressCorrection { get; set; }
			public bool SaveXML { get; set; }
			public string Message { get; set; }
			public Hint CentricHint { get; set; }
            public Append AppendMode { get; set; }

			public int BatchCount { get { return Records.Count; } }
			public bool ReadyToSend { get { return Records.Count >= MAX_PERSONATOR_BATCH_SIZE; } }

			private List<RequestRecord> Records = new List<RequestRecord>();
            private HashSet<Column> Columns = new HashSet<Column>();
            private HashSet<ColumnGroup> ColumnGroups = new HashSet<ColumnGroup>();

            public void SetColumns(params Column[] columns)
            {
                foreach (Column column in columns)
                    Columns.Add(column);
            }

            public void SetColumnGroups(params ColumnGroup[] groups)
            {
                foreach (ColumnGroup group in groups)
                    ColumnGroups.Add(group);
            }

            public void AddRecord(RequestRecord record)
            {
                Records.Add(record);
				if (record.RecordID == 0)
					record.RecordID = Records.Count;
			}

			public RequestRecord GetRequestRecord(int index)
			{
				return (BatchCount > index ? Records[index] : null);
			}

			public RequestRecord GetRequestRecord(long RecordID)
			{
				return Records.FirstOrDefault(x => x.RecordID == RecordID);
			}

			public string GetActions()
            {
                string actions = "";
                if (ActionCheck)
                    actions += "Check,";
                if (ActionVerify)
                    actions += "Verify,";
                if (ActionAppend)
                    actions += "Append,";
                if (ActionMove)
                    actions += "Move,";
                actions = actions.TrimEnd(',');
                return actions;
            }

            public string GetOptions()
            {
                string options = "";
                if (UsePreferredCity)
                    options += "UsePreferredCity:on;";
                if (AdvancedAddressCorrection)
                    options += "AdvancedAddressCorrection:on;";
                switch (CentricHint)
                {
                    case Hint.Auto: options += "CentricHint:Auto;"; break;
                    case Hint.Address: options += "CentricHint:Address;"; break;
                    case Hint.Phone: options += "CentricHint:Phone;"; break;
                    case Hint.Email: options += "CentricHint:Email;"; break;
                }
                switch (AppendMode)
                {
                    case Append.CheckError: options += "Append:CheckError;"; break;
                    case Append.Always: options += "Append:Always;"; break;
                    case Append.Blank: options += "Append:Blank;"; break;
                }
                options = options.TrimEnd(';');
                return options;
            }

            public string GetColumns()
            {
                string columns = "";
                foreach (Column column in Columns)
                {
                    columns += column.ToString() + ",";
                }
                foreach (ColumnGroup group in ColumnGroups)
                {
                    columns += "Grp" + group.ToString() + ",";
                }
                columns = columns.TrimEnd(',');
                return columns;
            }
        }

        public static bool SendPersonatorRequest(RequestData InputRequest)
        {
            bool result = false;
			InputRequest.Message = "";

			try
			{
                if (InputRequest.UseSOAP)
                {
                    if (PersonatorService == null)
                        PersonatorService = new PersonatorService.ServicemdContactVerifySOAPClient();

                    // Personator service can only handle 100 records at a time
                    for (int Index = 0; Index < InputRequest.BatchCount; Index += Personator.MAX_PERSONATOR_BATCH_SIZE)
                    {
                        int EndIndex = Math.Min(InputRequest.BatchCount, Index + Personator.MAX_PERSONATOR_BATCH_SIZE - 1);
                        PersonatorService.Request request = new PersonatorService.Request();
                        PersonatorService.Response response = new PersonatorService.Response();

                        // Build the request header (actions, options, return columns, etc.)
                        request = new PersonatorService.Request();
                        request.CustomerID = InputRequest.CustomerID;
                        request.TransmissionReference = "CHC Personator Request";
                        request.Actions = InputRequest.GetActions();
                        request.Options = InputRequest.GetOptions();
                        request.Columns = InputRequest.GetColumns();
                        request.Records = new PersonatorService.RequestRecord[InputRequest.BatchCount];

                        // Add each of the records
                        for (int CurrRecord = Index; CurrRecord <= EndIndex; CurrRecord++)
                        {
                            RequestRecord record = InputRequest.GetRequestRecord(CurrRecord);
                            PersonatorService.RequestRecord SubmitRecord = new PersonatorService.RequestRecord();
                            SubmitRecord = new PersonatorService.RequestRecord();
                            SubmitRecord.RecordID = record.RecordID.ToString();
                            SubmitRecord.FullName = record.FullName;
                            SubmitRecord.CompanyName = record.Company;
                            SubmitRecord.AddressLine1 = record.Line1;
                            SubmitRecord.AddressLine2 = record.Line2;
                            SubmitRecord.City = record.City;
                            SubmitRecord.State = record.State;
                            SubmitRecord.PostalCode = record.Zip;
                            SubmitRecord.Country = record.Country;
                            SubmitRecord.FirstName = record.FirstName;
                            SubmitRecord.LastName = record.LastName;
                            SubmitRecord.EmailAddress = record.Email;
                            SubmitRecord.PhoneNumber = record.Phone;
                            request.Records[CurrRecord] = SubmitRecord;
                        }

                        // Send the request
                        response = PersonatorService.doContactVerify(request);

						for (int CurrRecord = Index; CurrRecord <= EndIndex; CurrRecord++)
						{
							RequestRecord Request = InputRequest.GetRequestRecord(CurrRecord);

							// Find the response record that corresponds with this request record
							PersonatorService.ResponseRecord record = response.Records.FirstOrDefault(x => x.RecordID == Request.RecordID.ToString());
							if (record == null)
							{
								// error
								Request.Results = "Response not received for record " + Request.RecordID.ToString();
								continue;
							}

							// Populate the output data
							Request.Success = true;
							Request.Results = record.Results.Trim();
							ParseOutputResults(record.Results, Request);
							foreach (PropertyInfo pi in record.GetType().GetProperties())
							{
								Column col;
								if (Enum.TryParse(pi.Name, true, out col) == true)
								{
									string val = pi.GetValue(record) as string;
									if (val != null)
									{
										val = val.Trim();
										if (!string.IsNullOrEmpty(val))
											Request.OutputData[col] = val.ToString();
									}
								}
							}
						}
					}
                }
                else
                {
                    // Personator service can only handle 100 records at a time
                    for (int Index = 0; Index < InputRequest.BatchCount; Index += Personator.MAX_PERSONATOR_BATCH_SIZE)
                    {
                        int EndIndex = Math.Min(InputRequest.BatchCount, Index + Personator.MAX_PERSONATOR_BATCH_SIZE) - 1;
                        MemoryStream XMLToSend = new MemoryStream();

                        using (XmlTextWriter Writer = new XmlTextWriter(XMLToSend, null))
                        {
                            // Build the request header (actions, options, return columns, etc.)
                            Writer.WriteStartDocument();
                            Writer.WriteStartElement("Request");
                            Writer.WriteElementString("CustomerID", InputRequest.CustomerID);
                            Writer.WriteElementString("TransmissionReference", "Altegra Health Personator XML Interface");
                            Writer.WriteElementString("Actions", InputRequest.GetActions());
                            Writer.WriteElementString("Columns", InputRequest.GetColumns());
                            Writer.WriteElementString("Options", InputRequest.GetOptions());

							// Add each of the records - up to MAX_PERSONATOR_BATCH_SIZE
							Writer.WriteStartElement("Records");
                            for (int CurrRecord = Index; CurrRecord <= EndIndex; CurrRecord++)
                            {
                                RequestRecord record = InputRequest.GetRequestRecord(CurrRecord);
                                Writer.WriteStartElement("RequestRecord");
                                Writer.WriteElementString("RecordID", record.RecordID.ToString());
                                Writer.WriteElementString("CompanyName", record.Company);
                                Writer.WriteElementString("AddressLine1", record.Line1);
                                Writer.WriteElementString("AddressLine2", record.Line2);
                                Writer.WriteElementString("City", record.City);
                                Writer.WriteElementString("State", record.State);
                                Writer.WriteElementString("PostalCode", record.Zip);
                                Writer.WriteElementString("Country", record.Country);
                                Writer.WriteElementString("FullName", record.FullName);
                                Writer.WriteElementString("FirstName", record.FirstName);
                                Writer.WriteElementString("LastName", record.LastName);
                                Writer.WriteElementString("EmailAddress", record.Email);
                                Writer.WriteElementString("PhoneNumber", record.Phone);
                                Writer.WriteElementString("FreeForm", "");
                                Writer.WriteEndElement();
                            }
                            Writer.WriteEndElement();
                            Writer.WriteEndElement();

                            Writer.Flush();
                            Writer.Close();
                        }

                        byte[] byteData = XMLToSend.ToArray();

                        Stream postStream = null;
                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(PersonatorURL);
                        request.Method = "POST";
                        request.ContentType = "text/plain; charset=utf-8";
                        request.Accept = "application/xml";
                        request.ContentLength = byteData.Length;
						request.KeepAlive = true;
                        postStream = request.GetRequestStream();
                        postStream.Write(byteData, 0, byteData.Length);
                        postStream.Close();

						// Get the response
						HttpWebResponse response = (HttpWebResponse)request.GetResponse();
						XDocument xmlRespDoc = XDocument.Load(response.GetResponseStream());

						// write the request and response XML to a file
						if (InputRequest.SaveXML)
						{
							XDocument xmlReqDoc = XDocument.Parse(System.Text.Encoding.Default.GetString(byteData));
							xmlReqDoc.Save("XMLRequest.xml");
							xmlRespDoc.Save("XMLResponse.xml");
						}

						XmlReader reader = xmlRespDoc.CreateReader();
						int RecordNum = Index;
                        while (reader.Read())
                        {
                            if (reader.MoveToContent() != XmlNodeType.Element)
                                continue;
                            if (reader.Name.ToUpperInvariant() == "RESPONSERECORD")
                            {
                                reader.Read();
                                reader.MoveToContent();
                                int CurrDepth = reader.Depth;
                                RequestRecord record = InputRequest.GetRequestRecord(RecordNum);
                                while (reader.Depth == CurrDepth)
                                {
                                    string name = reader.Name;
                                    string value = reader.ReadInnerXml();
                                    Column col;
                                    if (name == "Results")
                                    {
                                        record.Success = true;
										record.Results = value.Trim();
                                        ParseOutputResults(record.Results, record);
                                    }
                                    else if (name == "TransmissionResults")
                                    {
                                        record.Success = false;
										record.Results = value.Trim();
										ParseOutputResults(record.Results, record);
                                    }
                                    else
                                    {
                                        if (Enum.TryParse<Column>(name, out  col))
                                            record.OutputData[col] = value;
                                    }
                                }
                                RecordNum++;
                            }
                        }
                    }
                }
				result = true;
			}
			catch (Exception ex)
            {
				InputRequest.Message = ex.Message;
				result = false;
            }

			return result;
        }

        private static void ParseOutputResults(string Results, RequestRecord record)
        {
            try
            {
				string AddressCodes = "";
				string PhoneCodes = "";
				string EmailCodes = "";
				string NameCodes = "";
				string OtherCodes = "";
				string[] Codes = Results.Split(',');
                foreach (string code in Codes)
                {
					if (record.Success == false)
                    {
						record.OutputNotes.Add(code, MelissaDataValidator.GetTxDescription(code));
					}
                    else
                    {
						record.OutputNotes.Add(code, MelissaDataValidator.GetDescription(code));
						if (code.StartsWith("A"))
							AddressCodes += AddressCodes.Length == 0 ? code : "," + code;
						else if (code.StartsWith("P"))
							PhoneCodes += PhoneCodes.Length == 0 ? code : "," + code;
						else if (code.StartsWith("E"))
							EmailCodes += EmailCodes.Length == 0 ? code : "," + code;
						else if (code.StartsWith("N"))
							NameCodes += NameCodes.Length == 0 ? code : "," + code;
						else
							OtherCodes += OtherCodes.Length == 0 ? code : "," + code;
					}
				}
				if (!string.IsNullOrEmpty(AddressCodes))
				{
					record.OutputData.Add(Column.AddressCodes, AddressCodes);
				}
				if (record.OutputData.ContainsKey(Column.AddressTypeCode))
				{
					record.OutputData.Add(Column.AddressType, MelissaDataValidator.GetAddressType(record.OutputData[Column.AddressTypeCode]).ToString());
				}
				if (!string.IsNullOrEmpty(PhoneCodes))
				{
					record.OutputData.Add(Column.PhoneCodes, PhoneCodes);
					record.OutputData.Add(Column.PhoneType, MelissaDataValidator.GetPhoneType(PhoneCodes).ToString());
					record.OutputData.Add(Column.PhoneExchange, MelissaDataValidator.GetPhoneExchange(PhoneCodes).ToString());
				}
				if (!string.IsNullOrEmpty(EmailCodes))
				{
					record.OutputData.Add(Column.EmailCodes, EmailCodes);
				}
				if (!string.IsNullOrEmpty(NameCodes))
				{
					record.OutputData.Add(Column.NameCodes, NameCodes);
				}
				if (!string.IsNullOrEmpty(OtherCodes))
				{
					record.OutputData.Add(Column.OtherCodes, OtherCodes);
					record.OutputData.Add(Column.GeocodeType, MelissaDataValidator.GetGeocodeType(OtherCodes).ToString());
				}
			}
			catch (Exception ex)
            {
            }
        }

		public enum Hint
        {
            Auto,
            Address,
            Phone,
            Email
        }

        public enum Append
        {
            CheckError,
            Always,
            Blank,
        }

		public enum Option
		{
			UsePreferredCity,
			Diacritics,
			AdvancedAddressCorrection,
			AdvancedAddressType,
			LongAddressFormat,
			CorrectSyntax,
			UpdateDomain,
			DatabaseLookup,
			StandardizeCasing,
			CorrectFirstName,
			StandardizeCompany,
			NameHint,
			GenderPopulation,
			GenderAggression,
			MiddleNameLogic,
			SalutationFormat,
			CentricHint,
			Append,
			Demographics,
			SSNCascade,
			DecennialCensusKey,
			FuzzyLookup,
		}

		public enum Column
        {
			// Column Name                       Group
			AddressExtras,                    // Default
			AddressKey,                       // Default
			AddressLine1,                     // Default
			AddressLine2,                     // Default
			City,                             // Default
			CompanyName,                      // Default
			EmailAddress,                     // Default
			MelissaAddressKey,                // Default
			MelissaAddressKeyBase,            // Default
			NameFull,                         // Default
			PhoneNumber,                      // Default
			PostalCode,                       // Default
			RecordID,                         // Default
			Results,                          // Default
			State,                            // Default
			DateLastConfirmed,                // N/A
			EstimatedHomeValue,               // N/A
			MelissaIdentityKey,               // N/A
			MoveDate,                         // N/A
			Occupation,                       // N/A
			OwnRent,                          // N/A
			PhoneCountryCode,                 // N/A
			PhoneCountryName,                 // N/A
			Plus4,                            // N/A
			PrivateMailBox,                   // N/A
			Suite,                            // N/A
			AddressTypeCode,                  // AddressDetails
			CarrierRoute,                     // AddressDetails
			CityAbbreviation,                 // AddressDetails
			CountryCode,                      // AddressDetails
			CountryName,                      // AddressDetails
			DeliveryIndicator,                // AddressDetails
			DeliveryPointCheckDigit,          // AddressDetails
			DeliveryPointCode,                // AddressDetails
			StateName,                        // AddressDetails
			UrbanizationName,                 // AddressDetails
			UTC,                              // AddressDetails
			AddressDeliveryInstallation,      // ParsedAddress
			AddressHouseNumber,               // ParsedAddress
			AddressLockBox,                   // ParsedAddress
			AddressPostDirection,             // ParsedAddress
			AddressPreDirection,              // ParsedAddress
			AddressPrivateMailboxName,        // ParsedAddress
			AddressPrivateMailboxRange,       // ParsedAddress
			AddressRouteService,              // ParsedAddress
			AddressStreetName,                // ParsedAddress
			AddressStreetSuffix,              // ParsedAddress
			AddressSuiteName,                 // ParsedAddress
			AddressSuiteNumber,               // ParsedAddress
			Latitude,                         // Geocode
			Longitude,                        // Geocode
			AreaCode,                         // ParsedPhone
			NewAreaCode,                      // ParsedPhone
			PhoneExtension,                   // ParsedPhone
			PhonePrefix,                      // ParsedPhone
			PhoneSuffix,                      // ParsedPhone
			DomainName,                       // ParsedEmail
			MailboxName,                      // ParsedEmail
			TopLevelDomain,                   // ParsedEmail
			Gender,                           // NameDetails
			Gender2,                          // NameDetails
			NameFirst,                        // NameDetails
			NameFirst2,                       // NameDetails
			NameLast,                         // NameDetails
			NameLast2,                        // NameDetails
			NameMiddle,                       // NameDetails
			NameMiddle2,                      // NameDetails
			NamePrefix,                       // NameDetails
			NamePrefix2,                      // NameDetails
			NameSuffix,                       // NameDetails
			NameSuffix2,                      // NameDetails
			Salutation,                       // NameDetails
			CBSACode,                         // Census
			CBSADivisionCode,                 // Census
			CBSADivisionLevel,                // Census
			CBSADivisionTitle,                // Census
			CBSALevel,                        // Census
			CBSATitle,                        // Census
			CensusBlock,                      // Census
			CensusTract,                      // Census
			CongressionalDistrict,            // Census
			CountyFIPS,                       // Census
			CountyName,                       // Census
			PlaceCode,                        // Census
			PlaceName,                        // Census
			CensusKey,                        // Census2
			CountySubdivisionCode,            // Census2
			CountySubdivisionName,            // Census2
			ElementarySchoolDistrictCode,     // Census2
			ElementarySchoolDistrictName,     // Census2
			SecondarySchoolDistrictCode,      // Census2
			SecondarySchoolDistrictName,      // Census2
			StateDistrictLower,               // Census2
			StateDistrictUpper,               // Census2
			UnifiedSchoolDistrictCode,        // Census2
			UnifiedSchoolDistrictName,        // Census2
			ChildrenAgeRange,                 // DemographicBasic
			CreditCardUser,                   // DemographicBasic
			DateOfBirth,                      // DemographicBasic
			DateOfDeath,                      // DemographicBasic
			DemographicsGender,               // DemographicBasic
			DemographicsResults,              // DemographicBasic
			Education,                        // DemographicBasic
			EthnicCode,                       // DemographicBasic
			EthnicGroup,                      // DemographicBasic
			HouseholdIncome,                  // DemographicBasic
			HouseholdSize,                    // DemographicBasic
			LengthOfResidence,                // DemographicBasic
			MaritalStatus,                    // DemographicBasic
			PoliticalParty,                   // DemographicBasic
			PresenceOfChildren,               // DemographicBasic
			PresenceOfSenior,                 // DemographicBasic
			DistanceAddressToIP,              // IPAddress
			IPAddress,                        // IPAddress
			IPCity,                           // IPAddress
			IPConnectionSpeed,                // IPAddress
			IPConnectionType,                 // IPAddress
			IPContinent,                      // IPAddress
			IPCountryAbbreviation,            // IPAddress
			IPCountryName,                    // IPAddress
			IPDomainName,                     // IPAddress
			IPISPName,                        // IPAddress
			IPLatitude,                       // IPAddress
			IPLongitude,                      // IPAddress
			IPPostalCode,                     // IPAddress
			IPProxyDescription,               // IPAddress
			IPProxyType,                      // IPAddress
			IPRegion,                         // IPAddress
			IPUTC,                            // IPAddress

			AddressCodes,
			PhoneCodes,
			EmailCodes,
			NameCodes,
			OtherCodes,
			AddressType,
			GeocodeType,
			PhoneType,
			PhoneExchange,
		}

		public enum ColumnGroup
        {
            ParsedAddress,
            AddressDetails,
			GeoCode,
			ParsedPhone,
			ParsedEmail,
			NameDetails,
			Census,
			Census2,
			DemographicBasic,
			IPAddress,
		}
	}
}
