﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataLib
{
	public enum AddressType
	{
		Unknown = 0,
		Company = 1,
		GeneralDelivery = 2,
		HighRise = 3,
		POBox = 4,
		RuralRoute = 5,
		Residential = 6,
	}

	public enum GeocodeType
	{
		Unknown = 0,
		Zip5 = 5,
		Zip7 = 7,
		Zip9 = 9,
		Zip11 = 11,
	}

	public enum PhoneType
	{
		Unknown = 0,
		Residential = 1,
		Business = 2,
		HomeOffice = 3,
		TollFree = 4,
		Special = 5,
		Fax = 6,
	}

	public enum ExchangeType
	{
		Unknown = 0,
		Cellular = 1,
		Land = 2,
		Voip = 3,
	}

	public class CDAddress
	{
		// Input
		public string Company = string.Empty;
		public string Line1 = string.Empty;
		public string Line2 = string.Empty;
		public string City = string.Empty;
		public string State = string.Empty;
		public string Zip = string.Empty;

		// Output
		public string Plus4 = string.Empty;
		public string DeliveryPoint = string.Empty;
		public string Suite = string.Empty;
		public string County = string.Empty;
		public string Country = string.Empty;
		public string Zip11 = string.Empty;
		public string Latitude = string.Empty;
		public string Longitude = string.Empty;
		public string Notes = string.Empty;
		public string Garbage = string.Empty;
		public string FIPSCode = string.Empty;
		public string SSACode = string.Empty;
		public AddressType AddressType = AddressType.Unknown;
		public GeocodeType GeocodeType = GeocodeType.Unknown;

		public string Zip5 { get { return (Zip != null && Zip.Length > 5) ? Zip.Substring(0, 5) : Zip; } }

		private const char Delimiter = '|';

		public CDAddress()
        {
        }

		public CDAddress Clone()
		{
			return (CDAddress)MemberwiseClone();
		}

		public CDAddress(string L1, string L2, string C, string S, string Z)
        {
            Line1 = L1;
            Line2 = L2;
            City = C;
            State = S;
            Zip = Z;
        }

        public override string ToString()
        {
            string FullAddr = string.Empty;

            if (!string.IsNullOrEmpty(Line1))
                FullAddr += Line1 + ", ";
            if (!string.IsNullOrEmpty(Line2))
                FullAddr += Line2 + ", ";
            if (!string.IsNullOrEmpty(City))
                FullAddr += City + ", ";
            if (!string.IsNullOrEmpty(State))
                FullAddr += State + " ";
            if (!string.IsNullOrEmpty(Zip))
                FullAddr += Zip;

            return FullAddr.Trim();
        }

		public static bool AddressIsSame(CDAddress A1, CDAddress A2, bool IgnoreCase = true)
		{
			if (string.Compare(A1.Zip11, A2.Zip11, IgnoreCase) == 0)
				return true;
			return string.Compare(A1.ToCacheKey(), A2.ToCacheKey(), IgnoreCase) == 0;
		}

		public bool IsEmpty()
		{
			return string.IsNullOrEmpty(Line1 + Line2 + City + State + Zip + Zip11);
		}

		public bool MightBeValid()
		{
			// Zip11 is sufficient. Otherwise must have non-empty Line1 or Line2 PLUS valid zip OR both city and state
			int nZip;
			if (!string.IsNullOrEmpty(Zip11))
				return true;
			if (string.IsNullOrEmpty(Line1) && string.IsNullOrEmpty(Line2))
				return false;
			if (!string.IsNullOrEmpty(Zip) && int.TryParse(Zip, out nZip) == true && nZip <= 99999 && nZip > 0)
				return true;
			if (!string.IsNullOrEmpty(City) && !string.IsNullOrEmpty(State))
				return true;
			return false;
		}

		public bool IsValid()
		{
			if (MightBeValid() == false)
				return false;
			if (!string.IsNullOrEmpty(Zip11))
				return true;
			if ((Notes.Contains("AS01")) || (Notes.Contains("AS02")) || (Notes.Contains("AS03")))
				return true;
			return false;
		}

		public string ToCacheKey()
		{
			StringBuilder s = new StringBuilder(500);
			s.Append(Company + Delimiter);
			s.Append(Line1 + Delimiter);
			s.Append(Line2 + Delimiter);
			s.Append(City + Delimiter);
			s.Append(State + Delimiter);
			s.Append(Zip5);
			return s.ToString();
		}

		public static CDAddress FromCacheKey(string Key)
		{
			CDAddress Address = null;
			string[] parts = Key.Split(Delimiter);
			if (parts.Count() == 6)
			{
				Address = new CDAddress();
				Address.Company = parts[0];
				Address.Line1 = parts[1];
				Address.Line2 = parts[2];
				Address.City = parts[3];
				Address.State = parts[4];
				Address.Zip = parts[5];
			}
			return Address;
		}

		public string ToCacheValue()
		{
			StringBuilder s = new StringBuilder(2000);
			s.Append(Company + Delimiter);
			s.Append(Line1 + Delimiter);
			s.Append(Line2 + Delimiter);
			s.Append(City + Delimiter);
			s.Append(State + Delimiter);
			s.Append(Zip + Delimiter);
			s.Append(Plus4 + Delimiter);
			s.Append(DeliveryPoint + Delimiter);
			s.Append(Suite + Delimiter);
			s.Append(County + Delimiter);
			s.Append(Country + Delimiter);
			s.Append(Zip11 + Delimiter);
			s.Append(Latitude + Delimiter);
			s.Append(Longitude + Delimiter);
			s.Append(Notes + Delimiter);
			s.Append(Garbage + Delimiter);
			s.Append(FIPSCode + Delimiter);
			s.Append(SSACode + Delimiter);
			s.Append(((int) AddressType).ToString() + Delimiter);
			s.Append(((int) GeocodeType).ToString());
			return s.ToString();
		}

		public static CDAddress FromCacheValue(string Value)
		{
			CDAddress Address = null;
			string[] parts = Value.Split(Delimiter);
			if (parts.Count() == 20)
			{
				Address = new CDAddress();
				Address.Company = parts[0];
				Address.Line1 = parts[1];
				Address.Line2 = parts[2];
				Address.City = parts[3];
				Address.State = parts[4];
				Address.Zip = parts[5];
				Address.Plus4 = parts[6];
				Address.DeliveryPoint = parts[7];
				Address.Suite = parts[8];
				Address.County = parts[9];
				Address.Country = parts[10];
				Address.Zip11 = parts[11];
				Address.Latitude = parts[12];
				Address.Longitude = parts[13];
				Address.Notes = parts[14];
				Address.Garbage = parts[15];
				Address.FIPSCode = parts[16];
				Address.SSACode = parts[17];
				Address.AddressType = (AddressType) Convert.ToInt32(parts[18]);
				Address.GeocodeType = (GeocodeType) Convert.ToInt32(parts[19]);
			}
			return Address;
		}
	}

	public class CDPhone
    {
        // Input
        public string PhoneNumber = string.Empty;
        public string ZipCode = string.Empty;

        // Output
        public string AreaCode = string.Empty;
        public string Extension = string.Empty;
        public string Prefix = string.Empty;
        public string Suffix = string.Empty;
        public string City = string.Empty;
        public string State = string.Empty;
        public string County = string.Empty;
        public string Country = string.Empty;
        public string Latitude = string.Empty;
        public string Longitude = string.Empty;
		public string Result = string.Empty;
		public string Notes = string.Empty;
		public ExchangeType ExchangeType = ExchangeType.Unknown;
		public PhoneType PhoneType = PhoneType.Unknown;

		private const char Delimiter = '|';

        public CDPhone()
        {
		}

		public CDPhone(string P, string Z)
        {
            PhoneNumber = P;
            ZipCode = Z;
        }

        public override string ToString()
        {
            return PhoneNumber;
        }

		public bool IsValid()
		{
			return Result == "Success";
		}

		public string ToCacheKey()
		{
			return PhoneNumber;
		}

		public static CDPhone FromCacheKey(string Key)
		{
			CDPhone Phone = null;
			if (!string.IsNullOrEmpty(Key))
				Phone = new CDPhone(Key, null);
			return Phone;
		}

		public string ToCacheValue()
		{
			StringBuilder s = new StringBuilder(2000);
			s.Append(PhoneNumber + Delimiter);
			s.Append(ZipCode + Delimiter);
			s.Append(AreaCode + Delimiter);
			s.Append(Extension + Delimiter);
			s.Append(Prefix + Delimiter);
			s.Append(Suffix + Delimiter);
			s.Append(City + Delimiter);
			s.Append(State + Delimiter);
			s.Append(County + Delimiter);
			s.Append(Country + Delimiter);
			s.Append(Latitude + Delimiter);
			s.Append(Longitude + Delimiter);
			s.Append(Result + Delimiter);
			s.Append(Notes + Delimiter);
			s.Append(((int) ExchangeType).ToString() + Delimiter);
			s.Append(((int) PhoneType).ToString());
			return s.ToString();
		}

		public static CDPhone FromCacheValue(string Value)
		{
			CDPhone Phone = null;
			string[] parts = Value.Split(Delimiter);
			if (parts.Count() == 16)
			{
				Phone = new CDPhone();
				Phone.PhoneNumber = parts[0];
				Phone.ZipCode = parts[1];
				Phone.AreaCode = parts[2];
				Phone.Extension = parts[3];
				Phone.Prefix = parts[4];
				Phone.Suffix = parts[5];
				Phone.City = parts[6];
				Phone.State = parts[7];
				Phone.County = parts[8];
				Phone.Country = parts[9];
				Phone.Latitude = parts[10];
				Phone.Longitude = parts[11];
				Phone.Result = parts[12];
				Phone.Notes = parts[13];
				Phone.ExchangeType = (ExchangeType) Convert.ToInt32(parts[14]);
				Phone.PhoneType = (PhoneType) Convert.ToInt32(parts[15]);
			}
			return Phone;
		}
	}

	public class CDEmail
    {
        // Input
        public string Email = string.Empty;

        // Output
        public string Notes = string.Empty;

        public CDEmail()
        {
        }

        public CDEmail(string E)
        {
            Email = E;
        }

        public override string ToString()
        {
            return Email;
        }
    }

    public class CDName
    {
        // Input
        public string FullName = string.Empty;
        public string Prefix = string.Empty;
        public string First = string.Empty;
        public string Middle = string.Empty;
        public string Last = string.Empty;
        public string Suffix = string.Empty;

        // Output
        public string Gender = string.Empty;
        public string Notes = string.Empty;

        public CDName()
        {
        }

        public CDName(string F, string M, string L)
        {
            First = F;
            Middle = M;
            Last = L;
        }

        public override string ToString()
        {
            string FullName = string.Empty;

            if (!string.IsNullOrEmpty(Prefix))
                FullName += Prefix + " ";
            if (!string.IsNullOrEmpty(First))
                FullName += First + " ";
            if (!string.IsNullOrEmpty(Middle))
                FullName += Middle + " ";
            if (!string.IsNullOrEmpty(Last))
                FullName += Last + " ";
            if (!string.IsNullOrEmpty(Suffix))
                FullName += Suffix + " ";

            return FullName.Trim();
        }
    }

	// Data cache for address and phone data
	// The cache is implemented as a simple dictionary with a type-specified key (normally a string).
	// Cached values are stored as strings instead of objects in order to save memory (the saving is dramatic).
	// The cache is size-restricted (set in constructor)
	// An MRU algorithm is used to trim the cache. Key values are enqueued when items are added or retrieved.
	// When the cache size limit is reached, the oldest key is retrieved (dequeued).
	// If that key exists only once in the queue (KeyCounts), the item is removed from the cache.
	// If the key exists in the queue more than once, keys are dequeued until one is found with a count of 1.
	public class CDCache<T> : IEnumerable
	{
		private Dictionary<T, string> Cache = new Dictionary<T, string>();
		private Dictionary<T, long> KeyMRUCounts = new Dictionary<T, long>();
		private Queue<T> KeyMRUQueue = new Queue<T>();
		private long CacheSizeLimit = 0;

		public long CacheSize { get; private set; }
		public long GetCount { get; private set; }
		public long ErrorCount { get; private set; }
		public long HitCount { get; private set; }
		public decimal HitRate { get { return (decimal) HitCount / GetCount; } }

		public CDCache(long MaxSize)
		{
			CacheSizeLimit = MaxSize;
			ClearCache();
		}

		public IEnumerator GetEnumerator()
		{
			return Cache.GetEnumerator();
		}

		public void ClearCache()
		{
			lock (Cache)
			{
				Cache.Clear();
				KeyMRUCounts.Clear();
				KeyMRUQueue.Clear();
				CacheSize = 0;
				GetCount = 0;
				ErrorCount = 0;
				HitCount = 0;
			}
		}

		public void AddToCache(T key, string value)
		{
			lock (Cache)
			{
				if (Cache.ContainsKey(key))
				{
					// refresh the cached value and increment the key count
					Cache[key] = value;
					KeyMRUCounts[key]++;
				}
				else
				{
					// add new item to the cache and set the key count to 1
					Cache.Add(key, value);
					KeyMRUCounts.Add(key, 1);
					CacheSize++;
				}
				KeyMRUQueue.Enqueue(key);

				if (CacheSize > CacheSizeLimit)
				{
					// trim the cache by removing the oldest item(s) that exists only once in the MRU queue
					int CountToRemove = (int) (CacheSizeLimit / 10000) + 1;
					for (int n = CountToRemove; n > 0; n--)
					{
						while (KeyMRUQueue.Count > 0)
						{
							T oldestkey = KeyMRUQueue.Dequeue();
							if (--KeyMRUCounts[oldestkey] == 0)
							{
								Cache.Remove(oldestkey);
								KeyMRUCounts.Remove(oldestkey);
								CacheSize--;
								break;
							}
						}
					}
				}
			}
		}

		public string GetFromCache(T key)
		{
			string value = null;

			GetCount++;
			lock (Cache)
			{
				if (Cache.TryGetValue(key, out value))
				{
					// add the key to the head of the MRU queue and increment the count of times the key exists in the queue
					HitCount++;
					KeyMRUCounts[key]++;
					KeyMRUQueue.Enqueue(key);
				}
			}
			return value;
		}
	}
}
