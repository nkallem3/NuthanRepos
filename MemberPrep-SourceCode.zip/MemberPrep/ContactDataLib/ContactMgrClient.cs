﻿using System;
using System.Configuration;
using System.Threading;

namespace ContactDataLib
{
	public class ContactMgrClient
	{
		private SRContactManager.ContactManagerClient ContactMgr = null;

		public SRContactManager.ContactManagerClient ConnectToContactManager(string endpoint)
		{
			if (string.IsNullOrEmpty(endpoint))
				endpoint = "ContactManager";
			ContactMgr = new SRContactManager.ContactManagerClient(endpoint);

			// Check if the service is available by setting a fairly short timeout
			ContactMgr.Endpoint.Binding.SendTimeout = ContactMgr.Endpoint.Binding.OpenTimeout;
			int Retry = 0;
			while (true)
			{
				try
				{
					ContactDataProvider dp = (ContactDataProvider)ContactMgr.GetProviderType();
					break;
				}
				catch (Exception ex)
				{
					if (++Retry > 3 || ex.HResult != -2146233083)
						throw;
					Thread.Sleep(10000);
				}
			}

			// In order to revert the timeout to its configured value, we have to recreate the client connection
			ContactMgr = new SRContactManager.ContactManagerClient(endpoint);

			return ContactMgr;
		}

		public bool AddressVerify(CDAddress InputAddress, out CDAddress OutputAddress)
		{
			OutputAddress = null;
			if (ContactMgr == null)
				throw new Exception("Contact Manager connection has not been established");
			return ContactMgr.AddressVerify(InputAddress, out OutputAddress);
		}

		public bool PhoneVerify(CDPhone InputPhone, out CDPhone OutputPhone)
		{
			OutputPhone = null;
			if (ContactMgr == null)
				throw new Exception("Contact Manager connection has not been established");
			return ContactMgr.PhoneVerify(InputPhone, out OutputPhone);
		}

		public bool EmailVerify(CDEmail InputEmail, out CDEmail OutputEmail)
		{
			OutputEmail = null;
			if (ContactMgr == null)
				throw new Exception("Contact Manager connection has not been established");
			return ContactMgr.EmailVerify(InputEmail, out OutputEmail);
		}

		public bool NameVerify(CDName InputName, out CDName OutputName)
		{
			OutputName = null;
			if (ContactMgr == null)
				throw new Exception("Contact Manager connection has not been established");
			return ContactMgr.NameVerify(InputName, out OutputName);
		}
	}
}
