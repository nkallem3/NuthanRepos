﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Serialization;

using MelissaData;

namespace ContactDataLib
{
    public class MelissaDataConfig
    {
		private static MelissaDataConfig _ConfigSingleton = null;
		public static MelissaDataConfig ConfigSingleton
		{
			get
			{
				if (_ConfigSingleton == null)
					ReadConfig(null);
				return _ConfigSingleton;
			}
		}

		public string CustomerNumber = "";
        public string LicenseCode = "";
		public string DataFilePath = "";
		public string GeoLicenseCode = "";
		public string GeoDataFilePath = "";
		public string AddressInit = "ADLSCFGZP";
		public string SuitePlacement = "";
		public string GarbagePlacement = "";
		public bool EnableStatistics = true;
		public bool SavePersonatorIO = false;
		public int AddressCacheSize = 0;
		public string CountyLookupFile = "";

		public static string ConfigFile { get; private set; }

        public static void ReadConfig(string path)
        {
            try
            {
                if (string.IsNullOrEmpty(path))
                    path = Environment.GetEnvironmentVariable("MelissaDataConfig");
                if (string.IsNullOrEmpty(path))
                    path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + "\\MelissaData.config";
				ConfigFile = path;
				XmlSerializer serializer = new XmlSerializer(typeof(MelissaDataConfig));
                Stream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
				_ConfigSingleton = (MelissaDataConfig)serializer.Deserialize(fs);
                fs.Close();
				if (string.IsNullOrEmpty(_ConfigSingleton.GeoLicenseCode))
					_ConfigSingleton.GeoLicenseCode = _ConfigSingleton.LicenseCode;
				if (string.IsNullOrEmpty(_ConfigSingleton.GeoDataFilePath))
					_ConfigSingleton.GeoDataFilePath = _ConfigSingleton.DataFilePath;
			}
			catch
            {
				_ConfigSingleton = new MelissaDataConfig();
            }
        }
    }

	public class MelissaDataValidator
	{
		public class ValidationStats
		{
			public int NumValidated = 0;
			public int NumFailed = 0;
			public int NumChanged = 0;
			public Dictionary<string, long> Details = new Dictionary<string, long>();
		}

		public ValidationStats AddressStats = new ValidationStats();
		public ValidationStats PhoneStats = new ValidationStats();
		public ValidationStats FaxStats = new ValidationStats();
		public ValidationStats NameStats = new ValidationStats();

		public void ResetStats()
		{
			if (AddressStats != null)
			{
				AddressStats.NumValidated = 0;
				AddressStats.NumFailed = 0;
				AddressStats.NumChanged = 0;
				AddressStats.Details.Clear();
			}
			if (PhoneStats != null)
			{
				PhoneStats.NumValidated = 0;
				PhoneStats.NumFailed = 0;
				PhoneStats.NumChanged = 0;
				PhoneStats.Details.Clear();
			}
			if (FaxStats != null)
			{
				FaxStats.NumValidated = 0;
				FaxStats.NumFailed = 0;
				FaxStats.NumChanged = 0;
				FaxStats.Details.Clear();
			}
			if (NameStats != null)
			{
				NameStats.NumValidated = 0;
				NameStats.NumFailed = 0;
				NameStats.NumChanged = 0;
				NameStats.Details.Clear();
			}
		}

		public void ClearCache()
		{
			if (AddressCache != null)
				AddressCache.ClearCache();
			if (PhoneCache != null)
				PhoneCache.ClearCache();
		}

		private mdAddr addrobj = null;
		private mdZip zipobj = null;
		private mdGeo geoobj = null;
		private mdPhone phoneobj = null;
		private mdEmail emailobj = null;
		private mdName nameobj = null;

		private CDCache<string> AddressCache = null;
		public long AddressCacheLookups { get { return AddressCache == null ? 0 : AddressCache.GetCount; } }
		public long AddressCacheHits { get { return AddressCache == null ? 0 : AddressCache.HitCount; } }
		public decimal AddressCacheHitRate { get { return AddressCacheLookups == 0 ? 0 : (decimal) AddressCacheHits * 100 / AddressCacheLookups; } }

		private CDCache<string> PhoneCache = null;
		public long PhoneCacheLookups { get { return PhoneCache == null ? 0 : PhoneCache.GetCount; } }
		public long PhoneCacheHits { get { return PhoneCache == null ? 0 : PhoneCache.HitCount; } }
		public decimal PhoneCacheHitRate { get { return PhoneCacheLookups == 0 ? 0 : (decimal) PhoneCacheHits * 100 / PhoneCacheLookups; } }

		private Dictionary<string, string> FIPStoSSA = null;

        private static MelissaDataConfig Config { get { return MelissaDataConfig.ConfigSingleton; } }

		public void Close()
        {
            if (addrobj != null)
                addrobj = null;
            if (zipobj != null)
                zipobj = null;
			if (geoobj != null)
				geoobj = null;
			if (phoneobj != null)
                phoneobj = null;
            if (emailobj != null)
                emailobj = null;
            if (nameobj != null)
                nameobj = null;
			AddressCache.ClearCache();
			PhoneCache.ClearCache();
		}

		public void Initialize()
        {
			//****Initialize Address Object Interface****//
			if (Config.AddressInit.ToUpper().Intersect("ADLSCRF").Count() != 0)
			{
				addrobj = new mdAddr();
				if (addrobj.SetLicenseString(Config.LicenseCode) == false)
					throw new Exception("Address object initialization failed: invalid license code");

				if (Config.AddressInit.ToUpper().Contains("A"))
					addrobj.SetPathToUSFiles(Config.DataFilePath);
				if (Config.AddressInit.ToUpper().Contains("D"))
					addrobj.SetPathToDPVDataFiles(Config.DataFilePath);
				if (Config.AddressInit.ToUpper().Contains("L"))
					addrobj.SetPathToLACSLinkDataFiles(Config.DataFilePath);
				if (Config.AddressInit.ToUpper().Contains("S"))
					addrobj.SetPathToSuiteLinkDataFiles(Config.DataFilePath);
				if (Config.AddressInit.ToUpper().Contains("C"))
					addrobj.SetPathToCanadaFiles(Config.DataFilePath);          //Canadian Address Add-on
				if (Config.AddressInit.ToUpper().Contains("R"))
					addrobj.SetPathToRBDIFiles(Config.DataFilePath);            //Residential Business Delivery Indicator Add-on
				if (Config.AddressInit.ToUpper().Contains("F"))
					addrobj.SetPathToSuiteFinderDataFiles(Config.DataFilePath); //AddressPlus Add-on (appends residential suites)

				if (addrobj.InitializeDataFiles() != mdAddr.ProgramStatus.ErrorNone)
					throw new Exception("Address object initialization failed: " + addrobj.GetInitializeErrorString());

				addrobj.SetUseUSPSPreferredCityNames(Config.AddressInit.ToUpper().Contains("K") ? 0 : 1);

				if (Config.AddressCacheSize > 0)
				{
					AddressCache = new CDCache<string>(Config.AddressCacheSize);
					PhoneCache = new CDCache<string>(Config.AddressCacheSize);
				}

				//****Initialize Address Object Zip Data Interface****//
				if (Config.AddressInit.ToUpper().Contains("Z"))
				{
					zipobj = new mdZip();
					if (zipobj.SetLicenseString(Config.LicenseCode) == false)
						throw new Exception("Zipcode object initialization failed: invalid license code");
					if (zipobj.Initialize(Config.DataFilePath, Config.DataFilePath, "") != 0)
						throw new Exception("Zipcode object initialization failed: " + zipobj.GetInitializeErrorString());
				}
			}

			//****Initialize Geocode Object Interface****//
			if (Config.AddressInit.ToUpper().Contains("G"))
			{
				geoobj = new mdGeo();
				if (geoobj.SetLicenseString(Config.GeoLicenseCode) == false)
					throw new Exception("Geocode object initialization failed: invalid license code");
				geoobj.SetPathToGeoCodeDataFiles(Config.GeoDataFilePath);
				if (Config.AddressInit.ToUpper().Contains("C"))
					geoobj.SetPathToGeoCanadaDataFiles(Config.DataFilePath);
				if (geoobj.InitializeDataFiles() != 0)
					throw new Exception("Geocode object initialization failed: " + geoobj.GetInitializeErrorString());
			}

			//****Initialize Phone Object Interface****//
			if (Config.AddressInit.ToUpper().Contains("P"))
			{
				phoneobj = new mdPhone();
				if (phoneobj.SetLicenseString(Config.LicenseCode) == false)
					throw new Exception("Phone object initialization failed: invalid license code");
				if (phoneobj.Initialize(Config.DataFilePath) != 0)
					throw new Exception("Phone object initialization failed: " + phoneobj.GetInitializeErrorString());
			}

            //****Initialize Email Object Interface****//
			if (Config.AddressInit.ToUpper().Contains("E"))
			{
				emailobj = new mdEmail();
				if (!emailobj.SetLicenseString(Config.LicenseCode))
					throw new Exception("Email object initialization failed: invalid license code");

				emailobj.SetPathToEmailFiles(Config.DataFilePath);
				if (emailobj.InitializeDataFiles() != mdEmail.ProgramStatus.ErrorNone)
					throw new Exception("Email object initialization failed: " + emailobj.GetInitializeErrorString());
			}

            //****Initialize Name Object Interface****//
            // TODO:  instantiating the mdName object throws an exception
            //nameobj = new mdName();
            //if (nameobj.SetLicenseString(Config.LicenseCode) == 0)
            //    throw new Exception("Name object initialization failed: invalid license code");
            //nameobj.SetPathToNameFiles(Config.DataFilePath);
            //if (nameobj.InitializeDataFiles() != mdName.ProgramStatus.NoError)
            //    throw new Exception("Name object initialization failed: " + nameobj.GetInitializeErrorString());

            //// Set processing options:
            //nameobj.SetPrimaryNameHint(mdName.NameHints.Varying);
            //nameobj.SetFirstNameSpellingCorrection(0);
            //nameobj.SetGenderAggression(mdName.Aggression.Conservative);
            //nameobj.SetMiddleNameLogic(mdName.MiddleNameLogic.MiddleName);

			if (string.IsNullOrEmpty(Config.CountyLookupFile) == false)
			{
				string LookupFile = Config.CountyLookupFile;
				if (string.IsNullOrEmpty(Path.GetDirectoryName(LookupFile)))
					LookupFile = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), LookupFile);
				if (File.Exists(LookupFile) == false)
					LookupFile = Path.Combine(Path.GetDirectoryName(MelissaDataConfig.ConfigFile), Config.CountyLookupFile);
				if (File.Exists(LookupFile) == false)
					throw new Exception("County lookup file not found - " + LookupFile);
				FIPStoSSA = new Dictionary<string, string>();
				StreamReader txtreader = new StreamReader(LookupFile);
				int code;
				while (!txtreader.EndOfStream)
				{
					string line = txtreader.ReadLine();
					string[] fields = line.Split('\t');
					if (fields.Count() == 6 && Int32.TryParse(fields[3], out code) && Int32.TryParse(fields[2], out code))
						FIPStoSSA[fields[3]] = fields[2];
				}
			}
		}

		public string GetInitInfo()
		{
			string info = "";

			info += string.Format("Config File: {0}\r\n", MelissaDataConfig.ConfigFile);
			info += string.Format("Data Path: {0}\r\n", Config.DataFilePath);
			info += string.Format("License: {0}\r\n", Config.LicenseCode.Substring(0, 10) + "...");
			info += string.Format("Config Options: {0}\r\n", Config.AddressInit);
			info += string.Format("Cache Size: {0}\r\n", Config.AddressCacheSize);
			if (addrobj != null)
			{
				info += "\r\n";
				info += string.Format("Address Error: {0}\r\n", addrobj.GetInitializeErrorString());
				info += string.Format("Address Buildnum: {0}\r\n", addrobj.GetBuildNumber());
				info += string.Format("Address Database: {0}\r\n", addrobj.GetDatabaseDate());
				info += string.Format("Address License: {0}\r\n", addrobj.GetLicenseExpirationDate());
			}
			if (geoobj != null)
			{
				info += "\r\n";
				info += string.Format("Geocode Error: {0}\r\n", geoobj.GetInitializeErrorString());
				info += string.Format("Geocode Buildnum: {0}\r\n", geoobj.GetBuildNumber());
				info += string.Format("Geocode Database: {0}\r\n", geoobj.GetDatabaseDate());
				info += string.Format("Geocode License: {0}\r\n", geoobj.GetLicenseExpirationDate());
			}
			if (phoneobj != null)
			{
				info += "\r\n";
				info += string.Format("Phoneobj Error: {0}\r\n", phoneobj.GetInitializeErrorString());
				info += string.Format("Phoneobj Buildnum: {0}\r\n", phoneobj.GetBuildNumber());
				info += string.Format("Phoneobj Database: {0}\r\n", phoneobj.GetDatabaseDate());
				info += string.Format("Phoneobj License: {0}\r\n", phoneobj.GetLicenseExpirationDate());
			}
			return info;
		}

		public void LogStatistics()
        {
        }

		public bool AddressVerify(CDAddress InputAddress, out CDAddress OutputAddress)
        {
            bool result = false;
			string[] Notes = null;

			// Check if the incoming address is in the cache
			if (AddressCache != null)
			{
				string value = AddressCache.GetFromCache(InputAddress.ToCacheKey());
				if (value != null)
				{
					OutputAddress = CDAddress.FromCacheValue(value);
					goto ReturnAddress;
				}
			}

			OutputAddress = new CDAddress();
			if (addrobj == null)
                throw new Exception("Address object is not initialized");

            //set input address
            addrobj.ClearProperties();
            addrobj.SetCompany(InputAddress.Company != null ? InputAddress.Company : string.Empty);
            addrobj.SetAddress(InputAddress.Line1 != null ? InputAddress.Line1 : string.Empty);
            addrobj.SetAddress2(InputAddress.Line2 != null ? InputAddress.Line2 : string.Empty);
            addrobj.SetCity(InputAddress.City != null ? InputAddress.City : string.Empty);
            addrobj.SetState(InputAddress.State != null ? InputAddress.State : string.Empty);
            addrobj.SetZip(InputAddress.Zip != null ? InputAddress.Zip : string.Empty);
            addrobj.SetLastName("");

            //verify address
            addrobj.VerifyAddress();

            OutputAddress.Company = addrobj.GetCompany();
            OutputAddress.Line1 = addrobj.GetAddress();
            OutputAddress.Line2 = addrobj.GetAddress2();
            OutputAddress.Suite = addrobj.GetSuite();
            OutputAddress.City = addrobj.GetCity();
            OutputAddress.State = addrobj.GetState();
            OutputAddress.Zip = addrobj.GetZip();
            OutputAddress.Plus4 = addrobj.GetPlus4();
            OutputAddress.Garbage = addrobj.GetParsedGarbage();
            OutputAddress.DeliveryPoint = addrobj.GetDeliveryPointCode();
            OutputAddress.County = addrobj.GetCountyName();
            OutputAddress.Country = addrobj.GetCountryCode();
			OutputAddress.FIPSCode = addrobj.GetCountyFips();
			if (FIPStoSSA != null)
				FIPStoSSA.TryGetValue(OutputAddress.FIPSCode, out OutputAddress.SSACode);

			string FullZip = OutputAddress.Zip + OutputAddress.Plus4 + OutputAddress.DeliveryPoint;
            if (FullZip.Length == 11)
                OutputAddress.Zip11 = FullZip;
            OutputAddress.Notes = addrobj.GetResults();
			OutputAddress.AddressType = GetAddressType(addrobj.GetAddressTypeCode());

			if (true)
			{
				string Sorted = "";
				List<string> SortedNotes = new List<string>();
				Notes = OutputAddress.Notes.Split(',');
				SortedNotes.AddRange(Notes.Where(x => x.StartsWith("AS")).OrderBy(x => x));
				SortedNotes.AddRange(Notes.Where(x => x.StartsWith("AE")).OrderBy(x => x));
				SortedNotes.AddRange(Notes.Where(x => x.StartsWith("AC")).OrderBy(x => x));
				foreach (string note in SortedNotes)
				{
					Sorted += (Sorted.Length > 0 ? "," : "") + note;
				}
				OutputAddress.Notes = Sorted;
			}

			// Determine where to put the suite info
			// First make sure the suite isn't already part of line 1 or 2
			if (!string.IsNullOrEmpty(OutputAddress.Suite))
			{
				string suite = OutputAddress.Suite.ToUpper();
				if (!OutputAddress.Line1.ToUpper().Contains(suite) && !OutputAddress.Line2.ToUpper().Contains(suite))
				{
					switch (Config.SuitePlacement.ToUpper())
					{
						case "1":
							OutputAddress.Line1 = OutputAddress.Suite;
							break;
						case "1R":
							OutputAddress.Line1 = OutputAddress.Line1 + (string.IsNullOrEmpty(OutputAddress.Line1) ? "" : ", ") + OutputAddress.Suite;
							break;
						case "1L":
							OutputAddress.Line1 = OutputAddress.Suite + (string.IsNullOrEmpty(OutputAddress.Line1) ? "" : ", ") + OutputAddress.Line1;
							break;
						case "2":
							OutputAddress.Line2 = OutputAddress.Suite;
							break;
						case "2R":
							OutputAddress.Line2 = OutputAddress.Line2 + (string.IsNullOrEmpty(OutputAddress.Line2) ? "" : ", ") + OutputAddress.Suite;
							break;
						case "2L":
							OutputAddress.Line2 = OutputAddress.Suite + (string.IsNullOrEmpty(OutputAddress.Line2) ? "" : ", ") + OutputAddress.Line2;
							break;
						case "NONE":
							break;
						default:
							if (string.IsNullOrEmpty(OutputAddress.Line2))
								OutputAddress.Line2 = OutputAddress.Suite;
							else if (string.IsNullOrEmpty(OutputAddress.Line1))
								OutputAddress.Line1 = OutputAddress.Suite;
							else
								OutputAddress.Line1 += " " + OutputAddress.Suite;
							break;
					}
				}
			}

			// Determine where to put the extraneous info
			// First make sure the garbage isn't already part of line 1 or 2
			if (!string.IsNullOrEmpty(OutputAddress.Garbage))
			{
				string garbage = OutputAddress.Garbage.ToUpper();
				if (!OutputAddress.Line1.ToUpper().Contains(garbage) && !OutputAddress.Line2.ToUpper().Contains(garbage))
				{
					switch (Config.GarbagePlacement.ToUpper())
					{
						case "1":
							OutputAddress.Line1 = OutputAddress.Garbage;
							break;
						case "1R":
							OutputAddress.Line1 = OutputAddress.Line1 + (string.IsNullOrEmpty(OutputAddress.Line1) ? "" : ", ") + OutputAddress.Garbage;
							break;
						case "1L":
							OutputAddress.Line1 = OutputAddress.Garbage + (string.IsNullOrEmpty(OutputAddress.Line1) ? "" : ", ") + OutputAddress.Line1;
							break;
						case "2":
							OutputAddress.Line2 = OutputAddress.Garbage;
							break;
						case "2R":
							OutputAddress.Line2 = OutputAddress.Line2 + (string.IsNullOrEmpty(OutputAddress.Line2) ? "" : ", ") + OutputAddress.Garbage;
							break;
						case "2L":
							OutputAddress.Line2 = OutputAddress.Garbage + (string.IsNullOrEmpty(OutputAddress.Line2) ? "" : ", ") + OutputAddress.Line2;
							break;
						case "NONE":
							break;
						case "PRESERVE":
							if (!string.IsNullOrEmpty(InputAddress.Line1) && InputAddress.Line1.ToUpper().StartsWith(garbage))
								OutputAddress.Line1 = OutputAddress.Garbage + " " + OutputAddress.Line1;
							else if (!string.IsNullOrEmpty(InputAddress.Line1) && InputAddress.Line1.ToUpper().Contains(garbage))
								OutputAddress.Line1 = OutputAddress.Line1 + " " + OutputAddress.Garbage;
							else if (!string.IsNullOrEmpty(InputAddress.Line2) && InputAddress.Line2.ToUpper().StartsWith(garbage))
								OutputAddress.Line2 = OutputAddress.Garbage + " " + OutputAddress.Line2;
							else if (!string.IsNullOrEmpty(InputAddress.Line2) && InputAddress.Line2.ToUpper().Contains(garbage))
								OutputAddress.Line2 = OutputAddress.Line2 + " " + OutputAddress.Garbage;
							else
								OutputAddress.Line2 = OutputAddress.Line2 + " " + OutputAddress.Garbage;
							break;
					}
				}
			}

			if (Config.AddressInit.ToUpper().Contains("Z") || Config.AddressInit.ToUpper().Contains("G"))
			{
				// Latitude/Longitude
				GetGeoCoordinates(OutputAddress);
			}

			// Add the result to the address cache 
		AddToCache:
			if (AddressCache != null)
			{
				string key = InputAddress.ToCacheKey();
				if (!string.IsNullOrEmpty(key))
					AddressCache.AddToCache(key, OutputAddress.ToCacheValue());
			}

		ReturnAddress:
            if ((OutputAddress.Notes.Contains("AS01")) || (OutputAddress.Notes.Contains("AS02")) || (OutputAddress.Notes.Contains("AS03")))
                result = true;

			// Make sure the statistics are compiled even if the output address came from the cache
			if (Config.EnableStatistics)
            {
				if (Notes == null)
					Notes = OutputAddress.Notes.Split(',');
				foreach (string note in Notes)
                {
                    if (AddressStats.Details.ContainsKey(note))
                        AddressStats.Details[note] += 1;
                    else
                        AddressStats.Details.Add(note, 1);
                }

				AddressStats.NumValidated++;
				if (OutputAddress.Notes.Contains("AC"))
					AddressStats.NumChanged++;
				if (result == false)
					AddressStats.NumFailed++;
			}

			return result;
        }

		public bool GetGeoCoordinates(CDAddress Address)
        {
			bool returnval = false;
            if (string.IsNullOrEmpty(Address.Zip))
                return false;

			if (geoobj == null)
			{
				if (zipobj == null)
					throw new Exception("Zip object is not initialized");
				string zip = Address.Zip.Length > 5 ? Address.Zip.Substring(0, 5) : Address.Zip;
				if (zipobj.FindZip(zip, false) != false)
				{
					Address.Latitude = zipobj.GetLatitude();
					Address.Longitude = zipobj.GetLongitude();
					Address.GeocodeType = GeocodeType.Zip5;
					returnval = true;
				}
			}
			else
			{
				if (geoobj.GeoCode(Address.Zip, Address.Plus4) != 0)
				{
					Address.Latitude = geoobj.GetLatitude();
					Address.Longitude = geoobj.GetLongitude();
					string result = geoobj.GetResults();
					Address.GeocodeType = GetGeocodeType(result);
					returnval = true;
				}
			}

			decimal testvalue;
			if (decimal.TryParse(Address.Latitude, out testvalue) == false || decimal.TryParse(Address.Longitude, out testvalue) == false)
			{
				Address.Latitude = "";
				Address.Longitude = "";
				Address.GeocodeType = GeocodeType.Unknown;
				returnval = false;
			}

			return returnval;
        }

        public bool PhoneVerify(CDPhone InputPhone, out CDPhone OutputPhone)
        {
			bool result = false;

			// Check if the incoming phone is in the cache
			if (PhoneCache != null)
			{
				string value = PhoneCache.GetFromCache(InputPhone.ToCacheKey());
				if (value != null)
				{
					OutputPhone = CDPhone.FromCacheValue(value);
					result = OutputPhone.IsValid();
					goto ReturnPhone;
				}
			}

			//if (MelissaDataMgr != null)
			//{
			//	result = MelissaDataMgr.PhoneVerify(InputPhone, out OutputPhone);
			//	goto ReturnPhone;
			//}

			OutputPhone = new CDPhone();
            if (phoneobj == null)
                throw new Exception("Phone object is not initialized");

            if (InputPhone.PhoneNumber == null) InputPhone.PhoneNumber = string.Empty;
            if (InputPhone.ZipCode == null) InputPhone.ZipCode = string.Empty;

			// attempt to fill in the area code if it's missing
			string zip = !string.IsNullOrEmpty(InputPhone.ZipCode) && InputPhone.ZipCode.Length >= 5 ? InputPhone.ZipCode.Substring(0, 5) : "";
			if (InputPhone.PhoneNumber.Length == 7 && !string.IsNullOrEmpty(zip))
            {
                if (phoneobj.CorrectAreaCode(InputPhone.PhoneNumber, InputPhone.ZipCode) == true)
                {
                    InputPhone.PhoneNumber = phoneobj.GetNewAreaCode() + InputPhone.PhoneNumber;
                }
            }

            result = phoneobj.Lookup(InputPhone.PhoneNumber, zip);

            OutputPhone.PhoneNumber = InputPhone.PhoneNumber;
            OutputPhone.Latitude = phoneobj.GetLatitude();
            OutputPhone.Longitude = phoneobj.GetLongitude();
            OutputPhone.City = phoneobj.GetCity();
            OutputPhone.State = phoneobj.GetState();
            OutputPhone.County = phoneobj.GetCountyName();
            OutputPhone.Country = phoneobj.GetCountryCode();
            OutputPhone.AreaCode = phoneobj.GetAreaCode();
            OutputPhone.Extension = phoneobj.GetExtension();
            OutputPhone.Prefix = phoneobj.GetPrefix();
            OutputPhone.Suffix = phoneobj.GetSuffix();
			OutputPhone.Result = result ? "Success" : "Failure";
			OutputPhone.Notes = phoneobj.GetResults();

            string ResultsString = OutputPhone.Notes;

			OutputPhone.PhoneType = GetPhoneType(ResultsString);
			OutputPhone.ExchangeType = GetPhoneExchange(ResultsString);

			// Add the result to the phone cache 
		AddToCache:
			if (PhoneCache != null)
			{
				string key = InputPhone.ToCacheKey();
				if (!string.IsNullOrEmpty(key))
					PhoneCache.AddToCache(key, OutputPhone.ToCacheValue());
			}

		ReturnPhone:
			if (Config.EnableStatistics)
            {
				ValidationStats stats = InputPhone.PhoneType == PhoneType.Fax ? FaxStats : PhoneStats;
                string[] Notes = OutputPhone.Notes.Split(',');
                foreach (string note in Notes)
                {
					if (stats.Details.ContainsKey(note))
						stats.Details[note] += 1;
                    else
						stats.Details.Add(note, 1);
                }

				stats.NumValidated++;
				if (string.Compare(InputPhone.ToString(), OutputPhone.ToString(), StringComparison.InvariantCultureIgnoreCase) != 0)
					stats.NumChanged++;
				if (result == false)
					stats.NumFailed++;
			}

            return result;
        }

        public bool EmailVerify(CDEmail InputEmail, out CDEmail OutputEmail)
        {
            throw new NotImplementedException();
        }

        public bool NameVerify(CDName InputName, out CDName OutputName)
        {
			bool result = false;

            OutputName = new CDName();
			if (nameobj == null)
                throw new Exception("Name object is not initialized");

            if (string.IsNullOrEmpty(InputName.FullName))
                InputName.FullName = InputName.ToString();
            nameobj.SetFullName(InputName.FullName);

            if (nameobj.Parse() == 1)
                result = true;

            OutputName.Prefix = nameobj.GetPrefix();
            if (InputName.FullName.Contains(OutputName.Prefix) == false)
                OutputName.Prefix = "";
            OutputName.First = nameobj.GetFirstName();
            OutputName.Middle = nameobj.GetMiddleName();
            OutputName.Last = nameobj.GetLastName();
            OutputName.Suffix = nameobj.GetSuffix();
            OutputName.Gender = nameobj.GetGender();
            OutputName.FullName = OutputName.ToString();
            OutputName.Notes = nameobj.GetResults();
            if (OutputName.Notes.Contains("NE"))
                result = false;

		ReturnName:
			if (Config.EnableStatistics)
            {
                string[] Notes = OutputName.Notes.Split(',');
                foreach (string note in Notes)
                {
                    if (NameStats.Details.ContainsKey(note))
                        NameStats.Details[note] += 1;
                    else
                        NameStats.Details.Add(note, 1);
                }

				NameStats.NumValidated++;
				if (string.Compare(InputName.ToString(), OutputName.ToString(), StringComparison.InvariantCultureIgnoreCase) != 0)
					NameStats.NumChanged++;
				if (result == false)
					NameStats.NumFailed++;
			}

            return result;
        }

        public bool PersonatorRequest(Personator.RequestData InputRequest)
        {
            InputRequest.CustomerID = Config.CustomerNumber;
			InputRequest.SaveXML = Config.SavePersonatorIO;
            return Personator.SendPersonatorRequest(InputRequest);
        }

		public static string GetDescription(string code) { Tuple<string, string> desc = null; return ResultCodes.TryGetValue(code, out desc) == false ? "" : desc.Item1; }
		public static string GetLongDescription(string code) { Tuple<string, string> desc = null; return ResultCodes.TryGetValue(code, out desc) == false ? "" : desc.Item2; }
		public static string GetTxDescription(string code) { Tuple<string, string> desc = null; return ResultCodes.TryGetValue(code, out desc) == false ? "" : desc.Item1; }
		public static string GetTxLongDescription(string code) { Tuple<string, string> desc = null; return ResultCodes.TryGetValue(code, out desc) == false ? "" : desc.Item2; }

		public static AddressType GetAddressType(string type)
		{
			switch (type)
			{
				case "F": return AddressType.Company;
				case "G": return AddressType.GeneralDelivery;
				case "H": return AddressType.HighRise;
				case "P": return AddressType.POBox;
				case "R": return AddressType.RuralRoute;
				case "S": return AddressType.Residential;
				//case "A": return Alias;
				//case "M": return Military Address;

				// Canadian types - not currently used
				//case "U": return Unique / LVR;
				//case "1": return Street;
				//case "2": return Street Served by Route and GD;
				//case "3": return Lock Box;
				//case "4": return Route Service;
				//case "5": return General Delivery;
				//case "B": return LVR Street;
				//case "C": return Government Street;
				//case "D": return LVR Lock Box;
				//case "E": return Government Lock Box;
				//case "L": return LVR General Delivery;
				//case "K": return Building;
			}
			return AddressType.Unknown;
		}

		public static GeocodeType GetGeocodeType(string type)
		{
			if (type.Contains("GS01"))
				return GeocodeType.Zip9;
			else if (type.Contains("GS02"))
				return GeocodeType.Zip7;
			else if (type.Contains("GS03"))
				return GeocodeType.Zip5;
			else if (type.Contains("GS05") || type.Contains("GS06"))
				return GeocodeType.Zip11;
			return GeocodeType.Unknown;
		}

		public static PhoneType GetPhoneType(string type)
		{
			if (type.Contains("PS10"))
				return PhoneType.Residential;
			else if (type.Contains("PS11"))
				return PhoneType.Business;
			else if (type.Contains("PS12"))
				return PhoneType.HomeOffice;
			else if (type.Contains("PS13"))
				return PhoneType.TollFree;
			else if (type.Contains("PS14"))
				return PhoneType.Special;
			return PhoneType.Unknown;
		}

		public static ExchangeType GetPhoneExchange(string type)
		{
			if (type.Contains("PS07"))
				return ExchangeType.Cellular;
			else if (type.Contains("PS08"))
				return ExchangeType.Land;
			else if (type.Contains("PS09"))
				return ExchangeType.Voip;
			return ExchangeType.Unknown;
		}

		private static Dictionary<string, Tuple<string, string>> ResultCodes = new Dictionary<string, Tuple<string, string>>()
		{
			{ "AS01", new Tuple<string, string>("Valid Address", "The address is valid and deliverable according to official postal agencies.") },
			{ "AS02", new Tuple<string, string>("Street Only Match", "The street address was verified but the suite/apartment number is missing or invalid.") },
			{ "AS03", new Tuple<string, string>("Non USPS Address Match", "US Only. This US address is not serviced by the USPS but does exist and may receive mail through third party carriers like UPS.") },
			{ "AS09", new Tuple<string, string>("Foreign Address", "The address is in a non-supported country.") },
			{ "AS10", new Tuple<string, string>("CMRA Address", "US Only. The address is a Commercial Mail Receiving Agency (CMRA) like a Mailboxes Etc. These addresses include a Private Mail Box (PMB or #) number.") },
			{ "AS11", new Tuple<string, string>("PBSA Address", "A PO Box formatted as a street address for package and mail delivery.") },
			{ "AS12", new Tuple<string, string>("Moved to New Address", "The record moved to a new address.") },
			{ "AS13", new Tuple<string, string>("Address Updated By LACS", "US Only. The address has been converted by LACSLink® from a rural-style address to a city-style address.") },
			{ "AS14", new Tuple<string, string>("Suite Appended", "US Only. A suite was appended by SuiteLink™ using the address and company name.") },
			{ "AS15", new Tuple<string, string>("Apartment Appended", "An apartment number was appended by AddressPlus using the address and last name.") },
			{ "AS16", new Tuple<string, string>("Vacant Address", "US Only. The address has been unoccupied for more than 90 days.") },
			{ "AS17", new Tuple<string, string>("No USPS Mail Delivery", "This address is classified as not receiving mail by the USPS via their No-Stat flag. Delivery might still be possible by third party carriers but that cannot be counted on.") },
			{ "AS20", new Tuple<string, string>("Deliverable only by USPS", "US Only. This address can only receive mail delivered through the USPS (i.e. PO Box or a military address).") },
			{ "AS23", new Tuple<string, string>("Extraneous Information", "Extraneous information not used in verifying the address was found. This includes unnecessary sub premises and other unrecognized data. Additional information will either be parsed into the Suite or Parsed Garbage/AddressExtras output.") },
			{ "AS24", new Tuple<string, string>("USPS Door Not Accessible", "Address identified by the USPS where carriers cannot physically access a building or door for mail delivery.") },
			{ "AE01", new Tuple<string, string>("Postal Code Error/General Error", "The address could not be verified at least up to the postal code level.") },
			{ "AE02", new Tuple<string, string>("Unknown Street", "Could not match the input street to a unique street name. Either no matches or too many matches found.") },
			{ "AE03", new Tuple<string, string>("Component Mismatch Error", "The combination of directionals (N, E, SW, etc) and the suffix (AVE, ST, BLVD) is not correct and produced multiple possible matches.") },
			{ "AE04", new Tuple<string, string>("Non-Deliverable Address", "US Only. A physical plot exists but is not a deliverable addresses. One example might be a railroad track or river running alongside this street, as they would prevent construction of homes in that location.") },
			{ "AE05", new Tuple<string, string>("Multiple Match", "The address was matched to multiple records. There is not enough information available in the address to break the tie between multiple records.") },
			{ "AE06", new Tuple<string, string>("Early Warning System", "US Only. This address currently cannot be verified but was identified by the Early Warning System (EWS) as belonging to a upcoming area and will likely be included in a future update.") },
			{ "AE07", new Tuple<string, string>("Missing Minimum Address", "Minimum requirements for the address to be verified is not met. A country input is required for global products. For US/CA, a postal code or city/state are required. Requirements for other countries may be different.") },
			{ "AE08", new Tuple<string, string>("Sub Premise Number Invalid", "An address element after the house number, in most cases the sub-premise, was not valid.") },
			{ "AE09", new Tuple<string, string>("Sub Premise Number Missing", "An address element after the house number, in most cases the sub-premise, was missing.") },
			{ "AE10", new Tuple<string, string>("Premise Number Invalid", "The premise (house or building) number for the address is not valid.") },
			{ "AE11", new Tuple<string, string>("Premise Number Missing", "The premise (house or building) number for the address is missing.") },
			{ "AE12", new Tuple<string, string>("Box Number Invalid", "The PO (Post Office Box), RR (Rural Route), or HC (Highway Contract) Box number is invalid.") },
			{ "AE13", new Tuple<string, string>("Box Number Missing", "The PO (Post Office Box), RR (Rural Route), or HC (Highway Contract) Box number is missing.") },
			{ "AE14", new Tuple<string, string>("PMB Number Missing", "US Only. The address is a Commercial Mail Receiving Agency (CMRA) and the Private Mail Box (PMB or #) number is missing.") },
			{ "AE17", new Tuple<string, string>("Sub Premise Not Required (Deprecated)", "A sub premise (suite) number was entered but the address does not have secondaries. (Deprecated - See AS23)") },
			{ "AE21", new Tuple<string, string>("MAK Not Found", "The input MAK was not found. This can be caused by an improperly formatted MAK (a proper MAK is 10 numerical digits long) or by requesting a MAK number that has not yet been assigned to a location.") },
			{ "AC01", new Tuple<string, string>("Postal Code Change", "The postal code was changed or added.") },
			{ "AC02", new Tuple<string, string>("Administrative Area Change", "The administrative area (state, province) was added or changed.") },
			{ "AC03", new Tuple<string, string>("Locality Change", "The locality (city, municipality) name was added or changed.") },
			{ "AC04", new Tuple<string, string>("Alternate to Base Change", "US Only. The address was found to be an alternate record and changed to the base (preferred) version.") },
			{ "AC05", new Tuple<string, string>("Alias Name Change", "US Only. An alias is a common abbreviation for a long street name, such as “MLK Blvd” for “Martin Luther King Blvd.” This change code indicates that the full street name (preferred) has been substituted for the alias.") },
			{ "AC06", new Tuple<string, string>("Address1/Address2 Swap", "Address1 was swapped with Address2 because Address1 could not be verified and Address2 could be verified.") },
			{ "AC07", new Tuple<string, string>("Address1 & Company Swapped", "Address1 was swapped with Company because only Company had a valid address.") },
			{ "AC08", new Tuple<string, string>("Plus4 Change", "US Only. A non-empty plus4 was changed.") },
			{ "AC09", new Tuple<string, string>("Dependent Locality Change", "The dependent locality (urbanization) was changed.") },
			{ "AC10", new Tuple<string, string>("Thoroughfare Name Change", "The thoroughfare (street) name was added or changed due to a spelling correction.") },
			{ "AC11", new Tuple<string, string>("Thoroughfare Type Change", "The thoroughfare (street) leading or trailing type was added or changed, such as from 'St' to 'Rd'") },
			{ "AC12", new Tuple<string, string>("Thoroughfare Directional Change", "The thoroughfare (street) pre-directional or post-directional was added or changed, such as from 'N' to 'NW'") },
			{ "AC13", new Tuple<string, string>("Sub Premise Type Change", "The sub premise (suite) type was added or changed, such as from “STE” to “APT.”") },
			{ "AC14", new Tuple<string, string>("Sub Premise Number Change", "The sub premise (suite) unit number was added or changed.") },
			{ "AC20", new Tuple<string, string>("House Number Change", "The house number was changed.") },

			{ "GS01", new Tuple<string, string>("Geocoded to Street Level", "The record was coded to the street level (Zip+4 for US, full postal code for CA).") },
			{ "GS03", new Tuple<string, string>("Geocoded to Community Level", "The record was coded to the community level (ZIP centroid for US, 3-digit postal code for CA).") },
			{ "GS05", new Tuple<string, string>("Geocoded to Rooftop Level", "The record was geocoded down to the rooftop level, meaning the point is within the property boundaries, usually the center.") },
			{ "GS06", new Tuple<string, string>("Geocoded to Interpolated Rooftop Level", "The record was geocoded down to the rooftop level using interpolation (educated estimations using street coordinates). The point may be in or close to the property boundaries.") },
			{ "GS10", new Tuple<string, string>("Wire Center Lat/Long", "The latitude and longitude are based off of the wire center of the phone number.") },
			{ "GE01", new Tuple<string, string>("Invalid Postal Code", "The submitted postal code is not in a valid format.") },
			{ "GE02", new Tuple<string, string>("Postal Code Coordinates Not Found", "The submitted postal code coordinates were not found in the Geocode database.") },

			{ "PS01", new Tuple<string, string>("Valid Phone", "The phone number is valid.") },
			{ "PS02", new Tuple<string, string>("7-Digit Match", "The first 7-digits of the phone number have been verified, but activity cannot be confirmed.") },
			{ "PS03", new Tuple<string, string>("Corrected Area Code", "NewAreaCode contains corrected area code that was changed according to the postal code it falls into.") },
			{ "PS06", new Tuple<string, string>("Updated Area Code", "The area code was changed due to an area code split. The updated code is located within NewAreaCode.") },
			{ "PS07", new Tuple<string, string>("Cellular Line", "(US/CA Only) On activation, the exchange type of the phone number was designated as a cellular number, but current status cannot be confirmed.") },
			{ "PS08", new Tuple<string, string>("Land Line", "(US/CA Only) On activation, the exchange type of the phone number was designated as a land line, but current status cannot be confirmed.") },
			{ "PS09", new Tuple<string, string>("VOIP Line", "On activation, the exchange type of the phone number was designated as a VOIP line, but current status cannot be confirmed.") },
			{ "PS10", new Tuple<string, string>("Residential Number", "Phone number found in Personator database.") },
			{ "PS11", new Tuple<string, string>("Business Number", "Phone number found in Business database.") },
			{ "PS12", new Tuple<string, string>("SOHO Number", "The phone number belongs to a small office or home office.") },
			{ "PE01", new Tuple<string, string>("Invalid Phone", "The area code/phone number does not exist in our database or contains non-numbers.") },
			{ "PE02", new Tuple<string, string>("Blank Phone", "The phone number is blank.") },
			{ "PE03", new Tuple<string, string>("Bad Phone", "The phone number has too many or too few digits.") },
			{ "PE04", new Tuple<string, string>("Multiple Match", "Two or more possible area codes are available as a fix and their distance is too close to choose one over the other.") },
			{ "PE05", new Tuple<string, string>("Bad Prefix/Prefix +1", "The phone prefix or first 7-digits do not exist in our database.") },

			{ "ES01", new Tuple<string, string>("Valid Email", "This email was confirmed to be a valid email.") },
			{ "ES02", new Tuple<string, string>("Invalid Email (Deprecated)", "(Deprecated) This email was confirmed to be a invalid email.") },
			{ "ES03", new Tuple<string, string>("Unknown Email", "This email's status is unknown due to unknown external factors. Please try again another time.") },
			{ "ES04", new Tuple<string, string>("Mobile Email Address", "The domain name was identified as a mobile email address and classified as not deliverable by the FCC.") },
			{ "ES05", new Tuple<string, string>("Disposable Domain", "The domain name of the submitted email was identified as a disposable domain.") },
			{ "ES06", new Tuple<string, string>("Spamtrap Domain", "The domain of the submitted email was identified as a spamtrap. Mailing to this domain could result in the sender being blacklisted.") },
			{ "ES07", new Tuple<string, string>("Accept All Server", "The mail server is an accept all server. Accept-All domains is set in a way that makes all emails seem valid.") },
			{ "ES10", new Tuple<string, string>("Syntax Changed", "The syntax of the submitted email address was changed.") },
			{ "ES11", new Tuple<string, string>("Top Level Domain Changed", "The top level domain of the submitted email address was changed.") },
			{ "ES12", new Tuple<string, string>("Domain Changed (Spelling)", "The domain of the submitted email address was corrected for spelling.") },
			{ "ES13", new Tuple<string, string>("Domain Changed (Update)", "The domain of the submitted email address was updated due to a domain name change.") },
			{ "ES21", new Tuple<string, string>("Verify (Cached Mailbox Result)", "The email status was found in our database of cached emails.") },
			{ "EE01", new Tuple<string, string>("Email Syntax Error", "There is a syntax error in the submitted email address.") },
			{ "EE02", new Tuple<string, string>("Email Domain Not Found", "A Domain of the submitted email address was not found.") },
			{ "EE03", new Tuple<string, string>("Email Server Not Found", "The mail server of the submitted email address was not found.") },
			{ "EE04", new Tuple<string, string>("Invalid Email", "An invalid email mailbox was detected (i.e. noreply).") },

			{ "NS01", new Tuple<string, string>("Name Parsed", "Name parsing was successful.") },
			{ "NS02", new Tuple<string, string>("Error Parsing", "An error was detected. Please check for a name error code.") },
			{ "NS03", new Tuple<string, string>("First Name Spelling Corrected", "The spelling in the first name field was corrected.") },
			{ "NS04", new Tuple<string, string>("First Name 2 Spelling Corrected", "The spelling in the second first name field was corrected.") },
			{ "NS05", new Tuple<string, string>("First Name 1 Found", "FirstName1 was found in our census table of names. Very likely to be a real first name.") },
			{ "NS06", new Tuple<string, string>("Last Name 1 Found", "LastName1 was found in our census table of names. Very likely to be a real last name.") },
			{ "NS07", new Tuple<string, string>("First Name 2 Found", "FirstName2 was found in our census table of names. Very likely to be a real first name.") },
			{ "NS08", new Tuple<string, string>("Last Name 2 Found", "LastName2 was found in our census table of names. Very likely to be a real last name.") },
			{ "NE01", new Tuple<string, string>("Unrecognized Format", "Two names were detected but the FullName string was not in a recognized format.") },
			{ "NE02", new Tuple<string, string>("Multiple First Names Detected", "Multiple first names were detected and could not be accurately genderized.") },
			{ "NE03", new Tuple<string, string>("Vulgarity Detected", "A vulgarity was detected in the name.") },
			{ "NE04", new Tuple<string, string>("Suspicious Word Detected", "The name contained words found on the list of nuisance names, such as 'Mickey Mouse'.") },
			{ "NE05", new Tuple<string, string>("Company Name Detected", "The name contained words normally found in a company name.") },
			{ "NE06", new Tuple<string, string>("Non-Alphabetic Character Detected", "The name contained a non-alphabetic character.") },

			{ "DA00", new Tuple<string, string>("Address Appended", "An address was changed or appended.") },
			{ "DA01", new Tuple<string, string>("City/State Append from Phone", "A city or state was appended from a phone number wire center.") },
			{ "DA10", new Tuple<string, string>("Name Appended", "A full name was changed or appended.") },
			{ "DA20", new Tuple<string, string>("Company Appended", "A company name was changed or appended.") },
			{ "DA30", new Tuple<string, string>("Phone Appended", "A phone number was changed or appended.") },
			{ "DA40", new Tuple<string, string>("Email Appended", "An email address was changed or appended.") },
			{ "VR01", new Tuple<string, string>("Name and Address Match", "The name and address match.") },
			{ "VR02", new Tuple<string, string>("Name and Phone Match", "The name and phone match.") },
			{ "VR03", new Tuple<string, string>("Name and Email Match", "The name and email match.") },
			{ "VR04", new Tuple<string, string>("Address and Phone Match", "The address and phone match.") },
			{ "VR05", new Tuple<string, string>("Address and Email Match", "The address and email match.") },
			{ "VR06", new Tuple<string, string>("Phone and Email Match", "The phone and email match.") },
			{ "VR07", new Tuple<string, string>("Company and Address Match", "The company and address match.") },
			{ "VR08", new Tuple<string, string>("Company and Phone Match", "The company and phone match.") },
			{ "VR09", new Tuple<string, string>("Company and Email Match", "The company and email match.") },
			{ "VR10", new Tuple<string, string>("Company and Name Match", "The company and name match.") },
			{ "VR11", new Tuple<string, string>("Name and SSN Match", "Matched the name field to the Social Security Number.") },
			{ "VS00", new Tuple<string, string>("Contact Record Not Found", "The record was not found in our contact database. We are unable to verify any information about the residents of this address.") },
			{ "VS01", new Tuple<string, string>("Historical Address Match", "The current address is outdated and a newer address match was found. Use the 'Move' action to get the latest address.") },
			{ "VS02", new Tuple<string, string>("Partial Address Match", "A match was made to a partial address. This could be due to matching the street address but not to the suite.") },
			{ "VS12", new Tuple<string, string>("Last Name Match", "A match was made to the last name only.") },
			{ "VS13", new Tuple<string, string>("First Name Match", "A match was made to the first name only.") },
			{ "VS22", new Tuple<string, string>("Partial Company Name Match", "A match was made to a partial company name.") },
			{ "VS30", new Tuple<string, string>("Phone Not Found", "A phone number was not found in the reference data.") },
			{ "VS31", new Tuple<string, string>("Historical Phone Match", "The current phone number is outdated and a newer phone number match was found. Use the 'Append' action to get the latest phone number.") },
			{ "VS40", new Tuple<string, string>("Email Not Found", "An email address was not found in the reference data.") },
			{ "VS41", new Tuple<string, string>("Historical Email Address", "The current email address is outdated and a newer email address match was found. Use the 'Append' action to get the latest email address.") },
			{ "VS50", new Tuple<string, string>("Last4 Only Match", "The name only matched to the last 4 digits of the Social Security Number.") },
			{ "SN01", new Tuple<string, string>("Invalid SSN Format", "The format of your Social Security Number was invalid.") },
			{ "SP01", new Tuple<string, string>("No Action", "A record was sent in, but the service did not have enough information to modify the record.") },
		};

		private static Dictionary<string, Tuple<string, string>> TransmissionCodes = new Dictionary<string, Tuple<string, string>>()
		{
			{ "SE01", new Tuple<string, string>("Cloud Service Internal Error", "The cloud service experienced an internal error.") },
			{ "GW01", new Tuple<string, string>("Expiring License", "Your License Key is expiring soon. Please contact your sales representative for a new License Key.") },
			{ "GW11", new Tuple<string, string>("Option Name Error", "The option name is either misspelled or incorrect.") },
			{ "GW12", new Tuple<string, string>("Option Value Error", "The option value is misspelled or incorrectly formatted.") },
			{ "GE01", new Tuple<string, string>("Empty Request Structure", "The SOAP, JSON, or XML request structure is empty. Not to be confused with the GE01 GeoCode result code.") },
			{ "GE02", new Tuple<string, string>("Empty Request Record Structure", "The SOAP, JSON, or XML request record structure is empty. Not to be confused with the GE02 GeoCode result code.") },
			{ "GE03", new Tuple<string, string>("Records Per Request Exceeded", "The counted records sent more than the number of records allowed per request.") },
			{ "GE04", new Tuple<string, string>("Empty License Key", "The License Key is empty.") },
			{ "GE05", new Tuple<string, string>("Invalid License Key", "The required license string is missing or invalid. Use the Credits License on the My Account page or call Tech Support 1-800-Melissa.") },
			{ "GE06", new Tuple<string, string>("Disabled License Key", "The License Key is disabled.") },
			{ "GE07", new Tuple<string, string>("Invalid Request", "The SOAP, JSON, or XML request is invalid.") },
			{ "GE08", new Tuple<string, string>("Product/Level Not Enabled", "The License Key is invalid for this product or level.") },
			{ "GE09", new Tuple<string, string>("Customer Does Not Exist", "The Customer ID is not in our system.") },
			{ "GE10", new Tuple<string, string>("Customer License Disabled", "The encrypted license is on the ban list.") },
			{ "GE11", new Tuple<string, string>("Customer Disabled", "The Customer ID is disabled.") },
			{ "GE12", new Tuple<string, string>("IP Blacklisted", "The IP Address is on the global ban list.") },
			{ "GE13", new Tuple<string, string>("IP Not Whitelisted", "The IP Address is not on the customer's whitelist.") },
			{ "GE14", new Tuple<string, string>("Out of Credits", "The account has ran out of credits. Add more credits to continue using the service. https://www.melissa.com/pricing/purchase") },
			{ "GE20", new Tuple<string, string>("Verify Not Activated", "The Verify package was requested but is not active for the License Key.") },
			{ "GE21", new Tuple<string, string>("Append Not Activated", "The Append package was requested but is not active for the License Key.") },
			{ "GE22", new Tuple<string, string>("Move Not Activated", "The Move package was requested but is not active for the License Key.") },
			{ "GE23", new Tuple<string, string>("No Valid Action Requested", "No valid action was requested by the service. The request must include at least one of the following actions: Check, Verify, Append, or Move.") },
			{ "GE24", new Tuple<string, string>("Demographics Not Activated", "The Demographics package was requested but is not active for the License Key.") },
			{ "GE27", new Tuple<string, string>("IP Columns Not Activated", "IP Columns requested but not active for the customer ID.") },
			{ "GE28", new Tuple<string, string>("SSN Verification Not Activated", "SSN Verification requested but not active for the customer ID.") },
			{ "GE29", new Tuple<string, string>("Not Available for Credit License", "The requested fields were not available for a credit license. To have access to the demographics fields, please upgrade your license to a subscription.") },
		};
	}
}
