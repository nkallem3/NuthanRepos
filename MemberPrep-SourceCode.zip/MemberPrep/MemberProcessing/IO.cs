﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace MemberProcessing
{
    public delegate bool QueryLineSkip(string Line);

	public class FieldDefinition
	{
		public string ExternalFieldName = "";
		public string InternalFieldName = "";
		public int MaxLength = 0;
		public int MaxMissingPercent = -1;
		public int MaxInvalidPercent = -1;
	}

	public class FormatFile
	{
		public string FieldDelimiter = "|";
		public List<FieldDefinition> FieldDefinitions = new List<FieldDefinition>();

		public static FormatFile Load(string Filename)
		{
			FormatFile format = null;

			using (Stream fs = new FileStream(Filename, FileMode.Open, FileAccess.Read))
			{
				XmlSerializer serializer = new XmlSerializer(typeof(FormatFile));
				format = (FormatFile) serializer.Deserialize(fs);
			}

			return format;
		}

		public string GetHeader()
		{
			string OutputLine = "";
			foreach (FieldDefinition FieldDef in FieldDefinitions)
			{
				string OutputFieldValue = FieldDef.ExternalFieldName;
				OutputLine += string.IsNullOrEmpty(OutputLine) ? OutputFieldValue : FieldDelimiter + OutputFieldValue;
			}
			return OutputLine;
		}
	}

	public abstract class DataIOReader
    {
		public abstract void Initialize();
		public abstract int GetOrdinal(string Name);
		public abstract bool Read(string NullString);
		public abstract string GetString(int Ordinal);
		public abstract bool IsRowValid(int? StrictColumnCount);

		public Stream Connection { get; set; }
		public bool HeaderPresent { get; set; }
        public bool FooterPresent { get; set; }
        public string HeaderLine { get; set; }
        public string FooterLine
		{
            get
            {
                if (!EndOfStream()) return string.Empty;
                return _FooterLine;
            }
        }
		public long RecordID { get { return _RecordID; } }
		public QueryLineSkip QueryHeaderSkip { get; set; }
        public QueryLineSkip QueryFooterSkip { get; set; }
		public string ExtraInfoMarker { get; set; }
		public string ExtraInfoLine { get; set; }
		public bool ExtraInfoPresent { get; set; }
		public bool IsDBNull(int Ordinal)
		{
			return false;
		}

		private StreamReader myReader;

        private long _RecordID = 0;
		private string _NextLine;
        private string _FooterLine;
        private string _CurrentLine;

        internal string CurrentLine
        {
            get
            {
                return _CurrentLine;
            }
        }

        internal string readNonBlankLine()
        {
            while (!myReader.EndOfStream)
            {
                string LINE = myReader.ReadLine();
                if (LINE.Trim() == string.Empty) continue;
                _RecordID++;
                return LINE;
            }
            // end of file
            return string.Empty;
        }

        public string ReadNextLine()
        {
            string Result = _NextLine;
            _NextLine = _FooterLine;
            _FooterLine = readNonBlankLine();
            if (_FooterLine == string.Empty)
            {
                // check result
                if (!string.IsNullOrEmpty(Result))
                {
                    // we read data from cache
                    _RecordID++;
                }
                // check
                if (FooterPresent)
                {
                    bool skipFooter = true;
                    if (QueryFooterSkip != null)
                    {
                        skipFooter = QueryFooterSkip(_NextLine);
                    }
                    if (skipFooter)
                    {
                        _FooterLine = _NextLine;
                        _NextLine = string.Empty;
                    }
                }
            }
            _CurrentLine = Result;
            return Result;
        }

        public bool EndOfStream()
        {
            if (_NextLine == string.Empty) return true;
            return false;
        }

        internal void InitializeReader()
        {
			myReader = new StreamReader(Connection);
            _NextLine = readNonBlankLine();
			HeaderLine = _NextLine;
			_FooterLine = readNonBlankLine();
            _RecordID = 0;

			// check for a line of extra info in the file (must be first line in file)
			// the default marker is "<<<<<...>>>>>" but a config file may override that
			string ExtraInfoBegin = null;
			string ExtraInfoEnd = null;
			if (ExtraInfoMarker == null)
			{
				ExtraInfoBegin = "<<<<<";
				ExtraInfoEnd = ">>>>>";
			}
			else if (ExtraInfoMarker.Length > 0)
			{
				ExtraInfoBegin = ExtraInfoMarker;
				ExtraInfoEnd = ExtraInfoMarker;
			}
			if (ExtraInfoBegin != null && _NextLine.StartsWith(ExtraInfoBegin) && _NextLine.EndsWith(ExtraInfoEnd))
			{
				ExtraInfoLine = _NextLine;
				ExtraInfoLine = ExtraInfoLine.Substring(ExtraInfoBegin.Length);
				ExtraInfoLine = ExtraInfoLine.Substring(0, Math.Max(ExtraInfoLine.Length - ExtraInfoBegin.Length, 0));
				_NextLine = _FooterLine;
				HeaderLine = _NextLine;
				_FooterLine = readNonBlankLine();
				ExtraInfoPresent = true;
			}
			else
			{
				ExtraInfoPresent = false;
			}

			if (HeaderPresent)
            {
                // query
                bool SkipHeader = true;
                if (QueryHeaderSkip != null)
                {
                    SkipHeader = QueryHeaderSkip(_NextLine);
                }
				if (SkipHeader)
				{
					HeaderLine = ReadNextLine();
				}
				else
				{
					HeaderLine = null;
				}
            }
        }
    }

    public class IODelimitedReader : DataIOReader
    {
        public string Delimiter { get; set; }
        public string EscapeSequence { get; set; }
        public string QuotedSequence { get; set; }
        private List<string> RowData = new List<string>();

        Dictionary<string, int> NameToOrdinal = new Dictionary<string, int>();

        public List<string> GetKnownFields()
        {
            return new List<string>(NameToOrdinal.Keys);
        }

        private List<string> SplitLine(string Line)
        {
            if (string.IsNullOrEmpty(QuotedSequence))
            {
                return new List<string>(Line.Split(new string[] { Delimiter }, StringSplitOptions.None));
            }
            // ok harder
            bool Quoted = false;
            string CurrentField = string.Empty;
            List<string> Result = new List<string>();
            int Index = 0;
            while (Index < Line.Length)
            {
                if (Line.Length - Index >= QuotedSequence.Length)
                {
                    // check
                    if (Line.Substring(Index, QuotedSequence.Length) == QuotedSequence)
                    {
                        // check
                        Quoted = !Quoted;
                        CurrentField += Line.Substring(Index, QuotedSequence.Length);
                        Index += QuotedSequence.Length;
                        continue;
                    }
                }
                if (!Quoted)
                {
                    if (Line.Length - Index >= Delimiter.Length)
                    {
                        if (Line.Substring(Index, Delimiter.Length) == Delimiter)
                        {
                            // got delimiter
                            Index += Delimiter.Length;
                            Result.Add(CurrentField);
                            CurrentField = string.Empty;
                            continue;
                        }
                    }
                }
                // just add
                CurrentField += Line[Index];
                Index++;
            }
            Result.Add(CurrentField);
            return Result;
        }

        private List<string> SplitLineByRules(string Line, string NullString)
        {
            if (EscapeSequence == string.Empty)
            {
                // easy
                List<string> Split = SplitLine(Line);
                List<string> Result = new List<string>();
                foreach (string VAL in Split)
                {
                    string trimmed = VAL.Trim();
                    trimmed = trimmed.TrimEnd(new char[] { '\0' });
                    // and adjust for quoted sequence
                    if (!string.IsNullOrEmpty(QuotedSequence))
                    {
                        if (trimmed.StartsWith(QuotedSequence))
                        {
                            trimmed = trimmed.Substring(QuotedSequence.Length);
                        }
                        if (trimmed.EndsWith(QuotedSequence))
                        {
                            trimmed = trimmed.Substring(0, trimmed.Length - QuotedSequence.Length);
                        }
                        trimmed = trimmed.Trim();
                    }
                    if (!string.IsNullOrEmpty(NullString))
                    {
                        if (trimmed == NullString)
                        {
                            trimmed = string.Empty;
                        }
                    }
                    Result.Add(trimmed);
                }
                return Result;
            }
            // now for the complicated with escaping
            throw new ApplicationException("NOT YET IMPLEMENTED");
        }

        public void Initialize(string HeaderOverride = null)
        {
            // check if we have header
            base.InitializeReader();
            // now populate NameToOrdinal
            NameToOrdinal.Clear();
            string LineToSplit = null;
            if (!string.IsNullOrEmpty(HeaderOverride))
            {
                LineToSplit = HeaderOverride;
            }
            else if (!string.IsNullOrEmpty(HeaderLine))
			{
                LineToSplit = HeaderLine;
            }
			if (!string.IsNullOrEmpty(LineToSplit))
			{
				RowData.Clear();
				RowData = SplitLineByRules(LineToSplit, string.Empty);
				for (int Index = 0; Index < RowData.Count; Index++)
				{
					string HEAD = RowData[Index].ToUpperInvariant().Trim();
					if (NameToOrdinal.ContainsKey(HEAD) == false)
						NameToOrdinal.Add(HEAD, Index);
				}
			}
        }

        public void AddAliasHeader(string Alias, string OriginalName)
        {
            int VALUE = GetOrdinal(OriginalName);
            string UPPER = Alias.ToUpperInvariant().Trim();
            NameToOrdinal[UPPER] = VALUE;
        }

		#region DataIOReader Members

		public override void Initialize()
		{
			Initialize(null);
		}

		public override int GetOrdinal(string Name)
        {
            string UPPER = Name.ToUpperInvariant().Trim();
            int VALUE;
            if (!NameToOrdinal.TryGetValue(UPPER, out VALUE))
            {
                throw new ApplicationException("Name not found");
            }
            return VALUE;
        }

        public override bool Read(string NullString)
        {
            RowData.Clear();
            if (base.EndOfStream()) return false;
            RowData = SplitLineByRules(base.ReadNextLine(), NullString);
            return true;
        }

        public override string GetString(int Ordinal)
        {
            if (Ordinal >= RowData.Count) return string.Empty;
            return RowData[Ordinal];
        }

        public override bool IsRowValid(int? StrictColumnCount)
        {
			// check if specified
			if (StrictColumnCount.HasValue)
			{
				if (StrictColumnCount.Value == 0 && NameToOrdinal.Count > 0)
					return RowData.Count == NameToOrdinal.Count;
				// compare
				else if (StrictColumnCount.Value > 0)
					return RowData.Count == StrictColumnCount.Value;
			}
			else
			{
				// check for line consisting of all bad chars not caught by readNonBlankLine
				foreach (char c in CurrentLine)
				{
					if (c > 0x20 && c < 0x7F)
						return true;
				}
				return false;
			}
			return true;
        }

		#endregion
	}

	public class IOFixedReader : DataIOReader
	{
		List<FixedFieldDescriptor> FieldDescriptors;
		List<string> RowData;

		public IOFixedReader(List<FixedFieldDescriptor> inFieldDescriptors)
		{
			FieldDescriptors = new List<FixedFieldDescriptor>(inFieldDescriptors);
			RowData = new List<string>();
		}

		private List<string> SplitLineByRules(string Line, string NullString)
		{
			List<string> Result = new List<string>();
			foreach (FixedFieldDescriptor myField in FieldDescriptors)
			{
				if (myField.StartPos > Line.Length)
				{
					Result.Add(string.Empty);
					continue;
				}
				// check size
				string val;
				if (myField.EndPos > Line.Length)
				{
					// just get sub
					val = Line.Substring(myField.StartPos).Trim();
				}
				else
				{
					val = Line.Substring(myField.StartPos, myField.Size).Trim();
				}
				// get field
				if (!string.IsNullOrEmpty(NullString))
				{
					if (val == NullString)
					{
						val = string.Empty;
					}
				}
				Result.Add(val);
			}
			return Result;
		}

		#region DataIOReader Members

		public override void Initialize()
		{
			// check and skip header if we have one
			base.InitializeReader();
		}

		public override int GetOrdinal(string Name)
		{
			string UPPER = Name.ToUpperInvariant();
			for (int Result = 0; Result < FieldDescriptors.Count; Result++)
			{
				if (FieldDescriptors[Result].Name == UPPER)
					return Result;
			}
			throw new ApplicationException("Name not found");
		}

		public override bool Read(string NullString)
		{
			RowData.Clear();
			if (base.EndOfStream()) return false;
			RowData = SplitLineByRules(base.ReadNextLine(), NullString);
			return true;
		}

		public override string GetString(int Ordinal)
		{
			if (Ordinal >= RowData.Count) return string.Empty;
			return RowData[Ordinal];
		}

		public override bool IsRowValid(int? StrictColumnCount)
		{
			// check for line consisting of all bad chars not caught by readNonBlankLine
			foreach (char c in CurrentLine)
			{
				if (c > 0x20 && c < 0x7F)
					return true;
			}
			return false;
		}

		#endregion
	}

	public class FixedFieldDescriptor
    {
        public string Name { get; set; }
        public int StartPos { get; set; }
        public int Size { get; set; }
        public int EndPos
        {
            get
            {
                return StartPos + Size;
            }
        }
        private FixedFieldDescriptor()
        {
        }
        private FixedFieldDescriptor(string inName, int inStartPos, int inSize)
        {
            Name = inName;
            StartPos = inStartPos;
            Size = inSize;
        }
        public static FixedFieldDescriptor Create(string inName, int inStartPos, int inSize)
        {
            FixedFieldDescriptor Result = new FixedFieldDescriptor(inName, inStartPos, inSize);
            return Result;
        }
    }

	public abstract class DataIOCommand : IDisposable
	{
		public abstract DataIOReader ExecuteReader();

		public Stream Connection { get; set; }
		public bool HeaderPresent { get; set; }
		public bool FooterPresent { get; set; }
		public QueryLineSkip QueryHeaderSkip { get; set; }
		public QueryLineSkip QueryFooterSkip { get; set; }
		public string ExtraInfoMarker { get; set; }

		public DataIOCommand()
		{
			Connection = null;
			HeaderPresent = false;
			FooterPresent = false;
		}

		public DataIOCommand(Stream InputStream)
		{
			Connection = InputStream;
			HeaderPresent = false;
			FooterPresent = false;
		}

		public void Dispose()
		{
			if (Connection != null)
			{
				Connection.Close();
				Connection.Dispose();
			}
		}
	}

	public class IODelimitedCommand : DataIOCommand
	{
		public string Delimiter { get; set; }
		public string EscapeSequence { get; set; }
		public string QuotedSequence { get; set; }
		public IODelimitedCommand() : base() { Delimiter = ","; EscapeSequence = "\""; QuotedSequence = "\""; }
		public IODelimitedCommand(Stream InputStream) : base(InputStream) { Delimiter = ","; EscapeSequence = "\""; QuotedSequence = "\""; }
		public string Header { get; set; }

		public override DataIOReader ExecuteReader()
		{
			IODelimitedReader myReader = new IODelimitedReader();
			myReader.Connection = Connection;
			myReader.Delimiter = Delimiter;
			myReader.EscapeSequence = EscapeSequence;
			myReader.QuotedSequence = QuotedSequence;
			myReader.FooterPresent = FooterPresent;
			myReader.HeaderPresent = HeaderPresent;
			myReader.QueryFooterSkip = QueryFooterSkip;
			myReader.QueryHeaderSkip = QueryHeaderSkip;
			string HeaderOverride = null;
			if (!string.IsNullOrEmpty(Header)) HeaderOverride = Header;
			myReader.ExtraInfoMarker = ExtraInfoMarker;
			myReader.Initialize(Header);
			return myReader;
		}
	}

	public class IOFixedCommand : DataIOCommand
    {
        List<FixedFieldDescriptor> FieldDescriptors = new List<FixedFieldDescriptor>();
        public IOFixedCommand() : base() { }
        public IOFixedCommand(Stream InputStream) : base(InputStream) { }
        public void AddFieldDescriptor(FixedFieldDescriptor inField)
        {
            FieldDescriptors.Add(FixedFieldDescriptor.Create(inField.Name.ToUpperInvariant(), inField.StartPos, inField.Size));
        }
        public void AddFieldDescriptor(string inName, int inStartPos, int inSize)
        {
            FieldDescriptors.Add(FixedFieldDescriptor.Create(inName.ToUpperInvariant(), inStartPos, inSize));
        }
        public override DataIOReader ExecuteReader()
        {
            IOFixedReader myReader = new IOFixedReader(FieldDescriptors);
            myReader.Connection = Connection;
            myReader.FooterPresent = FooterPresent;
            myReader.HeaderPresent = HeaderPresent;
            myReader.QueryFooterSkip = QueryFooterSkip;
            myReader.QueryHeaderSkip = QueryHeaderSkip;
            myReader.Initialize();
            return myReader;
        }
    }
}
