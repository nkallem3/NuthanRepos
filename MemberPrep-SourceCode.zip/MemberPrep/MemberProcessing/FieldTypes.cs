﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace MemberProcessing
{
	public enum FieldType : long
	{
		TString = 1,
		TDate = 2,
		TDecimal = 3,
		TBoolean = 4,
		TInteger = 5,
		THICNumber = 6,
		TSSN = 7,
		TGender = 8,
		TMCOContractNumber = 9,
		TUSPhoneNumber = 10,
		TCommercialPlanID = 11,
		TUSZipCode = 12,
		TUSStateCode = 13,
		TEmailAddress = 14,
		TUSPhoneNumberWithTollFree = 15,
		TMBI = 16,
	}

    public static class FieldValidator
    {
        private static HashSet<NPANXX> ValidUSPrefixes = null;
        private static string[] USPSState = new string[]
		{
            "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL",
            "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME",
            "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH",
            "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI",
            "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI",
            "WY", "AS", "GU", "MP", "PR", "VI", "FM", "MH", "PW", "AA",
            "AE", "AP"
		};
		private static Regex MBIRegex = new Regex(@"^((?i)[1-9][ACDEFGHJKMNPQRTUVWXY][ACDEFGHJKMNPQRTUVWXY0-9][0-9][ACDEFGHJKMNPQRTUVWXY][ACDEFGHJKMNPQRTUVWXY0-9][0-9][ACDEFGHJKMNPQRTUVWXY][ACDEFGHJKMNPQRTUVWXY][0-9][0-9])$", RegexOptions.Compiled);
		private static Regex HICRegex = new Regex(@"^(([0-9]{9}[A-Za-z][0-9A-Za-z]?)|(((A)|(H)|(CA)|(JA)|(MA)|(MH)|(PA)|(PD)|(PH)|(WA)|(WD)|(WH)|(WCA)|(WCD)|(WCH))(([0-9]{6})|([0-9]{9}))))$", RegexOptions.Compiled);
		private static Regex SSNRegex = new Regex(@"^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\1(?!0000)[0-9]{4}$", RegexOptions.Compiled);

		public const string DATE = "yyyyMMdd";
        public static string[] DATE_ARRAY = new string[] { DATE };

		public static DateTime? ToDate(string source, DateTime? defaultvalue = null)
		{
			DateTime result;
			if (DateTime.TryParse(source, out result))
				return result;
			else if (DateTime.TryParseExact(source, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out result))
				return result;
			return defaultvalue;
		}

		public static string FormatField(string FIELDDATA, FieldType FieldValidationType)
        {
            if (string.IsNullOrEmpty(FIELDDATA)) return string.Empty;
            string KEEP = string.Empty;
            switch(FieldValidationType)
            {
                case FieldType.TSSN:
                case FieldType.TInteger:
                    foreach (char CH in FIELDDATA)
                    {
                        if (char.IsDigit(CH)) KEEP += CH;
                    }
                    return KEEP;
                case FieldType.TUSPhoneNumber:
                case FieldType.TUSPhoneNumberWithTollFree:
                    foreach (char CH in FIELDDATA)
                    {
						// strip any non-numeric chars that could possibly be interpreted as part of a phone number
                        if ("()*+.,:;/-_".Contains(CH) == false) KEEP += CH;
                    }
                    if (KEEP.Length == 10) return KEEP;
                    if (KEEP.Length == 11)
                    {
                        if (KEEP[0] == '1')
                        {
                            return KEEP.Substring(1);
                        }
                    }
                    return KEEP;
                case FieldType.TCommercialPlanID:
                    // should be in format 5 digits 2 alpha state code 9 digits
                    foreach (char CH in FIELDDATA)
                    {
                        if (char.IsLetterOrDigit(CH)) KEEP += CH;
                    }
                    return KEEP;
                case FieldType.THICNumber:
				case FieldType.TMBI:
                    foreach (char CH in FIELDDATA)
                    {
                        if (char.IsLetterOrDigit(CH))
                            KEEP += CH;
                    }
                    return KEEP.Trim().ToUpperInvariant();
				case FieldType.TGender:
                    if (FIELDDATA[0] == 'F') return "F";
                    if (FIELDDATA[0] == 'f') return "F";
                    if (FIELDDATA[0] == 'M') return "M";
                    if (FIELDDATA[0] == 'm') return "M";
                    if (FIELDDATA[0] == 'W') return "F";
                    if (FIELDDATA[0] == 'x') return "X";
                    if (FIELDDATA[0] == 'X') return "X";
                    return string.Empty;
                case FieldType.TUSZipCode:
                    foreach (char CH in FIELDDATA)
                    {
                        if (char.IsDigit(CH)) KEEP += CH;
                    }
                    if (KEEP.Length == 5)
                    {
                        return KEEP;
                    }
                    if (KEEP.Length == 9)
                    {
                        return KEEP;
                    }
                    else if (KEEP.Length < 5)
                    {
                        // adjust
                        KEEP = ("00000" + KEEP);
                        // get last 5
                        KEEP = KEEP.Substring(KEEP.Length - 5);
                    }
                    else
                    {
                        KEEP = KEEP.Substring(0, 5);
                    }
                    return KEEP;
                case FieldType.TUSStateCode:
                    string STATE = string.Empty;
                    foreach (char CH in FIELDDATA)
                    {
                        if (char.IsLetter(CH))
                            STATE += CH;
                    }
                    if (STATE.Length < 2) return string.Empty;
                    STATE = STATE.ToUpperInvariant();
                    return STATE.Substring(0, 2);
                case FieldType.TEmailAddress:
                    string trim = FIELDDATA.Trim();
                    // split
                    string[] parts = trim.Split(new char[] { '@' }, StringSplitOptions.None);
                    if (parts.Length != 2) return trim;
                    // domain part is case insensitive
                    return parts[0] + "@" + parts[1].ToLowerInvariant();

            }
            return FIELDDATA;
        }

        public static bool IsFieldValid(string FIELDDATA, FieldType FieldValidationType)
        {
            switch (FieldValidationType)
            {
                case FieldType.TString:
                    return true;
                case FieldType.TDate:
                    DateTime dummyDateTime;
                    if (!DateTime.TryParseExact(FIELDDATA, DATE_ARRAY, null, System.Globalization.DateTimeStyles.None, out dummyDateTime)) return false;
                    if (dummyDateTime.Year < 1800) return false;
                    if (dummyDateTime.Year > 2200) return false;
                    if (dummyDateTime.Year > DateTime.Now.Year + 10) return false; // too far in future
                    return true;
                case FieldType.TDecimal:
                    decimal dummydecimal;
                    return decimal.TryParse(FIELDDATA, out dummydecimal);
                case FieldType.TBoolean:
                    bool dummybool;
                    return bool.TryParse(FIELDDATA, out dummybool);
                case FieldType.TInteger:
                    long dummylong;
                    return long.TryParse(FIELDDATA, out dummylong);
                case FieldType.THICNumber:
					if (string.IsNullOrEmpty(FIELDDATA)) return false;
					return HICRegex.IsMatch(FIELDDATA);
				case FieldType.TMBI:
					if (string.IsNullOrEmpty(FIELDDATA)) return false;
					return MBIRegex.IsMatch(FIELDDATA);
				case FieldType.TSSN:
					if (string.IsNullOrEmpty(FIELDDATA)) return false;
					return SSNRegex.IsMatch(FIELDDATA);
				case FieldType.TGender:
                    string dummyGender = FIELDDATA.ToUpperInvariant().Trim();
                    if (string.IsNullOrEmpty(dummyGender)) return true;
                    if (dummyGender[0] == 'F') return true;
                    if (dummyGender[0] == 'M') return true;
                    if (dummyGender[0] == 'U') return true; // unknown
                    if (dummyGender[0] == 'X') return true; // both
                    return false;
                case FieldType.TMCOContractNumber:
                    string MCO = FIELDDATA.ToUpperInvariant().Trim();
                    if (string.IsNullOrEmpty(MCO)) return false;
                    if (MCO.Length != 5) return false;
                    if ((MCO[0] != 'H') && (MCO[0] != 'R') && (MCO[0] != 'S')) return false; // must start with S, H or R
                    for (int Index = 1; Index < 4; Index++)
                    {
                        if (!char.IsDigit(MCO[Index])) return false; // must be followed by 4 digits
                    }
                    // if we are still here, this looks like possibly valid MCO
                    return true;
                case FieldType.TUSPhoneNumber:
                case FieldType.TUSPhoneNumberWithTollFree:
                    // get parts
                    if (FIELDDATA.Length != 10) return false;
                    short NPA = 0;
                    short NXX = 0;
                    if (!short.TryParse(FIELDDATA.Substring(0, 3), out NPA)) return false;
                    if (!short.TryParse(FIELDDATA.Substring(3, 3), out NXX)) return false;
                    if (ValidUSPrefixes != null)
                    {
                        NPANXX myINFO = new NPANXX(NPA, NXX);
                        return (ValidUSPrefixes.Contains(myINFO));
                    }
                    return false;
                case FieldType.TCommercialPlanID:
                    // should be 5 digits, 2 state code, 9 digits
                    if (FIELDDATA.Length != 16) return false;
                    // check payload
                    return true;
                case FieldType.TUSZipCode:
                    int zip;
                    if (FIELDDATA.Length <= 5)
                    {
                        int.TryParse(FIELDDATA, out zip);
                    }
                    else
                    {
                        int.TryParse(FIELDDATA.Substring(0, 5), out zip);
                    }
                    if (zip <= 500) return false;
                    if (zip > 99950) return false;
                    // kind of looks like possibly good zip code
                    return true;
                case FieldType.TUSStateCode:
                    return USPSState.Contains(FIELDDATA);
                case FieldType.TEmailAddress:
                    return true;
            }
            // until proven otherwise
            return true;
        }

		private static FileInfo CurrentNPANXXFile = null;
		public static void PrimePhoneValidator(string NPANXXFile)
        {
			if (!string.IsNullOrEmpty(NPANXXFile))
			{
				// Look for the most recent NPANXX file
				DirectoryInfo di = new DirectoryInfo(Path.GetDirectoryName(NPANXXFile));
				FileInfo fi = di.GetFiles(Path.GetFileName(NPANXXFile)).OrderByDescending(x => x.LastWriteTime).FirstOrDefault();
				if (fi != null)
				{
					if (CurrentNPANXXFile == null || (fi.FullName != CurrentNPANXXFile.FullName || fi.LastWriteTime != CurrentNPANXXFile.LastWriteTime))
					{
						// File never loaded or has changed
						HashSet<NPANXX> DataInFile = new HashSet<NPANXX>();
						using (Stream NPANXXStream = fi.OpenRead())
						{
							using (StreamReader myReader = new StreamReader(NPANXXStream))
							{
								while (!myReader.EndOfStream)
								{
									// Valid line should be in form NPA,NNX,...
									string Line = myReader.ReadLine().Trim();
									if (string.IsNullOrEmpty(Line)) continue;
									if (Line[0] == '#') continue;
									string[] parts = Line.Split(',');
									if (parts.Length < 2) continue;
									short NPA;
									short NXX;
									if (!short.TryParse(parts[0], out NPA)) continue;
									if (!short.TryParse(parts[1], out NXX)) continue;
									NPANXX myItem = new NPANXX(NPA, NXX);
									DataInFile.Add(myItem);
								}
							}
						}
						ValidUSPrefixes = DataInFile;
					}
					CurrentNPANXXFile = fi;
				}
			}
        }
    }

    public class NPANXX : IComparable<NPANXX>
    {
        public short NPA;
        public short NXX;
        public NPANXX(short npa, short nxx)
        {
            NPA = npa;
            NXX = nxx;
        }

        public int CompareTo(NPANXX other)
        {
            int comp = NPA.CompareTo(other.NPA);
            if (comp != 0) return comp;
            return NXX.CompareTo(other.NXX);
        }

        public override int GetHashCode()
        {
            return (((int)NPA) << 16) ^ ((int)NXX);
        }

        public override bool Equals(object obj)
        {
            if (!(obj is NPANXX)) return false;
            return (CompareTo((NPANXX)obj) == 0);
        }
    }
}
