﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Logging;

namespace MemberProcessing
{
	public class MemberProcess
	{
		private LoggerClass LoadLogger = null;

		public void ProcessLoad(LoadInfo Load, LoggingDelegate OnLogString = null)
		{
			DemoReader Reader = new DemoReader();
			Scrubbing Scrubber = new Scrubbing();
			Enrichment Enricher = new Enrichment();
			DemoWriter Writer = new DemoWriter();
			HistoricalData History = null;
			LoggingDelegate LoggerCallbackOrig = null;
			List<PersonatorBatch> BatchesToOutput = new List<PersonatorBatch>();
			long NextBatchNumberToOutput = 1;
			long TermedMembersExcluded = 0;
			long DeferredEnrichmentExcluded = 0;

			Load.RecordCount = 0;
			Load.Progress.Start(Load.FileSize, "");
			Load.Status = LoadStatus.InProcess;
			History = Load.History;

			try
			{
				if (string.IsNullOrEmpty(Load.InputFile))
					throw new Exception("No input file specified");
				if (File.Exists(Load.InputFile) == false)
					throw new Exception(string.Format("Input file not found - {0}", Load.InputFile));
				if (File.Exists(Load.ConfigFile) == false)
					throw new Exception(string.Format("Config file not found - {0}", Load.ConfigFile));

				// Initialization
				Load.Cleanup();
				Reader.Initialize(Load);
				Scrubber.Initialize(Load);
				Enricher.Initialize(Load);
				Writer.Initialize(Load);
				ProcessArgs.MelissaData.ClearCache();

				// Create a logger specific to this load
				LoadLogger = new LoggerClass();
				LoadLogger.LoggerInit(Load.LogFile, ProcessArgs.Config.ConsoleExecute, ProcessArgs.Config.LoggingLevel);
				LoadLogger.LoggingCallback = OnLogString;
				if (LoadLogger.GetLogLevel(LogDestination.Callback) > LogLevel.Info) LoadLogger.SetLogLevel(LogDestination.Callback, LogLevel.Info);
				if (LoadLogger.GetLogLevel(LogDestination.Console) > LogLevel.Info) LoadLogger.SetLogLevel(LogDestination.Console, LogLevel.Info);
				LoggerCallbackOrig = Logger.LoggingCallback;
				Logger.LoggingCallback = OnLogMessage;

				LoadLogger.LogString("--------------------------------------------------");
				LoadLogger.LogString(string.Format("Input file = {0}", Path.GetFileName(Load.InputFile)), LogLevel.Always);
				string sOptions = "";
				foreach (LoadOption opt in Load.LoadOptions.Where(x => x.ToString().StartsWith("Enrich")))
				{
					sOptions += (string.IsNullOrEmpty(sOptions) ? "" : ", ") + opt.ToString().Replace("Enrich", "");
				}
				if (Load.LoadOptions.Contains(LoadOption.EnrichDeferred) == false)
					sOptions += string.Format(" ({0} threads)", ProcessArgs.Config.MaxPersonatorThreads);
				Logger.LogString(string.Format("Enrichment options: {0}", sOptions), LogLevel.Always);

				// Launch threads to read the phone/address/enrich/mbihicn historical data for this data source
				LoadLogger.LogString("Reading historical data", LogLevel.Always);
				List<Task> ReadHistoryTasks = new List<Task>();
				if (Load.LoadOptions.Contains(LoadOption.NoHistory) == false && Load.LoadOptions.Contains(LoadOption.NoValidation) == false)
					ReadHistoryTasks.Add(Task.Run(() => History.ReadPhoneHistory(Load.PhoneHistoryFile)));
				if (Load.LoadOptions.Contains(LoadOption.NoHistory) == false && Load.LoadOptions.Contains(LoadOption.NoValidation) == false)
					ReadHistoryTasks.Add(Task.Run(() => History.ReadAddressHistory(Load.AddressHistoryFile)));
				if (Load.LoadOptions.Contains(LoadOption.NoHistory) == false && Load.LoadOptions.Contains(LoadOption.NoEnrichment) == false)
					ReadHistoryTasks.Add(Task.Run(() => History.ReadEnrichHistory(Load.EnrichHistoryFile)));
				if (Load.LoadOptions.Contains(LoadOption.NoValidation) == false)
					ReadHistoryTasks.Add(Task.Run(() => Load.LoadMBIHICNCrosswalk(ProcessArgs.Config.MBIHICNRootFolder)));
				Task.WaitAll(ReadHistoryTasks.ToArray());

				// Process the input file
				// Members are read, scrubbed, enriched, and then output
				// If enrichment is being done in-process, a batch of members are sent to Personator before writing the output
				LoadLogger.LogString("Processing file");
				while (!Reader.EndOfFile)
				{
					if (Load.Status == LoadStatus.Aborted)
					{
						throw new Exception();
					}

					// Read the next member
					PMMember Member = Reader.GetNextMember();
					if (Member != null)
					{
						Load.RecordCount++;

						// Bump any field missing counts
						foreach (FieldDefinition def in Load.OutputFormat.FieldDefinitions.Where(x => x.MaxMissingPercent >= 0))
						{
							if (string.IsNullOrEmpty(Member.GetStringData(def.InternalFieldName)))
							{
								Load.Stats.Missing.Bump(def.InternalFieldName);
							}
						}

						// Check if the member is termed and should be excluded
						if (Load.LoadOptions.Contains(LoadOption.IncludeTermed) == false)
						{
							string PEED = Member.GetStringData(PMMember.PLANEFFECTIVEENDDATE);
							DateTime? dtPEED = FieldValidator.ToDate(PEED);
							if (dtPEED != null && dtPEED.Value <= Load.EffectiveDate)
							{
								TermedMembersExcluded++;
								string MemberID = Member.GetStringData(PMMember.MEMBERID);
								Logger.LogString(string.Format("Member excluded due to termination date: ID = {0}, date = {1}", MemberID, dtPEED.Value.ToString("yyyyMMdd")), LogLevel.Verbose);
								continue;
							}
						}

						// Validation
						Scrubber.ScrubMember(Member);

						// Enrichment - can be either immediate or deferred
						//    Immediate: The Enrichment class handles batching and sending to Personator
						//    Deferred:  Members needing enrichment are output to a file
						Enricher.EnrichMember(Member);
						if (Reader.EndOfFile)
						{
							Enricher.FinishEnrichment();
						}

						// If enrichment is deferred, output members immediately
						if (Load.LoadOptions.Contains(LoadOption.EnrichDeferred) == true)
						{
							Writer.OutputMember(Member);
							Load.Progress.Current = Member.BytesRead;
						}
					}

					// Check for completed enrichment returned from Personator
					// If there's no more input data, wait here until all batches are returned
					while (Enricher.EnrichmentIsPending)
					{
						PersonatorBatch Batch = Enricher.GetCompletedBatch();
						if (Batch != null)
						{
							BatchesToOutput.Add(Batch);
						}
						if (Reader.EndOfFile == false)
							break;
						Thread.Sleep(500);
					}

					// Output members in sequential order
					// Batches may not be returned from Personator in the same order as they were sent
					while (BatchesToOutput.Any())
					{
						PersonatorBatch BatchToOutput = BatchesToOutput.FirstOrDefault(x => x.BatchNumber == NextBatchNumberToOutput);
						if (BatchToOutput != null)
						{
							NextBatchNumberToOutput++;
							BatchesToOutput.Remove(BatchToOutput);
							foreach (PMMember MemberOut in BatchToOutput.MemberData.OrderBy(x => x.RecordID))
							{
								// For deferred enrichment proicessing, exclude any members not needing enrichment
								if (Load.Loadtype == LoadType.DeferredEnrichment && MemberOut.NeedsEnrichment.Count == 0)
									DeferredEnrichmentExcluded++;
								else
									Writer.OutputMember(MemberOut);
								Load.Progress.Current = Member.BytesRead;
							}
						}
						if (Reader.EndOfFile == false)
							break;
					}
				}

				Reader.Close();
				Enricher.Close();
				Writer.Close();

				Logger.LogString(string.Format("Total members: {0:N0}", Load.RecordCount), LogLevel.Always);
				if (Load.LoadOptions.Contains(LoadOption.IncludeTermed) == false)
					Logger.LogString(string.Format("Members excluded due to termination date: {0:N0}", TermedMembersExcluded));
				if (Load.Loadtype == LoadType.DeferredEnrichment)
					Logger.LogString(string.Format("Members excluded (no enrichment needed): {0:N0}", DeferredEnrichmentExcluded));
				Scrubber.LogStats();
				Enricher.LogStats();
				History.LogStats();

				// Evaluate missing and invalid counts
				foreach (FieldDefinition def in Load.OutputFormat.FieldDefinitions.OrderBy(x => x.InternalFieldName))
				{
					decimal Missing = Load.Stats.Missing.GetCount(def.InternalFieldName) * 100 / Load.RecordCount;
					decimal Invalid = Load.Stats.Invalid.GetCount(def.InternalFieldName) * 100 / Load.RecordCount;
					if (def.MaxMissingPercent >= 0 && Missing > def.MaxMissingPercent)
					{
						Logger.LogString(string.Format("Load failed - too many missing values for {0} ({1:N1}%)", def.InternalFieldName, Missing), LogLevel.Error);
						Load.Status = LoadStatus.Error;
					}
					if (def.MaxInvalidPercent >= 0 && Invalid > def.MaxInvalidPercent)
					{
						Logger.LogString(string.Format("Load failed - too many invalid values for {0} ({1:N1}%)", def.InternalFieldName, Invalid), LogLevel.Error);
						Load.Status = LoadStatus.Error;
					}
				}

				// Launch threads to write the phone/address/enrich historical data for this data source
				LoadLogger.LogString("Updating historical data", LogLevel.Always);
				List<Task> WriteHistoryTasks = new List<Task>();
				if (Load.LoadOptions.Contains(LoadOption.NoHistory) == false && Load.Status == LoadStatus.InProcess)
				{
					WriteHistoryTasks.Add(Task.Run(() => History.WritePhoneHistory(Load.PhoneHistoryFile)));
					WriteHistoryTasks.Add(Task.Run(() => History.WriteAddressHistory(Load.AddressHistoryFile)));
					WriteHistoryTasks.Add(Task.Run(() => History.WriteEnrichHistory(Load.EnrichHistoryFile)));
					Task.WaitAll(WriteHistoryTasks.ToArray());
				}

				if (Load.Status == LoadStatus.InProcess)
					Load.Status = LoadStatus.Complete;
			}
			catch (Exception ex)
			{
				if (Load.IsAborted)
				{
					LoadLogger.LogString("Processing aborted", LogLevel.Error);
				}
				else
				{
					LoadLogger.LogException("Program Error", ex);
					Load.Status = LoadStatus.Error;
				}
			}
			finally
			{
				Reader.Close();
				Enricher.Close();
				Writer.Close();
				LoadLogger.LogString(string.Format("Processing ended: file = {0}, status = {1} ({2:N2} total seconds)",
					Path.GetFileName(Load.InputFile), Load.Status, (decimal) Load.Progress.Elapsed.TotalSeconds), LogLevel.Always);

				// Archive the processed files (Logger needs to be closed before the log file can be archived)
				LoadLogger.LoggerClose();
				Logger.LoggingCallback = LoggerCallbackOrig;
				Load.Archive();

				// Update the processing log
				string Line = string.Format("{0},{1},{2},{3}", Path.GetFileName(Load.InputFile), DateTime.Now, Load.RecordCount, Load.Status);
				File.AppendAllLines(ProcessArgs.Config.ProcessLogFile, new string[] { Line });
			}
		}

		private void OnLogMessage(string str, LogLevel level)
		{
			if (LoadLogger != null)
				LoadLogger.LogString(str, level);
		}
	}
}
