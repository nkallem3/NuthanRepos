﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

using Logging;

namespace MemberProcessing
{
	public enum LoadType
	{
		DEMO,
		DeferredEnrichment,
	}

	public enum LoadStatus
	{
		None,
		Ready,
		InProcess,
		Complete,
		Aborted,
		Error,
	}

	public enum LoadOption
	{
		ValidateAddress,
		ValidatePhone,
		EnrichAddress,
		EnrichPhone,
		EnrichEmail,
		EnrichDeferred,
		IncludeTermed,
		NoValidation,
		NoEnrichment,
		NoHistory,
	}

	public class LoadProgress
	{
		public Stopwatch timer = new Stopwatch();
		public long Max = 0;
		public long Current = 0;
		public int PercentComplete { get { return Max > 0 && Current > 0 ? (int) ((decimal) Current * 100 / Max) : 0; } }
		public TimeSpan Elapsed { get { return timer.Elapsed; } }
		public string ElapsedString { get { return timer.Elapsed.ToString(timer.Elapsed.TotalHours >= 1.0 ? "hh\\:mm\\:ss" : "mm\\:ss"); } }
		public void Start(long max, string message) { Max = max; Current = 0; timer.Restart(); }
		public void Stop() { timer.Stop(); }
	}

	// This class is populated from the process log
	public class LoadHistory
	{
		public string DemoFile = "";
		public long RecordCount = 0;
		public DateTime ProcessedDate;
		public LoadStatus Status = LoadStatus.None;
	}

	public class StatCounter
	{
		private Dictionary<string, long> FieldCounts = new Dictionary<string, long>();

		public void Bump(string Field)
		{
			if (FieldCounts.ContainsKey(Field))
				FieldCounts[Field]++;
			else
				FieldCounts.Add(Field, 1);
		}

		public long GetCount(string Field)
		{
			long Count = 0;
			return FieldCounts.TryGetValue(Field, out Count) ? Count : 0;
		}

		public List<string> GetFields()
		{
			return FieldCounts.Keys.OrderBy(x => x).ToList();
		}
	}

	public class LoadStatistics
	{
		public StatCounter Missing = new StatCounter();
		public StatCounter Invalid = new StatCounter();
		public StatCounter Altered = new StatCounter();
		public StatCounter Removed = new StatCounter();
		public StatCounter Scrubbed = new StatCounter();
		public StatCounter ScrubTried = new StatCounter();
		public StatCounter Enriched = new StatCounter();
		public StatCounter EnrichTried = new StatCounter();
		public StatCounter EnrichDeferred = new StatCounter();
	}

	public class LoadInfo
	{
		public long DataSourceID = 0;
		public long FileSize = 0;
		public long RecordCount = 0;
		public DateTime EffectiveDate;
		public DateTime ProcessedDate;
		public string DataSourceName = "";
		public string ErrorMessage = "";
		public string ConfigFile = "";
		public string DemoFile = "";
		public string ExtraFileInfo = "";
		public LoadType Loadtype = LoadType.DEMO;
		public LoadProgress Progress = new LoadProgress();
		public LoadStatus Status = LoadStatus.None;
		public LoadStatistics Stats = new LoadStatistics();
		public FormatFile OutputFormat = null;
		public MBIHICNCrosswalk MBIHICNCrosswalk = null;
		public HashSet<LoadOption> LoadOptions = new HashSet<LoadOption>();
		public HistoricalData History = new HistoricalData();

		private string BaseName { get { return string.Format("DS{0:0000}_{1}", DataSourceID, EffectiveDate.ToString("yyyy-MM-dd")); } }
		private string BasePath { get { return Path.GetDirectoryName(DemoFile); } }
		private string BaseHistoryPath { get { return Path.Combine(ProcessArgs.Config.HistoryFolder, string.Format("DS{0:0000}", DataSourceID)); } }
		private string BaseArchivePath { get { return Path.Combine(ProcessArgs.Config.ArchiveFolder, string.Format("DS{0:0000}", DataSourceID)); } }

		public string InputFile { get { return Loadtype == LoadType.DEMO ? DemoFile : ToBeEnrichedFile; } }
		public string OutputFile { get { return Loadtype == LoadType.DEMO ? Path.Combine(BasePath, BaseName + ".DEMO") : Path.Combine(ProcessArgs.Config.EnrichFolder, BaseName + ".EnrichedOutput.txt"); } }
		public string LogFile { get { return Path.Combine(BasePath, BaseName + ".Log"); } }
		public string ChangeFile { get { return Path.Combine(BasePath, BaseName + ".ChangeLog.csv"); } }
		public string ToBeEnrichedFile { get { return Path.Combine(ProcessArgs.Config.EnrichFolder, BaseName + ".ToBeEnriched.txt"); } }
		public string EnrichInputFormat { get { return Path.Combine(ProcessArgs.Config.ConfigFolder, "DeferredEnrichmentInput.xml"); } }
		public string EnrichOutputFormat { get { return Path.Combine(ProcessArgs.Config.ConfigFolder, "DeferredEnrichmentOutput.xml"); } }
		public string PhoneHistoryFile { get { return Path.Combine(BaseHistoryPath, string.Format("DS{0:0000}-PhoneData.txt", DataSourceID)); } }
		public string AddressHistoryFile { get { return Path.Combine(BaseHistoryPath, string.Format("DS{0:0000}-AddressData.txt", DataSourceID)); } }
		public string EnrichHistoryFile { get { return Path.Combine(BaseHistoryPath, string.Format("DS{0:0000}-EnrichData.txt", DataSourceID)); } }
		public bool IsAborted { get { return Status == LoadStatus.Aborted; } }

		public string GetStatusString()
		{
			if (Progress.Elapsed.TotalMilliseconds == 0)
				return Status.ToString();
			else if (Status == LoadStatus.InProcess)
				return string.Format("{0}  ({1} - {2}%)", Status, Progress.ElapsedString, Progress.PercentComplete);
			else
				return string.Format("{0}  ({1})", Status, Progress.ElapsedString);
		}

		public override string ToString()
		{
			return string.Format("{0} - {1}", BaseName, Status);
		}

		public void GetLoadInfoForDemoFile(string FileName)
		{
			char[] pathseps = { '\\', '/' };
			string[] parts;
			DateTime EffDate;

			Loadtype = LoadType.DEMO;
			DataSourceID = 0;
			FileSize = new FileInfo(FileName).Length;
			RecordCount = 0;
			DemoFile = FileName;
			ConfigFile = "";

			// Make sure we have a proper DEMO file
			parts = Path.GetFileName(FileName).ToUpperInvariant().Trim().Split(new char[] { '.' });
			if (parts.Length == 4
				&& long.TryParse(parts[1], out DataSourceID)
				&& DateTime.TryParseExact(parts[2], "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out EffDate))
			{
				// Demo file -- "???.datasource.effectivedate.DEMO"
				EffectiveDate = EffDate;

				// Find the config file (and hence the data source name)
				foreach (string folder in Directory.GetDirectories(ProcessArgs.Config.DemoRootFolder, string.Format("DS{0:0000}-*", DataSourceID)))
				{
					string file = Path.Combine(folder, string.Format("DS{0:0000}.xml", DataSourceID));
					if (File.Exists(file))
					{
						DataSourceName = folder.Substring(folder.LastIndexOfAny(pathseps) + 8);
						ConfigFile = file;
						break;
					}
				}
			}
			else
			{
				ErrorMessage = "Invalid DEMO file";
			}

			if (DataSourceID == 0)
				ErrorMessage = "Unknown Datasource";
			else if (string.IsNullOrEmpty(ConfigFile) || !File.Exists(ConfigFile))
				ErrorMessage = "Missing config file";
			if (!string.IsNullOrEmpty(ErrorMessage))
				Status = LoadStatus.Error;
			else if (Directory.GetFiles(ProcessArgs.Config.InputFolder, BaseName + "*.*").Any())
				Status = LoadStatus.InProcess;
			else if (Directory.Exists(BaseArchivePath) && Directory.GetFiles(BaseArchivePath, BaseName + "*.*").Any())
				Status = LoadStatus.Complete;
			else
				Status = LoadStatus.Ready;
		}

		public void GetLoadInfoForEnrichmentFile(string FileName)
		{
			char[] pathseps = { '\\', '/' };
			long DS = 0;
			DateTime EF;

			Loadtype = LoadType.DeferredEnrichment;
			DataSourceID = 0;
			FileSize = new FileInfo(FileName).Length;
			RecordCount = 0;
			DemoFile = "";
			ConfigFile = EnrichInputFormat;
			OutputFormat = FormatFile.Load(EnrichOutputFormat);

			// Make sure we have a proper enrichment file (DSnnnn-yyyy-MM-dd.ToBeEnriched.txt)
			string DSString = Path.GetFileNameWithoutExtension(FileName).Substring(2, 4);
			string EFString = Path.GetFileNameWithoutExtension(FileName).Substring(7, 10);
			if (long.TryParse(DSString, out DS) == true && DateTime.TryParse(EFString, out EF) == true)
			{
				DataSourceID = DS;
				EffectiveDate = EF;

				// Set the DEMO filename so we can locate the .log, .csv, etc files
				string DSStr = string.Format("DS{0:0000}", DataSourceID);
				if (Directory.Exists(BaseArchivePath))
					DemoFile = Directory.GetFiles(BaseArchivePath, "*.demo").FirstOrDefault(x => Path.GetFileName(x).StartsWith(DSStr) == false);
				if (string.IsNullOrEmpty(DemoFile))
					DemoFile = Path.Combine(BaseArchivePath, string.Format("0.{0}.{1}.demo", DataSourceID, EffectiveDate.ToString("yyyy-MM-dd")));

				// Find the data source name
				foreach (string folder in Directory.GetDirectories(ProcessArgs.Config.DemoRootFolder, string.Format("DS{0:0000}-*", DataSourceID)))
				{
					string file = Path.Combine(folder, string.Format("DS{0:0000}.xml", DataSourceID));
					if (File.Exists(file))
					{
						DataSourceName = folder.Substring(folder.LastIndexOfAny(pathseps) + 8);
						break;
					}
				}
			}
			if (DataSourceID == 0)
				ErrorMessage = "Unknown Datasource";
			if (!string.IsNullOrEmpty(ErrorMessage))
				Status = LoadStatus.Error;
			Status = LoadStatus.Ready;
		}

		public void Cleanup()
		{
			// Remove any temporary files using in processing
			foreach (string file in Directory.GetFiles(Path.GetDirectoryName(InputFile), BaseName + "*.*"))
			{
				if (File.Exists(file) && string.Compare(file, InputFile, true) != 0)
					File.Delete(file);
			}
		}

		public void Archive()
		{
			// Move the DEMO and any temporary files to the archive (or error) folder
			string ArchiveFolder = null;
			if (Loadtype == LoadType.DEMO)
			{
				if (Status == LoadStatus.Complete)
				{
					ArchiveFolder = BaseArchivePath;
					if (File.Exists(OutputFile))
						File.Copy(OutputFile, Path.Combine(ProcessArgs.Config.OutputFolder, Path.GetFileName(OutputFile)), true);
				}
				else if (Status == LoadStatus.Error)
				{
					ArchiveFolder = ProcessArgs.Config.ErrorFolder;
				}
			}
			else
			{
				if (Status == LoadStatus.Complete)
				{
					ArchiveFolder = BaseArchivePath;
					if (File.Exists(OutputFile))
						File.Copy(OutputFile, Path.Combine(ProcessArgs.Config.OutputFolder, Path.GetFileName(OutputFile)), true);
				}
			}
			if (!string.IsNullOrEmpty(ArchiveFolder))
			{
				FileArchive(LogFile, ArchiveFolder);
				FileArchive(ChangeFile, ArchiveFolder);
				FileArchive(InputFile, ArchiveFolder);
				FileArchive(OutputFile, ArchiveFolder);

				// Update the location of the DEMO file (also locates the .log, .csv, etc files)
				DemoFile = Path.Combine(ArchiveFolder, Path.GetFileName(DemoFile));
			}
		}

		private void FileArchive(string srcFile, string dstPath)
		{
			string dstfile = Path.Combine(dstPath, Path.GetFileName(srcFile));
			if (!File.Exists(srcFile) || string.Compare(srcFile, dstfile, true) == 0)
				return;
			if (Directory.Exists(dstPath) == false)
				Directory.CreateDirectory(dstPath);
			if (File.Exists(dstfile))
				File.Delete(dstfile);
			File.Move(srcFile, dstfile);
		}

		public void LoadMBIHICNCrosswalk(string MBIHICNRootFolder)
		{
			if (Directory.Exists(MBIHICNRootFolder) == false)
				return;

			string MBIHICNFormatFile = Path.Combine(MBIHICNRootFolder, "MBIHICNCrosswalk.xml");
			string[] MBIDirs = Directory.GetDirectories(MBIHICNRootFolder, string.Format("DS{0:0000}*.*", DataSourceID));
			if (MBIDirs.Count() == 1)
			{
				MBIHICNCrosswalk = new MBIHICNCrosswalk();
				MBIHICNCrosswalk.DataSourceID = DataSourceID;
				MBIHICNCrosswalk.LoadFromFolder(MBIDirs[0], MBIHICNFormatFile);
			}
		}
	}
}

