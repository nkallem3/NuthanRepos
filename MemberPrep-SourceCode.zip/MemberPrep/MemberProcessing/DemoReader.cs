﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Xml;

namespace MemberProcessing
{
    public enum DemoType
    {
        NOT_SUPPLIED,
        Delimited,
        FixedWidth
    }

    public class DemoColumn
    {
		public string DemoFieldName;
		public string DataBureauFieldName;
        public int? Position;
        public int? Offset;
        public int? Length;
        public string[] OverrideFormat;

        public DemoColumn()
        {
			DemoFieldName = string.Empty;
			DataBureauFieldName = string.Empty;
            Position = null;
            Offset = null;
            Length = null;
            OverrideFormat = null;
        }
    }

    public class DemoConfig
    {
        public static string[] DEMODateFormat = new string[] { "MM/dd/yyyy", "dd-MMM-yy", "yyyyMMdd", "yyyy-MM-dd", "yyyy-MM-dd hh:mm:ss" };
		public bool IsValid { get { return TypeOfParser != DemoType.NOT_SUPPLIED; } }
		public string MCOOverride = string.Empty;
        public bool? hasHeader = null;
        public bool? hasFooter = null;
        public int? StrictColumnCount = null;
        public string HeaderMarker = string.Empty;
        public string FooterMarker = string.Empty;
		public string ExtraInfoMarker = null;
		public DemoType TypeOfParser = DemoType.NOT_SUPPLIED;
        public string Delimiter = string.Empty;
        public string NullString = string.Empty;
		public System.Text.RegularExpressions.Regex HeaderRegex = null;
		public System.Text.RegularExpressions.Regex FooterRegex = null;
		public HashSet<LoadOption> LoadOptions = null;

		public Dictionary<string, DemoColumn> Columns = new Dictionary<string, DemoColumn>();

		public void SetHeaderMarker(string marker)
		{
			if (marker != null && marker.StartsWith("{RX}"))
				HeaderRegex = new System.Text.RegularExpressions.Regex(marker.Substring(4), System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
			else
				HeaderMarker = marker;
		}

		public void SetFooterMarker(string marker)
		{
			if (marker != null && marker.StartsWith("{RX}"))
				FooterRegex = new System.Text.RegularExpressions.Regex(marker.Substring(4), System.Text.RegularExpressions.RegexOptions.Compiled | System.Text.RegularExpressions.RegexOptions.IgnoreCase);
			else
				FooterMarker = marker;
		}

		public bool QueryHeaderSkip(string Line)
		{
			if (HeaderRegex != null)
				return HeaderRegex.IsMatch(Line);
			return (Line.ToUpperInvariant().StartsWith(HeaderMarker.ToUpperInvariant()));
		}

		public bool QueryFooterSkip(string Line)
		{
			if (FooterRegex != null)
				return FooterRegex.IsMatch(Line);
			return (Line.ToUpperInvariant().StartsWith(FooterMarker.ToUpperInvariant()));
		}

		public static DemoConfig ReadConfig(string ConfigFile)
		{
			DemoConfig Config = null;

			XmlReaderSettings settings = new XmlReaderSettings();
			settings.ConformanceLevel = System.Xml.ConformanceLevel.Fragment;
			settings.IgnoreWhitespace = true;
			settings.IgnoreComments = true;
			settings.CheckCharacters = false;

			bool insideReadableRecord = false;
			using (XmlReader myReader = XmlReader.Create(ConfigFile))
			{
				while (myReader.Read())
				{
					#region depth 0
					if (myReader.Depth == 0)
					{
						if (myReader.NodeType == System.Xml.XmlNodeType.XmlDeclaration) continue;
						if (myReader.NodeType == System.Xml.XmlNodeType.EndElement) continue;
						if (myReader.MoveToContent() != System.Xml.XmlNodeType.Element) continue;
						string CurrentSectionName = myReader.Name.ToUpperInvariant().Trim();
						if (CurrentSectionName == "DATALOADDEFINITION")
						{
							// we are inside table that we care about
							// check
							if (myReader.MoveToAttribute("DefaultDefinitionFile"))
							{
								// get value
								string VAL = myReader.Value;
								string DefaultConfigurationFile = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(ConfigFile), VAL);
								// get config
								Config = ReadConfig(DefaultConfigurationFile);
							}
							else
							{
								Config = new DemoConfig();
							}
							// check for overrides
							if (myReader.MoveToAttribute("Contract"))
							{
								// get contract override
								Config.MCOOverride = myReader.Value;
							}
							if (myReader.MoveToAttribute("FileFormat"))
							{
								string FF = myReader.Value.ToUpperInvariant();
								if ((FF == "COMMADELIMITED") || (FF == "DELIMITED"))
								{
									Config.TypeOfParser = DemoType.Delimited;
									// set default
									Config.Delimiter = ",";
								}
								else if (FF == "FIXEDWIDTH")
								{
									Config.TypeOfParser = DemoType.FixedWidth;
								}
							}
							if (myReader.MoveToAttribute("Delimiter"))
							{
								Config.Delimiter = myReader.Value;
							}
							if (myReader.MoveToAttribute("HeaderAvailable"))
							{
								Config.hasHeader = bool.Parse(myReader.Value);
							}
							if (myReader.MoveToAttribute("TrailerAvailable"))
							{
								Config.hasFooter = bool.Parse(myReader.Value);
							}
							if (myReader.MoveToAttribute("HeaderPrefix"))
							{
								Config.SetHeaderMarker(myReader.Value);
							}
							if (myReader.MoveToAttribute("TrailerPrefix"))
							{
								Config.SetFooterMarker(myReader.Value);
							}
							if (myReader.MoveToAttribute("StrictColumnCount"))
							{
								Config.StrictColumnCount = int.Parse(myReader.Value);
							}
							if (myReader.MoveToAttribute("Null"))
							{
								Config.NullString = myReader.Value.Trim();
							}
							if (myReader.MoveToAttribute("ExtraInfoMarker"))
							{
								Config.ExtraInfoMarker = myReader.Value.Trim();
							}
							if (myReader.MoveToAttribute("LoadOptions"))
							{
								Config.LoadOptions = new HashSet<LoadOption>();
								foreach (string option in myReader.Value.Trim().Split(new char[] { ',', '.', ';' }, StringSplitOptions.RemoveEmptyEntries))
								{
									switch (option.Trim().ToUpper())
									{
										case "VA": Config.LoadOptions.Add(MemberProcessing.LoadOption.ValidateAddress); break;
										case "VP": Config.LoadOptions.Add(MemberProcessing.LoadOption.ValidatePhone); break;
										case "EA": Config.LoadOptions.Add(MemberProcessing.LoadOption.EnrichAddress); break;
										case "EP": Config.LoadOptions.Add(MemberProcessing.LoadOption.EnrichPhone); break;
										case "EE": Config.LoadOptions.Add(MemberProcessing.LoadOption.EnrichEmail); break;
										case "IT": Config.LoadOptions.Add(MemberProcessing.LoadOption.IncludeTermed); break;
									}
								}
							}
						}
						else
						{
							// we do not care about this table
						}
						continue;
					}
					#endregion

					if (myReader.MoveToContent() != System.Xml.XmlNodeType.Element) continue;

					#region scan depth 1 for records
					if (myReader.Depth == 1)
					{
						string CurrentRecordName = myReader.Name.ToUpperInvariant().Trim();
						if (CurrentRecordName == "COLUMN")
						{
							insideReadableRecord = true;
							// read definition
							DemoColumn myColumn = new DemoColumn();
							if (myReader.MoveToAttribute("Name"))
							{
								string FIELDNAME = myReader.Value.ToUpperInvariant().Trim();
								myColumn.DemoFieldName = FIELDNAME;
								myColumn.DataBureauFieldName = GetDBFieldName(FIELDNAME);
								if (myColumn.DataBureauFieldName == null)
									throw new ApplicationException("E&E field not understood");
							}
							if (myReader.MoveToAttribute("Field"))
							{
								if (string.IsNullOrEmpty(myColumn.DemoFieldName))
									myColumn.DemoFieldName = myReader.Value.Trim();
								myColumn.DataBureauFieldName = myReader.Value.Trim();
								if (myColumn.DataBureauFieldName.ToUpperInvariant() == "ZIP5")
									myColumn.DataBureauFieldName = "Zip";
							}
							if (myReader.MoveToAttribute("Position"))
							{
								myColumn.Position = int.Parse(myReader.Value);
							}
							else
							{
								// AHDB-442: Position gets wrong value if column already exists
								if (Config.Columns.ContainsKey(myColumn.DataBureauFieldName))
									myColumn.Position = Config.Columns.Count - 1;
								else
									myColumn.Position = Config.Columns.Count;
							}
							if (myReader.MoveToAttribute("Offset"))
							{
								myColumn.Offset = int.Parse(myReader.Value);
							}
							if (myReader.MoveToAttribute("Length"))
							{
								myColumn.Length = int.Parse(myReader.Value);
							}
							if ((myColumn.DataBureauFieldName == "DOB") ||
								(myColumn.DataBureauFieldName == "DOD") ||
								(myColumn.DataBureauFieldName == "MspRedetermindationDate") ||
								(myColumn.DataBureauFieldName == "MedicaidRecertificationDate") ||
								(myColumn.DataBureauFieldName == "PlanEffectiveStartDate") ||
								(myColumn.DataBureauFieldName == "PlanEffectiveEndDate"))
							{
								if (myReader.MoveToAttribute("Formats"))
								{
									string split = ",";
									string Value = myReader.Value;
									if (myReader.MoveToAttribute("FormatsDelimiter"))
									{
										split = myReader.Value;
									}
									myColumn.OverrideFormat = Value.Split(new string[] { split }, StringSplitOptions.RemoveEmptyEntries);
								}
							}
							else
							{
								if (myReader.MoveToAttribute("Formats"))
								{
									myColumn.OverrideFormat = new string[1];
									myColumn.OverrideFormat[0] = myReader.Value;
								}
							}
							// save
							Config.Columns[myColumn.DataBureauFieldName] = myColumn;
						}
						else
						{
							insideReadableRecord = false;
						}
						continue;
					}
					#endregion

					#region check for invalid depth (3+)
					if (myReader.Depth > 2)
					{
						throw new ApplicationException("XML is too deep");
					}
					#endregion

					#region read depth 2 where data resides
					while (myReader.Depth == 2)
					{
						myReader.Read();
						while ((myReader.MoveToContent() != System.Xml.XmlNodeType.Element) && myReader.Depth == 2) myReader.Read();
					}
					#endregion

					// we finished reading row, now see if it was readable
					if (insideReadableRecord && insideReadableRecord)
					{
						// we received data
						// moving on
					}
				}
			}
			return Config;
		}

		private static Dictionary<string, string> NameToDBNameMap = new Dictionary<string, string>()
		{
			{ "PLANMEMBERID", "MemberID" },
			{ "HNUM", "McoContractNumber" },
			{ "COVERAGEBEGINDATE", "PlanEffectiveStartDate" },
			{ "COVERAGETERMDATE", "PlanEffectiveEndDate" },
			{ "COVERAGEENDDATE", "PlanEffectiveEndDate" },  // YES 2 different names for same thing???
			{ "FIRSTNAME", "NameFirst" },
			{ "MIDDLEINITIAL", "NameMiddle" },
			{ "LASTNAME", "NameLast" },
			{ "ADDRESS1", "Address1" },
			{ "ADDRESS2", "Address2" },
			{ "CITY", "City" },
			{ "STATE", "State" },
			{ "ZIP", "Zip" },
			{ "ZIP5", "Zip" },
			{ "ZIP4", "ZipPlus4" },
			{ "ZIPPLUS4", "ZipPlus4" },
			{ "COUNTY", "County" },
			{ "PRIMARYPHONE", "PhoneNumberPrimary" },
			{ "ALTERNATEPHONE", "PhoneNumberAlternate" },
			{ "EMAIL", "EmailAddress" },
			{ "GENDER", "Gender" },
			{ "DOB", "DOB" },
			{ "DOD", "DOD" },
			{ "SSN", "SSN" },
			{ "HICN", "HicNumber" },
			{ "MBI", "MBI" },
			{ "BENEFITSET", "BenefitSet" },
			{ "GROUPNUMBER", "GroupNumber" },
			{ "PBPCODE", "PbpCode" },
			{ "LANGUAGE", "Language" },
			{ "BUSINESSSEGMENT", "BusinessSegment" },
			{ "CUSTOMERPROVIDERID", "PCPID" },
			{ "MEDICAIDID", "MedicaidID" },
			{ "REGION", "Region" },
			{ "LOB", "LOB" }
		};

		private static string GetDBFieldName(string FieldName)
		{
			string DBFieldName = null;
			if (NameToDBNameMap.TryGetValue(FieldName, out DBFieldName) == true)
				return DBFieldName;
			return null;
		}

		//private void ConvertConfig(string RootFolder)
		//{
		//	int count = 0;
		//	foreach (string folder in Directory.GetDirectories(RootFolder, "DS*"))
		//	{
		//		foreach (string file in Directory.GetFiles(folder, "DS????.xml"))
		//		{
		//			count++;
		//			try
		//			{
		//				FileProcessing.FormatFile format = new FileProcessing.FormatFile();
		//				DemoConfig config = DemoReader.ReadConfig(file);
		//				if (config.TypeOfParser == DemoType.Delimited)
		//				{
		//					format.FirstRowHasHeader = true;
		//					format.FixedLengthFields = false;
		//					format.FieldDelimiter = config.Delimiter;
		//				}
		//				else if (config.TypeOfParser == DemoType.FixedWidth)
		//				{
		//					format.FirstRowHasHeader = false;
		//					format.FixedLengthFields = true;
		//				}
		//				if (config.hasHeader.HasValue && config.hasHeader.Value == true)
		//				{
		//					if (config.HeaderRegex != null)
		//						format.Header = config.HeaderRegex.ToString();
		//					else if (!string.IsNullOrEmpty(config.HeaderMarker))
		//						format.Header = string.Format("^{0}.*$", config.HeaderMarker);
		//				}
		//				if (config.hasFooter.HasValue && config.hasFooter.Value == true)
		//				{
		//					if (config.FooterRegex != null)
		//						format.Footer = config.FooterRegex.ToString();
		//					else if (!string.IsNullOrEmpty(config.FooterMarker))
		//						format.Footer = string.Format("^{0}.*$", config.FooterMarker);
		//				}
		//				if (!string.IsNullOrEmpty(config.MCOOverride))
		//				{
		//					format.Custom = "McoContractNumber=" + config.MCOOverride;
		//				}

		//				foreach (DemoColumn column in config.Columns.Values.OrderBy(x => x.Position))
		//				{
		//					FileProcessing.FieldDefinition fielddef = new FileProcessing.FieldDefinition();
		//					if (config.TypeOfParser == DemoType.FixedWidth)
		//					{
		//						fielddef.ColumnStart = column.Offset.Value;
		//						fielddef.ColumnEnd = fielddef.ColumnStart + column.Length.Value - 1;
		//						fielddef.MaxLength = column.Length.Value;
		//					}
		//					fielddef.ExternalFieldName = column.DemoFieldName;
		//					fielddef.InternalFieldName = column.DataBureauFieldName;
		//					if (column.OverrideFormat != null && column.OverrideFormat.Count() > 0)
		//					{
		//						fielddef.Format = "";
		//						if (column.OverrideFormat.Count() > 1)
		//							fielddef.Format = "";
		//						foreach (string fmt in column.OverrideFormat)
		//							fielddef.Format += (string.IsNullOrEmpty(fielddef.Format) ? "" : "|") + fmt;
		//					}
		//					format.FieldDefinitions.Add(fielddef);
		//				}

		//				//char[] pathseps = { '\\', '/' };
		//				//string Filename = folder.Substring(folder.LastIndexOfAny(pathseps) + 1) + ".xml";
		//				//FileProcessing.FormatFile.Save(Path.Combine(Path.Combine(ProcessingArgs.Args.ConfigFilePath, "DEMOFORMATS"), Filename), format);
		//				FileProcessing.FormatFile.Save(Path.ChangeExtension(file, ".txt"), format);
		//			}
		//			catch (Exception ex)
		//			{
		//			}
		//		}
		//	}
		//}
	}

	public class DemoReader
    {
		private DataIOReader IOReader = null;
		private DataIOCommand IOCommand = null;
		private DemoConfig Config = null;
		private MemberParser Parser = null;
		private long RecordCount = 0;

		public bool EndOfFile { get { return IOReader != null && IOReader.EndOfStream(); } }
		public long BytesRead { get { return IOReader != null && IOReader.Connection != null ? IOReader.Connection.Position : 0; } }

		public void Initialize(LoadInfo Load)
		{
			// read configuration
			Config = DemoConfig.ReadConfig(Load.ConfigFile);
			if (Config.TypeOfParser == DemoType.NOT_SUPPLIED)
				throw new ApplicationException("Failed to read config file - " + Load.ConfigFile);

			Stream inputstream = File.OpenRead(Load.InputFile);

			// check
			switch (Config.TypeOfParser)
			{
				case DemoType.Delimited:
					IODelimitedCommand commanddelimited = new IODelimitedCommand(inputstream);
					IOCommand = commanddelimited;
					commanddelimited.Delimiter = Config.Delimiter;
					commanddelimited.EscapeSequence = string.Empty;
					// generate header list
					int maxitems = 0;
					foreach (DemoColumn myColumn in Config.Columns.Values)
					{
						if (myColumn.Position.HasValue)
						{
							if (maxitems <= myColumn.Position.Value)
							{
								maxitems = myColumn.Position.Value + 1;
							}
						}
					}

					// build the header
					string HEADER = string.Empty;
					for (int index = 0; index < maxitems; index++)
					{
						// look for item
						List<DemoColumn> myList = new List<DemoColumn>();
						foreach (DemoColumn myColumn in Config.Columns.Values)
						{
							if (myColumn.Position.HasValue)
							{
								if (myColumn.Position.Value == index)
								{
									myList.Add(myColumn);
								}
							}
						}

						string COLNAME = string.Empty;
						foreach (DemoColumn item in myList)
						{
							if (string.IsNullOrEmpty(COLNAME))
							{
								COLNAME = item.DataBureauFieldName;
							}
						}
						if (string.IsNullOrEmpty(COLNAME)) COLNAME = "dontcare";
						HEADER += string.IsNullOrEmpty(HEADER) ? COLNAME : Config.Delimiter + COLNAME;
					}
					commanddelimited.Header = HEADER;
					break;
				case DemoType.FixedWidth:
					IOFixedCommand commandfixed = new IOFixedCommand(inputstream);
					IOCommand = commandfixed;
					foreach (DemoColumn myColumn in Config.Columns.Values)
					{
						commandfixed.AddFieldDescriptor(myColumn.DataBureauFieldName, myColumn.Offset.Value, myColumn.Length.Value);
					}
					break;
			}

			if (Config.hasHeader.HasValue)
			{
				IOCommand.HeaderPresent = Config.hasHeader.Value;
				if (IOCommand.HeaderPresent)
				{
					IOCommand.QueryHeaderSkip = ((string Line) => Config.QueryHeaderSkip(Line));
				}
			}
			if (Config.hasFooter.HasValue)
			{
				IOCommand.FooterPresent = Config.hasFooter.Value;
				if (IOCommand.FooterPresent)
				{
					IOCommand.QueryFooterSkip = ((string Line) => Config.QueryFooterSkip(Line));
				}
			}
			if (Config.ExtraInfoMarker != null)
			{
				IOCommand.ExtraInfoMarker = Config.ExtraInfoMarker;
			}

			// Start reading the file
			IOReader = IOCommand.ExecuteReader();

			// populate fields for output
			Parser = new MemberParser();
			foreach (KeyValuePair<string, DemoColumn> myPair in Config.Columns)
			{
				string XMLName = myPair.Key;

				// check if in compound
				if ((Config.TypeOfParser != DemoType.FixedWidth) && (myPair.Value.Length.HasValue))
				{
					Parser.AddField(XMLName, "{0:" + myPair.Value.Length.ToString() + "}");
				}
				else
				{
					string format = null;
					if (myPair.Value.OverrideFormat != null)
					{
						if (myPair.Value.OverrideFormat.Length > 0)
						{
							format = myPair.Value.OverrideFormat[0];
						}
					}
					Parser.AddField(XMLName, format);
				}
			}

			// check for mco override
			if (!string.IsNullOrEmpty(Config.MCOOverride))
			{
				Parser.AddOverrideField("McoContractNumber", Config.MCOOverride);
			}
			if (Config.Columns.ContainsKey("DOB"))
			{
				string[] format = Config.Columns["DOB"].OverrideFormat;
				Parser.AddDateField("DOB", format);
			}
			if (Config.Columns.ContainsKey("DOD"))
			{
				string[] format = Config.Columns["DOD"].OverrideFormat;
				Parser.AddDateField("DOD", format);
			}
			if (Config.Columns.ContainsKey("PlanEffectiveStartDate"))
			{
				string[] format = Config.Columns["PlanEffectiveStartDate"].OverrideFormat;
				Parser.AddDateField("PlanEffectiveStartDate", format);
			}
			if (Config.Columns.ContainsKey("PlanEffectiveEndDate"))
			{
				string[] format = Config.Columns["PlanEffectiveEndDate"].OverrideFormat;
				Parser.AddDateField("PlanEffectiveEndDate", format);
			}
			if (Config.Columns.ContainsKey("MspRedetermindationDate"))
			{
				string[] format = Config.Columns["MspRedetermindationDate"].OverrideFormat;
				Parser.AddDateField("MspRedetermindationDate", format);
			}
			if (Config.Columns.ContainsKey("MedicaidRecertificationDate"))
			{
				string[] format = Config.Columns["MedicaidRecertificationDate"].OverrideFormat;
				Parser.AddDateField("MedicaidRecertificationDate", format);
			}

			RecordCount = 0;
			Load.ExtraFileInfo = ((DataIOReader) IOReader).ExtraInfoLine;
		}

		public void Close()
		{
			if (IOCommand != null)
			{
				IOCommand.Dispose();
				IOCommand = null;
			}
		}

		public PMMember GetNextMember()
		{
			PMMember Member = null;
			try
			{
				if (IOReader.Read(Config.NullString) == false)
					return null;

				RecordCount++;
				if (!IOReader.IsRowValid(Config.StrictColumnCount))
				{
					throw new Exception("Invalid column count - record " + RecordCount.ToString());
				}

				// Create the member with data from the file and hand it off to the processing callback
				Member = new PMMember();
				Member.RecordID = RecordCount;
				Member.BytesRead = IOReader.Connection.Position;
				Member.RecordPair("RecordID", RecordCount.ToString());
				Parser.ProcessMemberLine(IOReader, Member);
			}
			catch (Exception ex)
			{
				throw new Exception("Fatal error at record " + RecordCount.ToString() + ": " + ex.Message);
			}
			return Member;
		}
	}

    public class MemberParser
    {
        private Dictionary<string, string> FieldAndFormat;
        private List<KeyValuePair<int, string>> OrdinalToField;
        private Dictionary<string, List<string>> AlternateFormats;
        private Dictionary<string, string> OverrideValues;
		private List<string> DateFields;

		public MemberParser()
        {
            FieldAndFormat = new Dictionary<string,string>();
            OrdinalToField = null;
            DateFields = new List<string>();
            AlternateFormats = new Dictionary<string, List<string>>();
            OverrideValues = new Dictionary<string, string>();
		}

        public void AddField(string FieldName, string Format = null)
        {
            string FIELDNAME = FieldName.ToUpperInvariant().Trim();
			FieldAndFormat[FIELDNAME] = Format;
        }

        public void AddDateField(string FieldName, string[] FormatList)
        {
			// Use format specified in config file as primary, other standard formats as alternates
			List<string> Formats = new List<string>();
			if (FormatList != null)
			{
				Formats = FormatList.ToList();
				Formats.AddRange(DemoConfig.DEMODateFormat);
			}
			else
			{
				Formats = DemoConfig.DEMODateFormat.ToList();
			}
			AddDateField(FieldName, Formats[0]);
            for (int Index = 1; Index < Formats.Count; Index++)
            {
                AddAlternateFormat(FieldName, Formats[Index]);
            }
        }

        public void AddDateField(string FieldName, string Format = null)
        {
            string FIELDNAME = FieldName.ToUpperInvariant().Trim();
            FieldAndFormat[FIELDNAME] = Format;
            int POS = DateFields.BinarySearch(FIELDNAME);
            if (POS < 0)
            {
                DateFields.Insert(~POS, FIELDNAME);
            }
        }

        public void AddAlternateFormat(string FieldName, string Format)
        {
            string FIELDNAME = FieldName.ToUpperInvariant().Trim();
            List<string> FORMATS;
            if (!AlternateFormats.TryGetValue(FIELDNAME, out FORMATS))
            {
                FORMATS = new List<string>();
                AlternateFormats[FIELDNAME] = FORMATS;
            }
            int POS = FORMATS.BinarySearch(Format);
            if (POS < 0) FORMATS.Insert(~POS, Format);
        }

        public void AddOverrideField(string FieldName, string Value)
        {
            AddField(FieldName);
            OverrideValues[FieldName.ToUpperInvariant().Trim()] = Value;
        }

		public string TrimLimit(string input, int length)
		{
			if (input == null) return string.Empty;
			if (length < 0)
			{
				// trim limit from end
				int taillenght = -length;
				if (input.Length <= length) return input.Trim();
				return (input.Substring(input.Length - taillenght, taillenght).Trim());
			}
			if (input.Length <= length) return input.Trim();
			return (input.Substring(0, length).Trim());
		}

		public void ProcessMemberLine(DataIOReader myReader, PMMember Member)
        {
            int override_counter = -1;
            if (OrdinalToField == null)
            {
				// build field to ordinal mapping
				OrdinalToField = new List<KeyValuePair<int,string>>();
                foreach (string Key in FieldAndFormat.Keys)
                {
                    int ordinal;
                    if (OverrideValues.ContainsKey(Key))
                    {
                        ordinal = override_counter;
                        override_counter--;
                    }
                    else
                    {
                        ordinal = myReader.GetOrdinal(Key);
					}
					OrdinalToField.Add(new KeyValuePair<int, string>(ordinal, Key));
				}
			}

			foreach (KeyValuePair<int, string> pair in OrdinalToField)
            {
                if (myReader.IsDBNull(pair.Key)) continue;
                string Value;

                // check override
                if (pair.Key < 0)
                {
                    Value = OverrideValues[pair.Value];
                }
				else
				{
                    Value = myReader.GetString(pair.Key);
                    if (Value.Contains("\0"))
                    {
                        Value = Value.Replace("\0", string.Empty);
                    }
                    if (Value.Contains("\x1a"))
                    {
                        Value = Value.Replace("\x1a", string.Empty);
                    }
                }
                if (string.IsNullOrEmpty(Value)) continue;

                // check type
                int POS = DateFields.BinarySearch(pair.Value);
                if (POS >= 0)
                {
                    // this is date field
                    string FORMAT = FieldAndFormat[pair.Value];
                    List<string> Formats = new List<string>();
                    Formats.Add(FORMAT);
                    if (AlternateFormats.ContainsKey(pair.Value))
                    {
                        Formats.AddRange(AlternateFormats[pair.Value]);
                    }
                    string[] DATE_FORMAT_ARRAY = Formats.ToArray();
                    DateTime InputValue;
                    bool OK = false;
                    if (string.IsNullOrEmpty(FORMAT))
                    {
                        OK = DateTime.TryParse(Value, out InputValue);
                    }
                    else
                    {
                        OK = DateTime.TryParseExact(Value, DATE_FORMAT_ARRAY, null, System.Globalization.DateTimeStyles.None, out InputValue);
						// The following code fails for PlanEffectiveEndDate and MspRedetermindationDate, which can legitimately be in the future.
						// Code removed by PPD 3/28/2023
						if (OK && pair.Value != "PlanEffectiveEndDate" && pair.Value == "MspRedetermindationDate")
						{
							if (AlternateFormats.ContainsKey(pair.Value))
							{
								if (InputValue > DateTime.Now)
									InputValue = InputValue.AddYears(-100);
							}
						}
					}
					// write output
					if (OK)
                    {
						Member.RecordPair(pair.Value, InputValue.ToString(FieldValidator.DATE));
                    }
                    continue;
                }

				// otherwise it is string - but check for format
				string FORMATSTR = FieldAndFormat[pair.Value];
                if (string.IsNullOrEmpty(FORMATSTR))
                {
					Member.RecordPair(pair.Value, Value);
                }
                else
                {
                    // {0,-10:10} - this is my version with "precision"
                    // {0,-10} standard

                    // {0,10} - left space pad to 10 characters if less than 10
                    // {0,-10} - right space pad to 10 characters if less than 10

                    // {0,-10:10} - left space pad to 10 characters, truncate at 10 if longer

                    // {0,-2:-2} - left space pad to 2 characters, truncate at 2 char from right (last 2 characters)
                    if (FORMATSTR.Contains(':'))
                    {
                        // mine
                        int pos1 = FORMATSTR.IndexOf(':');
                        int pos2 = FORMATSTR.IndexOf('}');
                        string LIMIT = FORMATSTR.Substring(pos1 + 1, pos2 - pos1 - 1);
                        string FORMATOUT = FORMATSTR.Substring(0, pos1) + FORMATSTR.Substring(pos2);
                        int limit = int.Parse(LIMIT);
                        string LimitValue = TrimLimit(Value, limit);
						Member.RecordPair(pair.Value, string.Format(FORMATOUT, LimitValue));
                    }
                    else
                    {
						// standard
						Member.RecordPair(pair.Value, string.Format(FORMATSTR, Value));
                    }
                }
            }
        }
    }
}
