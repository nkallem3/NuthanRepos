﻿using System;
using System.Collections.Generic;

using ContactDataLib;
using Logging;

namespace MemberProcessing
{
	public class Scrubbing
	{
		private LoadInfo Load = null;

		public void Initialize(LoadInfo load)
		{
			Load = load;
		}

		public void LogStats()
		{
			if (Load.LoadOptions.Contains(LoadOption.NoValidation))
				return;

			Logger.LogString("Invalid field counts:");
			foreach (string Field in Load.Stats.Invalid.GetFields())
				Logger.LogString(FormatStat(Field, "invalid", Load.Stats.Invalid.GetCount(Field), Load.RecordCount));
			Logger.LogString("Removed field counts:");
			foreach (string Field in Load.Stats.Removed.GetFields())
				Logger.LogString(FormatStat(Field, "removed", Load.Stats.Removed.GetCount(Field), Load.RecordCount));
			Logger.LogString("Altered field counts:");
			foreach (string Field in Load.Stats.Altered.GetFields())
				Logger.LogString(FormatStat(Field, "altered", Load.Stats.Altered.GetCount(Field), Load.RecordCount));
			Logger.LogString("Validation stats:");
			foreach (string Field in Load.Stats.ScrubTried.GetFields())
				Logger.LogString(FormatStat(Field, "validated", Load.Stats.Scrubbed.GetCount(Field), Load.Stats.ScrubTried.GetCount(Field)));
		}

		private string FormatStat(string name, string op, long number, long total)
		{
			string result = "     " + name + " - ";
			if (total == 0)
				result += "(none)";
			else
				result += string.Format("{0:N0} {1} of {2:N0} considered ({3:0.0}%)", number, op, total, (double) number * 100 / total);
			return result;
		}

		public void ScrubMember(PMMember Member)
		{
			if (Load.LoadOptions.Contains(LoadOption.NoValidation))
				return;

			Member.OnFieldChanged = OnFieldChanged;

			CapitalizeName(Member, "NAMELAST");
			CapitalizeName(Member, "NAMEMIDDLE");
			CapitalizeName(Member, "NAMEFIRST");
			CapitalizeName(Member, "POANAMELAST");
			CapitalizeName(Member, "POANAMEMIDDLE");
			CapitalizeName(Member, "POANAMEFIRST");
			CapitalizeName(Member, "PARENTNAMELAST");
			CapitalizeName(Member, "PARENTNAMEMIDDLE");
			CapitalizeName(Member, "PARENTNAMEFIRST");
			CapitalizeName(Member, "PCPNAMELAST");
			CapitalizeName(Member, "PCPNAMEFIRST");

			// format and validate all phone numbers (invalid numbers are removed!!)
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERPRIMARY);
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERALTERNATE);
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERALTERNATE2);
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERALTERNATE3);
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERMOBILE);
			CleanupPhoneNumber(Member, PMMember.PHONENUMBERWORK);
			CleanupPhoneNumber(Member, PMMember.POAPHONENUMBERPRIMARY);

			// promote Alternate or Mobile to Primary
			string PrimaryNumber = Member.GetStringData(PMMember.PHONENUMBERPRIMARY);
			string AlternateNumber = Member.GetStringData(PMMember.PHONENUMBERALTERNATE);
			string AlternateNumber2 = Member.GetStringData(PMMember.PHONENUMBERALTERNATE2);
			string AlternateNumber3 = Member.GetStringData(PMMember.PHONENUMBERALTERNATE3);
			string MobileNumber = Member.GetStringData(PMMember.PHONENUMBERMOBILE);
			if (string.IsNullOrEmpty(PrimaryNumber))
			{
				// Primary number missing - promote an alternate if we have one
				if (!string.IsNullOrEmpty(AlternateNumber))
				{
					Member.RecordPair(PMMember.PHONENUMBERPRIMARY, AlternateNumber, "Alternate phone number promoted to Primary");
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE, "Alternate phone number promoted to Primary");
				}
				else if (!string.IsNullOrEmpty(AlternateNumber2))
				{
					Member.RecordPair(PMMember.PHONENUMBERPRIMARY, AlternateNumber2, "Alternate2 phone number promoted to Primary");
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE2, "Alternate2 phone number promoted to Primary");
				}
				else if (!string.IsNullOrEmpty(AlternateNumber3))
				{
					Member.RecordPair(PMMember.PHONENUMBERPRIMARY, AlternateNumber3, "Alternate3 phone number promoted to Primary");
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE3, "Alternate3 phone number promoted to Primary");
				}
				else if (!string.IsNullOrEmpty(MobileNumber))
				{
					Member.RecordPair(PMMember.PHONENUMBERPRIMARY, MobileNumber, "Mobile phone number promoted to Primary");
					Member.RemoveData(PMMember.PHONENUMBERMOBILE, "Mobile phone number promoted to Primary");
				}
			}
			else
			{
				// Primary number exists - remove any alternate numbers that are the same
				if (AlternateNumber == PrimaryNumber)
				{
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE, "Alternate phone number same as Primary");
				}
				if (AlternateNumber2 == PrimaryNumber)
				{
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE2, "Alternate2 phone number same as Primary");
				}
				if (AlternateNumber3 == PrimaryNumber)
				{
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE3, "Alternate3 phone number same as Primary");
				}
			}

			// commercial plan id
			string PlanID = Member.GetStringData(PMMember.COMMERCIALPLANID);
			if (!string.IsNullOrEmpty(PlanID))
			{
				string PlanIDFormatted = FieldValidator.FormatField(PlanID, FieldType.TCommercialPlanID);
				if (PlanIDFormatted != PlanID)
				{
					Member.RecordPair(PMMember.COMMERCIALPLANID, PlanIDFormatted, "Non alpha/numeric removed");
				}
				// Not sure why the plan ID is not validated??
			}

			// Plan effective start date
			string planeffectivestartdate = Member.GetStringData(PMMember.PLANEFFECTIVESTARTDATE);
			DateTime? ValidPESD = null;
			if (!string.IsNullOrEmpty(planeffectivestartdate))
			{
				ValidPESD = FieldValidator.ToDate(planeffectivestartdate);
				if (!ValidPESD.HasValue)
				{
					// invalid date
					Member.RemoveData(PMMember.PLANEFFECTIVESTARTDATE, "Invalid date");
					Member.RecordInvalid(PMMember.PLANEFFECTIVESTARTDATE);
				}
				else if (ValidPESD > Load.EffectiveDate.AddMonths(2) || ValidPESD < Load.EffectiveDate.AddYears(-30))
				{
					// invalid plan start date
					Member.RemoveData(PMMember.PLANEFFECTIVESTARTDATE, "Plan start date is outside of valid window");
				}
				else
				{
					// valid
					string newvalue = ValidPESD.Value.ToString(FieldValidator.DATE);
					if (newvalue != planeffectivestartdate)
					{
						// format change
						Member.RecordPair(PMMember.PLANEFFECTIVESTARTDATE, newvalue, "Plan start date reformatted");
					}
				}
			}

			// Use the file effective date if the start date is missing for the member
			string PlanEffectiveStartDateValue = Member.GetStringData(PMMember.PLANEFFECTIVESTARTDATE);
			if (string.IsNullOrEmpty(PlanEffectiveStartDateValue))
			{
				Member.RecordPair(PMMember.PLANEFFECTIVESTARTDATE, Load.EffectiveDate.ToString("yyyyMMdd"), "Missing plan start date - using default");
			}

			// Plan effective end date
			string planeffectiveenddate = Member.GetStringData(PMMember.PLANEFFECTIVEENDDATE);
			if (!string.IsNullOrEmpty(planeffectiveenddate))
			{
				DateTime? ValidPEED = FieldValidator.ToDate(planeffectiveenddate);
				if (!ValidPEED.HasValue)
				{
					// invalid date
					Member.RemoveData(PMMember.PLANEFFECTIVEENDDATE, "Invalid date");
					Member.RecordInvalid(PMMember.PLANEFFECTIVEENDDATE);
				}
				else if (ValidPEED > Load.EffectiveDate.AddMonths(2) || ValidPEED < Load.EffectiveDate.AddYears(-30))
				{
					// invalid plan end date
					Member.RemoveData(PMMember.PLANEFFECTIVEENDDATE, "Plan end date is outside of valid window");
				}
				else if (ValidPESD.HasValue && ValidPESD.Value > ValidPEED)
				{
					// end date before start date
					Member.RemoveData(PMMember.PLANEFFECTIVEENDDATE, "Plan end date is before plan start date");
				}
				else
				{
					// valid
					string newvalue = ValidPEED.Value.ToString(FieldValidator.DATE);
					if (newvalue != planeffectiveenddate)
					{
						// format change
						Member.RecordPair(PMMember.PLANEFFECTIVEENDDATE, newvalue, "Plan end date reformatted");
					}
				}
			}

			// Ensure specific format for other date fields
			foreach (string datefield in new List<string>() { "MspRedetermindationDate", "MedicaidRecertificationDate", "PCPDate" })
			{
				string fieldvalue = Member.GetStringData(datefield);
				if (!string.IsNullOrEmpty(fieldvalue))
				{
					DateTime? datevalue = FieldValidator.ToDate(fieldvalue);
					if (!datevalue.HasValue)
					{
						// invalid date
						Member.RecordInvalid(datefield);
					}
					else
					{
						// valid
						string newvalue = datevalue.Value.ToString(FieldValidator.DATE);
						if (newvalue != fieldvalue)
						{
							// format change
							Member.RecordPair(datefield, newvalue, "Date reformatted");
						}
					}
				}
			}

			// Gender
			string gender = Member.GetStringData(PMMember.GENDER);
			if (!string.IsNullOrEmpty(gender))
			{
				string genderformatted = FieldValidator.FormatField(gender, FieldType.TGender);
				if (!FieldValidator.IsFieldValid(genderformatted, FieldType.TGender))
				{
					// invalid gender
					Member.RemoveData(PMMember.GENDER, "Invalid gender");
					Member.RecordInvalid(PMMember.GENDER);
				}
				else if (genderformatted != gender)
				{
					// format change
					Member.RecordPair(PMMember.GENDER, genderformatted, "Gender value reformatted");
				}
			}

			// DOB
			string dob = Member.GetStringData(PMMember.DOB);
			DateTime? ValidDOB = null;
			if (!string.IsNullOrEmpty(dob))
			{
				ValidDOB = FieldValidator.ToDate(dob);
				if (!ValidDOB.HasValue)
				{
					// invalid date
					Member.RemoveData(PMMember.DOB, "Invalid DOB");
					Member.RecordInvalid(PMMember.DOB);
				}
				else if (ValidDOB.Value.Year <= 1890 || ValidDOB.Value > DateTime.Now)
				{
					// invalid DOB for a living person
					Member.RemoveData(PMMember.DOB, "Invalid DOB for a living person");
				}
				else
				{
					// valid
					string newvalue = ValidDOB.Value.ToString(FieldValidator.DATE);
					if (newvalue != dob)
					{
						// format change
						Member.RecordPair(PMMember.DOB, newvalue, "DOB reformatted");
					}
				}
			}

			// DOD
			string dod = Member.GetStringData(PMMember.DOD);
			if (!string.IsNullOrEmpty(dod))
			{
				DateTime? ValidDOD = FieldValidator.ToDate(dod);
				if (!ValidDOD.HasValue)
				{
					// invalid date
					Member.RemoveData(PMMember.DOD, "Invalid DOD");
					Member.RecordInvalid(PMMember.DOD);
				}
				else if (ValidDOD.Value.Year <= 1890 || ValidDOD.Value > DateTime.Now)
				{
					// invalid DOD for a living person
					Member.RemoveData(PMMember.DOD, "Invalid DOD for a living person");
				}
				else if (ValidDOB.HasValue && ValidDOD < ValidDOB)
				{
					// invalid DOD (before DOB)
					Member.RemoveData(PMMember.DOD, "Invalid DOD (before DOB)");
				}
				else
				{
					// valid
					string newvalue = ValidDOD.Value.ToString(FieldValidator.DATE);
					if (newvalue != dod)
					{
						// format change
						Member.RecordPair(PMMember.DOD, newvalue, "DOD reformatted");
					}
				}
			}

			// SSN
			string ssn = Member.GetStringData(PMMember.SSN);
			if (!string.IsNullOrEmpty(ssn))
			{
				string ssnformatted = FieldValidator.FormatField(ssn, FieldType.TSSN);
				if (FieldValidator.IsFieldValid(ssnformatted, FieldType.TSSN) == false)
				{
					// not a valid SSN
					Member.RemoveData(PMMember.SSN, "Invalid SSN");
					Member.RecordInvalid(PMMember.SSN);
				}
				else if (ssnformatted != ssn)
				{
					// format changed
					ssn = ssnformatted;
					Member.RecordPair(PMMember.SSN, ssnformatted, "SSN value reformatted");
				}
			}

			// validate and normalize the address
			CDAddress addrin = Member.GetAddress();
			if (addrin.IsEmpty() == false)
			{
				CDAddress addrout;
				Load.Stats.ScrubTried.Bump(PMMember.ADDRESS);
				if (addrin.MightBeValid())
				{
					if (ValidateAddress(addrin, out addrout))
						Load.Stats.Scrubbed.Bump(PMMember.ADDRESS);
					Member.UpdateAddress(addrout);
					if (CDAddress.AddressIsSame(addrin, addrout) == false)
						Member.FieldChanged(PMMember.ADDRESS, addrin.ToCacheKey(), addrout.ToCacheKey(), "Melissa Data validation");
				}
			}

			// validate and normalize the POA address
			CDAddress poaaddrin = Member.GetPOAAddress();
			if (poaaddrin.IsEmpty() == false)
			{
				CDAddress poaaddrout;
				Load.Stats.ScrubTried.Bump(PMMember.POAADDRESS);
				if (poaaddrin.MightBeValid())
				{
					if (ValidateAddress(poaaddrin, out poaaddrout))
						Load.Stats.Scrubbed.Bump(PMMember.POAADDRESS);
					Member.UpdatePOAAddress(poaaddrout);
					if (CDAddress.AddressIsSame(poaaddrin, poaaddrout) == false)
						Member.FieldChanged(PMMember.POAADDRESS, poaaddrin.ToCacheKey(), poaaddrout.ToCacheKey(), "Melissa Data validation");
				}
			}

			CleanupHICN(Member, Load.MBIHICNCrosswalk);
		}

		private void CapitalizeName(PMMember Member, string FieldName)
		{
			string Value = Member.GetStringData(FieldName);
			if (!string.IsNullOrEmpty(Value))
			{
				string fmtVAL = Value.ToUpperInvariant();
				if (fmtVAL != Value)
				{
					// format changed
					Member.RecordPair(FieldName, fmtVAL, "Name capitalized");
				}
			}
		}

		private void CleanupPhoneNumber(PMMember Member, string PhoneFieldName)
		{
			string number = Member.GetStringData(PhoneFieldName);
			if (!string.IsNullOrEmpty(number))
			{
				long num;
				string fmtVAL = FieldValidator.FormatField(number, FieldType.TUSPhoneNumber);
				Load.Stats.ScrubTried.Bump(PhoneFieldName);

				// First check if the number is clearly invalid (not a number or area code between 200 and 999)
				if (long.TryParse(fmtVAL, out num) == false || num < 2000000000 || num > 9999999999)
				{
					// invalid phone number
					Member.RemoveData(PhoneFieldName, "Invalid phone number");
					Member.RecordInvalid(PhoneFieldName);
					return;
				}

				CDPhone PhoneIn = new CDPhone(fmtVAL, null);
				CDPhone PhoneOut;
				if (ValidatePhone(PhoneIn, out PhoneOut) == false)
				{
					// invalid phone number
					Member.RemoveData(PhoneFieldName, "Phone number is not callable");
				}
				else
				{
					// valid number
					Load.Stats.Scrubbed.Bump(PhoneFieldName);
					if (fmtVAL != number)
					{
						// format changed
						Member.RecordPair(PhoneFieldName, fmtVAL, "Phone number reformatted");
					}
				}
			}
		}

		public bool ValidatePhone(CDPhone PhoneIn, out CDPhone PhoneOut)
		{
			bool result = true;

			// 1) Check historical data, 2) Check Melissa Data, 3) Check old phone validator
			if ((PhoneOut = Load.History.GetPhoneHistory(PhoneIn)) != null)
			{
				result = PhoneOut.IsValid();
			}
			else if (ProcessArgs.MelissaData != null && Load.LoadOptions.Contains( LoadOption.ValidatePhone))
			{
				ProcessArgs.MelissaData.PhoneVerify(PhoneIn, out PhoneOut);
				Load.History.SetPhoneHistory(PhoneIn, PhoneOut);
				result = PhoneOut.IsValid();
			}
			else
			{
				PhoneOut = PhoneIn;
				result = FieldValidator.IsFieldValid(PhoneIn.PhoneNumber, FieldType.TUSPhoneNumber);
			}

			return result;
		}

		public bool ValidateAddress(CDAddress AddressIn, out CDAddress AddressOut)
		{
			bool result = true;

			// 1) Check historical data, 2) Check Melissa Data, 3) Check old address validator
			if ((AddressOut = Load.History.GetAddressHistory(AddressIn)) != null)
			{
				result = AddressOut.IsValid();
			}
			else if (ProcessArgs.MelissaData != null && Load.LoadOptions.Contains(LoadOption.ValidatePhone))
			{
				ProcessArgs.MelissaData.AddressVerify(AddressIn, out AddressOut);
				Load.History.SetAddressHistory(AddressIn, AddressOut);
				result = AddressOut.IsValid();
			}
			else
			{
				AddressOut = AddressIn;
				result = AddressOut.IsValid();
			}

			return result;
		}

		private void CleanupHICN(PMMember Member, MBIHICNCrosswalk MBIHICNCrosswalk)
		{
			string MBI = Member.GetStringData(PMMember.MBI);
			string HICN = Member.GetStringData(PMMember.HICNUMBER);
			string HICALT = Member.GetStringData(PMMember.HICNUMBERALTERNATE);

			// Validate the MBI and check if it might really be a HICN
			if (!string.IsNullOrEmpty(MBI))
			{
				if (FieldValidator.IsFieldValid(MBI, FieldType.THICNumber) && string.IsNullOrEmpty(HICN))
				{
					// MBI is really a HICN
					HICN = MBI;
					Member.RecordPair(PMMember.HICNUMBER, HICN, "MBI value is really a HICN");
				}
				if (FieldValidator.IsFieldValid(MBI, FieldType.TMBI) == false)
				{
					// MBI is invalid
					MBI = null;
					//Member.RemoveData(PMMember.MBI, "Invalid MBI value");
					Member.RecordInvalid(PMMember.MBI);
				}
			}

			// Validate the HICN and check if it might really be an MBI
			if (!string.IsNullOrEmpty(HICN))
			{
				if (FieldValidator.IsFieldValid(HICN, FieldType.TMBI) && string.IsNullOrEmpty(MBI))
				{
					// HICN is really an MBI
					MBI = HICN;
					Member.RecordPair(PMMember.MBI, MBI, "HICN value is really an MBI");
				}
				if (FieldValidator.IsFieldValid(HICN, FieldType.THICNumber) == false)
				{
					// HICN is invalid
					HICN = null;
					//Member.RemoveData(PMMember.HICNUMBER, "Invalid HICN value");
					Member.RecordInvalid(PMMember.HICNUMBER);
				}
			}

			// Validate the alternate HICN and check if it might really be an MBI
			if (!string.IsNullOrEmpty(HICALT))
			{
				if (FieldValidator.IsFieldValid(HICALT, FieldType.TMBI) && string.IsNullOrEmpty(MBI))
				{
					// Alternate HICN is really an MBI
					MBI = HICALT;
					Member.RecordPair(PMMember.MBI, MBI, "Alternate HICN value is really an MBI");
				}
				if (FieldValidator.IsFieldValid(HICALT, FieldType.THICNumber) == false)
				{
					// Alt HICN is invalid
					HICALT = null;
					//Member.RemoveData(PMMember.HICNUMBERALTERNATE, "Invalid HICN value");
					Member.RecordInvalid(PMMember.HICNUMBERALTERNATE);
				}
				else if (string.IsNullOrEmpty(HICN))
				{
					HICN = HICALT;
					Member.RecordPair(PMMember.HICNUMBER, MBI, "Alternate HICN promoted to primary");
					Member.RemoveData(PMMember.HICNUMBERALTERNATE, "Alternate HICN promoted to primary");
				}
			}

			// Populate either the HICN or MBI using the crosswalk
			if (MBIHICNCrosswalk != null)
			{
				if (!string.IsNullOrEmpty(HICN) && string.IsNullOrEmpty(MBI))
				{
					string Lookup = MBIHICNCrosswalk.HICtoMBI(HICN);
					if (!string.IsNullOrEmpty(Lookup))
					{
						Member.RecordPair(PMMember.MBI, Lookup, "HICN-to-MBI crosswalk");
					}
				}
				else if (!string.IsNullOrEmpty(MBI) && string.IsNullOrEmpty(HICN))
				{
					string Lookup = MBIHICNCrosswalk.MBItoHIC(MBI);
					if (!string.IsNullOrEmpty(Lookup))
					{
						Member.RecordPair(PMMember.HICNUMBER, Lookup, "MBI-to-HICN crosswalk");
					}
				}
			}
		}

		private void OnFieldChanged(FieldChange change)
		{
			string KEY = change.Field;
			if (change.NewValue == null)
				Load.Stats.Invalid.Bump(KEY);
			else if (string.IsNullOrEmpty(change.NewValue))
				Load.Stats.Removed.Bump(KEY);
			else
				Load.Stats.Altered.Bump(KEY);
		}
	}
}
