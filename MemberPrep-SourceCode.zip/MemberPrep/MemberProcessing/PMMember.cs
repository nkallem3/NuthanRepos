﻿using System;
using System.Collections.Generic;
using System.Linq;

using ContactDataLib;

namespace MemberProcessing
{
	public delegate void OnFieldChangedDelegate(FieldChange change);

	public class FieldChange
	{
		public DateTime TimeStamp;
		public long RecordID = 0;
		public string MemberID = string.Empty;
		public string Field = string.Empty;
		public string OldValue = string.Empty;
		public string NewValue = string.Empty;
		public string Note = string.Empty;
	}

	public class PMMember
    {
		// Primary field names
		public const string PLANEFFECTIVEENDDATE = "PLANEFFECTIVEENDDATE";
		public const string PLANEFFECTIVESTARTDATE = "PLANEFFECTIVESTARTDATE";
		public const string MEMBERID = "MEMBERID";
		public const string MCOCONTRACTNUMBER = "MCOCONTRACTNUMBER";
		public const string NAMEFIRST = "NAMEFIRST";
		public const string NAMEMIDDLE = "NAMEMIDDLE";
		public const string NAMELAST = "NAMELAST";
		public const string ADDRESS = "ADDRESS";
		public const string ADDRESS1 = "ADDRESS1";
		public const string ADDRESS2 = "ADDRESS2";
		public const string CITY = "CITY";
		public const string STATE = "STATE";
		public const string ZIP = "ZIP";
		public const string ZIP11 = "ZIP11";
		public const string COUNTY = "COUNTY";
		public const string STATEANDCOUNTYCODE = "STATEANDCOUNTYCODE";
		public const string PHONENUMBERPRIMARY = "PHONENUMBERPRIMARY";
		public const string PHONENUMBERALTERNATE = "PHONENUMBERALTERNATE";
		public const string PHONENUMBERALTERNATE2 = "PHONENUMBERALTERNATE2";
		public const string PHONENUMBERALTERNATE3 = "PHONENUMBERALTERNATE3";
		public const string PHONENUMBERWORK = "PHONENUMBERWORK";
		public const string PHONENUMBERMOBILE = "PHONENUMBERMOBILE";
		public const string EMAILADDRESS = "EMAILADDRESS";
		public const string GENDER = "GENDER";
		public const string DOB = "DOB";
		public const string DOD = "DOD";
		public const string SSN = "SSN";
		public const string MBI = "MBI";
		public const string HICNUMBER = "HICNUMBER";
		public const string HICNUMBERALTERNATE = "HICNUMBERALTERNATE";
		public const string COMMERCIALPLANID = "COMMERCIALPLANID";
		public const string POAADDRESS = "POAADDRESS";
		public const string POAADDRESS1 = "POAADDRESS1";
		public const string POAADDRESS2 = "POAADDRESS2";
		public const string POACITY = "POACITY";
		public const string POASTATE = "POASTATE";
		public const string POAZIP = "POAZIP";
		public const string POAPHONENUMBERPRIMARY = "POAPHONENUMBERPRIMARY";

		public long RecordID = 0;
		public long BytesRead = 0; // used to track percent complete
		public List<string> NeedsEnrichment = null;
		public List<FieldChange> FieldChanges { get { return DataChanges.ToList(); } }
		public OnFieldChangedDelegate OnFieldChanged { get; set; }

		private Dictionary<string, string> Data;
		private List<FieldChange> DataChanges;

		public PMMember()
        {
			RecordID = 0;
			NeedsEnrichment = new List<string>();
			Data = new Dictionary<string, string>();
			DataChanges = new List<FieldChange>();
		}

        public void RecordPair(string Key, string Value, string Note = null)
        {
			string KEY = Key.ToUpperInvariant();
			if (!string.IsNullOrEmpty(Note))
			{
				string OldValue = GetStringData(KEY);
				if (Value != OldValue)
					FieldChanged(KEY, OldValue, Value, Note);
			}
			if (Data.ContainsKey(KEY))
				Data[KEY] = Value;
			else
				Data.Add(KEY, Value);
		}

		public void RemoveData(string Key, string Note = null)
        {
			string KEY = Key.ToUpperInvariant();
			if (!string.IsNullOrEmpty(Note))
			{
				string OldValue = GetStringData(KEY);
				if (!string.IsNullOrEmpty(OldValue))
					FieldChanged(KEY, OldValue, "", Note);
			}
			Data.Remove(KEY);
		}

		public void RecordInvalid(string Key)
		{
			string KEY = Key.ToUpperInvariant();
			FieldChanged(KEY, GetStringData(KEY), null, null);
		}

		public string GetStringData(string Key)
		{
			string KEY = Key.ToUpperInvariant();
			string Value = null;
			if (Data.TryGetValue(KEY, out Value) == false)
			{
				Value = string.Empty;
			}
			return Value;
		}

		public void FieldChanged(string Field, string OldValue, string NewValue, string Note)
		{
			FieldChange change = new FieldChange();
			change.TimeStamp = DateTime.Now;
			change.RecordID = RecordID;
			change.MemberID = GetStringData(PMMember.MEMBERID);
			change.Field = Field;
			change.OldValue = OldValue;
			change.NewValue = NewValue;
			change.Note = Note;
			DataChanges.Add(change);
			if (OnFieldChanged != null)
				OnFieldChanged(change);
		}

		public CDAddress GetAddress()
		{
			CDAddress Address = new CDAddress();
			Address.Line1 = GetStringData(PMMember.ADDRESS1);
			Address.Line2 = GetStringData(PMMember.ADDRESS2);
			Address.City = GetStringData(PMMember.CITY);
			Address.County = GetStringData(PMMember.COUNTY);
			Address.FIPSCode = GetStringData(PMMember.STATEANDCOUNTYCODE);
			Address.State = GetStringData(PMMember.STATE);
			string zip = GetStringData(PMMember.ZIP);
			if (!string.IsNullOrEmpty(zip))
			{
				zip = FieldValidator.FormatField(zip, FieldType.TInteger);
				if (zip.Length >= 5)
					Address.Zip = zip.Substring(0, 5);
				if (zip.Length >= 9)
					Address.Plus4 = zip.Substring(5, 4);
			}
			Address.Zip11 = GetStringData(PMMember.ZIP11);
			return Address;
		}

		public void UpdateAddress(CDAddress Address)
		{
			RemoveData(PMMember.ADDRESS1);
			RemoveData(PMMember.ADDRESS2);
			RemoveData(PMMember.CITY);
			RemoveData(PMMember.COUNTY);
			RemoveData(PMMember.ZIP);
			RemoveData(PMMember.STATE);
			RemoveData(PMMember.STATEANDCOUNTYCODE);
			RemoveData(PMMember.ZIP11);

			if (!string.IsNullOrEmpty(Address.Line1)) RecordPair(PMMember.ADDRESS1, Address.Line1);
			string address2 = Address.Line2;
			if (string.IsNullOrEmpty(address2))
			{
				address2 = Address.Suite;
			}
			else
			{
				if (!string.IsNullOrEmpty(Address.Suite))
				{
					address2 += " " + Address.Suite;
				}
			}
			if (!string.IsNullOrEmpty(address2)) RecordPair(PMMember.ADDRESS2, address2);
			if (!string.IsNullOrEmpty(Address.City)) RecordPair(PMMember.CITY, Address.City);
			if (!string.IsNullOrEmpty(Address.County)) RecordPair(PMMember.COUNTY, Address.County);
			string zipout = string.Empty;
			if (!string.IsNullOrEmpty(Address.Zip))
			{
				zipout = Address.Zip.PadLeft(5, '0');
				if (!string.IsNullOrEmpty(Address.Plus4))
				{
					zipout += Address.Plus4.PadLeft(4, '0');
				}
			}
			if (!string.IsNullOrEmpty(zipout)) RecordPair(PMMember.ZIP, zipout);
			if (!string.IsNullOrEmpty(Address.State)) RecordPair(PMMember.STATE, Address.State);
			if (!string.IsNullOrEmpty(Address.FIPSCode)) RecordPair(PMMember.STATEANDCOUNTYCODE, Address.FIPSCode);
			if (!string.IsNullOrEmpty(Address.Zip11)) RecordPair(PMMember.ZIP11, Address.Zip11);
		}

		public CDAddress GetPOAAddress()
		{
			CDAddress Address = new CDAddress();
			Address.Line1 = GetStringData(PMMember.POAADDRESS1);
			Address.Line2 = GetStringData(PMMember.POAADDRESS2);
			Address.City = GetStringData(PMMember.POACITY);
			Address.State = GetStringData(PMMember.POASTATE);
			string zip = GetStringData(PMMember.POAZIP);
			if (!string.IsNullOrEmpty(zip))
			{
				zip = FieldValidator.FormatField(zip, FieldType.TInteger);
				if (zip.Length >= 5)
					Address.Zip = zip.Substring(0, 5);
				if (zip.Length >= 9)
					Address.Plus4 = zip.Substring(5, 4);
			}
			return Address;
		}

		public void UpdatePOAAddress(CDAddress Address)
		{
			RemoveData(PMMember.POAADDRESS1);
			RemoveData(PMMember.POAADDRESS2);
			RemoveData(PMMember.POACITY);
			RemoveData(PMMember.POASTATE);
			RemoveData(PMMember.POAZIP);
			if (!string.IsNullOrEmpty(Address.Line1)) RecordPair(PMMember.POAADDRESS1, Address.Line1);
			string address2 = Address.Line2;
			if (string.IsNullOrEmpty(address2))
			{
				address2 = Address.Suite;
			}
			else
			{
				if (!string.IsNullOrEmpty(Address.Suite))
				{
					address2 += " " + Address.Suite;
				}
			}
			if (!string.IsNullOrEmpty(address2)) RecordPair(PMMember.POAADDRESS2, address2);
			if (!string.IsNullOrEmpty(Address.City)) RecordPair(PMMember.POACITY, Address.City);
			string zipout = string.Empty;
			if (!string.IsNullOrEmpty(Address.Zip))
			{
				zipout = Address.Zip.PadLeft(5, '0');
				if (!string.IsNullOrEmpty(Address.Plus4))
				{
					zipout += Address.Plus4.PadLeft(4, '0');
				}
			}
			if (!string.IsNullOrEmpty(zipout)) RecordPair(PMMember.POAZIP, zipout);
			if (!string.IsNullOrEmpty(Address.State)) RecordPair(PMMember.POASTATE, Address.State);
		}
	}
}
