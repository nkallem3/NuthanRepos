﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

using ContactDataLib;
using Logging;

namespace MemberProcessing
{
	public delegate void UpdateMemberDelegate(PMMember Member, EnrichData Original, EnrichData Updated, string Reason, bool UpdateHistory);

	public class Enrichment
	{
		private LoadInfo Load = null;
		private StreamWriter ToBeEnrichedFileStream = null;
		private List<PersonatorBatch> PersonatorBatches = new List<PersonatorBatch>();
		private PersonatorBatch CurrentPersonatorBatch = new PersonatorBatch();
		private long DeferredEnrichmentCount = 0;
		private long PersonatorBatchCount = 0;

		public bool EnrichmentIsPending { get { return PersonatorBatches.Count > 0; } }

		public void Initialize(LoadInfo load)
		{
			Load = load;
			ToBeEnrichedFileStream = null;
		}

		public void Close()
		{
			if (ToBeEnrichedFileStream != null)
			{
				ToBeEnrichedFileStream.Close();
				ToBeEnrichedFileStream = null;
			}
		}

		public void LogStats()
		{
			if (Load.LoadOptions.Contains(LoadOption.NoEnrichment))
				return;

			Logger.LogString(string.Format("Enrichment stats:"));
			foreach (string Field in Load.Stats.EnrichTried.GetFields())
				Logger.LogString(FormatStat(Field, Load.Stats.Enriched.GetCount(Field), "enriched", Load.Stats.EnrichTried.GetCount(Field)));
			if (Load.LoadOptions.Contains(LoadOption.EnrichDeferred) == true)
			{
				Logger.LogString(string.Format("Deferred Enrichment: (file = {0}, records = {1})", Path.GetFileName(Load.ToBeEnrichedFile), DeferredEnrichmentCount));
				foreach (string Field in Load.Stats.EnrichTried.GetFields())
					Logger.LogString(string.Format("     {0} - {1} added to file", Field, Load.Stats.EnrichDeferred.GetCount(Field)));
			}
		}

		private string FormatStat(string name, long number, string op, long total)
		{
			string result = "     " + name + " - ";
			if (total == 0)
				result += "(none)";
			else
				result += string.Format("{0:N0} {1} of {2:N0} considered ({3:0.0}%)", number, op, total, (double) number * 100 / total);
			return result;
		}

		public void EnrichMember(PMMember Member)
		{
			if (Load.LoadOptions.Contains(LoadOption.NoEnrichment))
				return;

			// Perform enrichment (nothing to do if we don't have a member ID and name)
			EnrichData record = EnrichData.FromMember(Member);
			bool IsAltPhone = false;
			if (string.IsNullOrEmpty(record.memberid) || string.IsNullOrEmpty(record.last) || string.IsNullOrEmpty(record.first))
				return;

			// If we have a primary phone, try to enrich the alternate
			if (!string.IsNullOrEmpty(record.phone))
			{
				record.phone = Member.GetStringData(PMMember.PHONENUMBERALTERNATE);
				IsAltPhone = true;
			}

			// Determine if the member needs to be enriched based on what is requested and what is missing
			if (Load.LoadOptions.Contains(LoadOption.EnrichAddress) && !record.address.MightBeValid() && (!string.IsNullOrEmpty(record.phone) || !string.IsNullOrEmpty(record.email)))
			{
				record.address = new CDAddress();  // remove the address so there's no confusion over whether it might be valid or not
				Member.NeedsEnrichment.Add(PMMember.ADDRESS);
			}
			if (Load.LoadOptions.Contains(LoadOption.EnrichPhone) && string.IsNullOrEmpty(record.phone) && (record.address.IsValid() || !string.IsNullOrEmpty(record.email)))
			{
				if (IsAltPhone)
					Member.NeedsEnrichment.Add(PMMember.PHONENUMBERALTERNATE);
				else
					Member.NeedsEnrichment.Add(PMMember.PHONENUMBERPRIMARY);
			}
			if (Load.LoadOptions.Contains(LoadOption.EnrichEmail) && string.IsNullOrEmpty(record.email) && (record.address.IsValid() || !string.IsNullOrEmpty(record.phone)))
			{
				Member.NeedsEnrichment.Add(PMMember.EMAILADDRESS);
			}

			if (Member.NeedsEnrichment.Any())
			{
				foreach (string field in Member.NeedsEnrichment)
				{
					Load.Stats.EnrichTried.Bump(field);
				}

				// First check the historical enrichment data
				EnrichData history = Load.History.GetEnrichHistory(record);
				if (history != null)
				{
					// Update the member from historical data then continue with either in-process or deferred enrichment
					UpdateMember(Member, record, history, "Historical enrichment", false);
					Member.NeedsEnrichment.Clear();
				}
			}

			if (Load.LoadOptions.Contains(LoadOption.EnrichDeferred))
			{
				// Deferred enrichment - only output members that need to be enriched
				if (Member.NeedsEnrichment.Any())
				{
					string Header = "MemberID|MBI|NameFirst|NameLast|DOB|Address1|Address2|City|State|Zip|Zip11|PrimaryPhone|AlternatePhone|EmailAddress";
					string Delimiter = "|";
					foreach (string field in Member.NeedsEnrichment)
					{
						Load.Stats.EnrichDeferred.Bump(field);
					}

					if (ToBeEnrichedFileStream == null)
					{
						ToBeEnrichedFileStream = new StreamWriter(Load.ToBeEnrichedFile, false);
						ToBeEnrichedFileStream.WriteLine(Header);
					}

					// Write the member data to the deferred enrichment file
					StringBuilder s = new StringBuilder(500);
					s.Append(record.memberid + Delimiter);
					s.Append(record.mbi + Delimiter);
					s.Append(record.first + Delimiter);
					s.Append(record.last + Delimiter);
					s.Append(record.dob + Delimiter);
					s.Append(record.address.Line1 + Delimiter);
					s.Append(record.address.Line2 + Delimiter);
					s.Append(record.address.City + Delimiter);
					s.Append(record.address.State + Delimiter);
					s.Append(record.address.Zip5 + Delimiter);
					s.Append(record.address.Zip11 + Delimiter);
					s.Append(Member.GetStringData(PMMember.PHONENUMBERPRIMARY) + Delimiter);
					s.Append(Member.GetStringData(PMMember.PHONENUMBERALTERNATE) + Delimiter);
					s.Append(record.email);
					ToBeEnrichedFileStream.WriteLine(s.ToString());
					DeferredEnrichmentCount++;
				}
			}
			else
			{
				// In-process enrichment - Queue the data for Personator
				// Every member gets queued but only members needing enrichment will be transmitted to Personator
				CurrentPersonatorBatch.AddMember(Member, record);

				// If we have a full batch ready, send it and start a new one
				PersonatorBatch BatchToSend = null;
				if (CurrentPersonatorBatch.ReadyToSend)
				{
					PersonatorBatches.Add(CurrentPersonatorBatch);
					BatchToSend = CurrentPersonatorBatch;
					CurrentPersonatorBatch = new PersonatorBatch();
				}
				if (BatchToSend != null)
				{
					// Limit the number of batches (threads) outstanding with Personator
					while (PersonatorBatches.Count(x => x.BatchComplete == false) > ProcessArgs.Config.MaxPersonatorThreads)
					{
						Thread.Sleep(250);
					}

					// Process on a background thread (will be marked complete when Personator has finished)
					BatchToSend.BatchNumber = ++PersonatorBatchCount;
					Logger.LogString(string.Format("Queuing batch {0}", BatchToSend.BatchNumber), LogLevel.Verbose);
					BatchToSend.ProcThread = new Thread(x => BatchToSend.SendToPersonator(UpdateMember));
					BatchToSend.ProcThread.Name = "Batch " + BatchToSend.BatchNumber.ToString();
					BatchToSend.ProcThread.Priority = ThreadPriority.BelowNormal;
					BatchToSend.ProcThread.Start();
				}
			}
		}

		public void FinishEnrichment()
		{
			// Force the current member batch to be sent to Personator
			if (CurrentPersonatorBatch != null && CurrentPersonatorBatch.MemberData.Count > 0)
			{
				PersonatorBatches.Add(CurrentPersonatorBatch);
				PersonatorBatch BatchToSend = CurrentPersonatorBatch;
				CurrentPersonatorBatch = new PersonatorBatch();
				BatchToSend.BatchNumber = ++PersonatorBatchCount;
				Logger.LogString(string.Format("Queuing last batch {0}", BatchToSend.BatchNumber), LogLevel.Verbose);
				BatchToSend.SendToPersonator(UpdateMember);
			}
		}

		public PersonatorBatch GetCompletedBatch()
		{
			// Check if any batches have been running too long


			// Get the first completed batch ordered by batch number
			PersonatorBatch CompletedBatch = PersonatorBatches.OrderBy(x => x.BatchNumber).FirstOrDefault(x => x.BatchComplete);
			if (CompletedBatch != null)
			{
				Logger.LogString(string.Format("Batch returned {0}\t({1:N1})", CompletedBatch.BatchNumber, (decimal) CompletedBatch.BatchTime.TotalMilliseconds / 1000), LogLevel.Verbose);
				PersonatorBatches.Remove(CompletedBatch);
			}
			return CompletedBatch;
		}

		private void UpdateMember(PMMember Member, EnrichData Original, EnrichData Updated, string Reason, bool UpdateHistory)
		{
			// Compare, update and track the member data
			if (Member.NeedsEnrichment.Contains(PMMember.ADDRESS))
			{
				if (!CDAddress.AddressIsSame(Updated.address, Original.address) && Updated.address.IsValid())
				{
					Load.Stats.Enriched.Bump(PMMember.ADDRESS);
					Member.UpdateAddress(Updated.address);
					Member.FieldChanged(PMMember.ADDRESS, "", Updated.address.ToString(), Reason);
				}
			}

			if (Member.NeedsEnrichment.Contains(PMMember.PHONENUMBERPRIMARY))
			{
				if (string.Compare(Updated.phone, Original.phone, 0) != 0 && !string.IsNullOrEmpty(Updated.phone))
				{
					Load.Stats.Enriched.Bump(PMMember.PHONENUMBERPRIMARY);
					Member.RecordPair(PMMember.PHONENUMBERPRIMARY, Updated.phone, Reason);
				}
			}

			if (Member.NeedsEnrichment.Contains(PMMember.PHONENUMBERALTERNATE))
			{
				if (string.Compare(Updated.phone, Original.phone, 0) != 0 && !string.IsNullOrEmpty(Updated.phone))
				{
					Load.Stats.Enriched.Bump(PMMember.PHONENUMBERALTERNATE);
					Member.RecordPair(PMMember.PHONENUMBERALTERNATE, Updated.phone, Reason);
				}
			}

			if (Member.NeedsEnrichment.Contains(PMMember.EMAILADDRESS))
			{
				if (string.Compare(Updated.email, Original.email, 0) != 0 && !string.IsNullOrEmpty(Updated.email))
				{
					Load.Stats.Enriched.Bump(PMMember.EMAILADDRESS);
					Member.RecordPair(PMMember.EMAILADDRESS, Updated.email, Reason);
				}
			}

			// Even if enrichment didn't return something we should use the original data to populate the enrichment history
			// That way if a future client file needs enrichment, we can use whatever existed before
			// TODO: Not sure this is the right thing to do so it's not enabled
			if (false)
			{
				if (Updated.address.MightBeValid() == false && Original.address.IsValid())
				{
					Updated.address = Original.address;
				}
				if (string.IsNullOrEmpty(Updated.phone) && !string.IsNullOrEmpty(Original.phone))
				{
					Updated.phone = Original.phone;
					Updated.phoneclass = Original.phoneclass;
					Updated.phonedesignation = Original.phonedesignation;
				}
				if (string.IsNullOrEmpty(Updated.phone) && !string.IsNullOrEmpty(Original.phone))
				{
					Updated.email = Original.email;
				}
			}

			// When outputting the deferred enrichment data, remove anything that was not specifically enriched
			if (Load.Loadtype == LoadType.DeferredEnrichment)
			{
				if (Member.NeedsEnrichment.Contains(PMMember.ADDRESS) == false)
					Member.UpdateAddress(new CDAddress());
				if (Member.NeedsEnrichment.Contains(PMMember.PHONENUMBERPRIMARY) == false)
					Member.RemoveData(PMMember.PHONENUMBERPRIMARY);
				if (Member.NeedsEnrichment.Contains(PMMember.PHONENUMBERALTERNATE) == false)
					Member.RemoveData(PMMember.PHONENUMBERALTERNATE);
				if (Member.NeedsEnrichment.Contains(PMMember.EMAILADDRESS) == false)
					Member.RemoveData(PMMember.EMAILADDRESS);
			}

			// Update the historical enrichment data (unless enrichment came from the history in the first place)
			if (Load.History != null && UpdateHistory)
			{
				Load.History.SetEnrichHistory(Original, Updated);
			}
		}
	}

	public class PersonatorBatch
	{
		public long BatchNumber { get; set; }
		public bool BatchComplete { get; private set; }
		public bool ReadyToSend { get { return PersonatorData.ReadyToSend || MemberData.Count > Personator.MAX_PERSONATOR_BATCH_SIZE * 100; } }
		public DateTime StartTime { get; private set; }
		public TimeSpan BatchTime { get; private set; }
		public Thread ProcThread { get; set; }

		public List<PMMember> MemberData = new List<PMMember>();

		private Personator.RequestData PersonatorData = new Personator.RequestData();

		// TestModeMax: 0 = send to Personator, > 0 = test with random delay Min..Max
		private Random rand = new Random(DateTime.Now.Millisecond);
		private int TestModeMin = 0;
		private int TestModeMax = 0;

		public PersonatorBatch()
		{
			BatchComplete = false;
			if (!string.IsNullOrEmpty(ProcessArgs.Config.TestMode))
			{
				string[] parms = ProcessArgs.Config.TestMode.Split(',');
				if (parms.Count() == 1)
				{
					int.TryParse(parms[0], out TestModeMax);
					TestModeMin = TestModeMax;
				}
				else if (parms.Count() == 2)
				{
					int.TryParse(parms[0], out TestModeMin);
					int.TryParse(parms[1], out TestModeMax);
				}
				TestModeMin = Math.Min(Math.Max(1, TestModeMin), TestModeMax);
			}
		}

		public void AddMember(PMMember Member, EnrichData Data)
		{
			if (Member == null)
			{
				return;
			}
			MemberData.Add(Member);

			// If the member needs enrichment, then populate the enrichment data sent to Personator
			if (Member.NeedsEnrichment.Any() && Data != null)
			{
				Personator.RequestRecord PersonatorRecord = new Personator.RequestRecord();
				PersonatorRecord.RecordID = (int) Member.RecordID;
				PersonatorRecord.FirstName = Data.first;
				PersonatorRecord.LastName = Data.last;

				// If we have an address, don't send the phone or email in order to try and get those returned
				// Otherwise, send the phone and/or email in order to try and get an address returned
				if (Data.address != null && Data.address.MightBeValid())
				{
					PersonatorRecord.Line1 = Data.address.Line1;
					PersonatorRecord.Line2 = Data.address.Line2;
					PersonatorRecord.City = Data.address.City;
					PersonatorRecord.State = Data.address.State;
					PersonatorRecord.Zip = Data.address.Zip;
				}
				else
				{
					PersonatorRecord.Phone = Data.phone;
					PersonatorRecord.Email = Data.email;
				}
				PersonatorData.AddRecord(PersonatorRecord);
			}
		}

		private EnrichData FromPersonatorRequest(Personator.RequestRecord Record)
		{
			EnrichData info = new EnrichData();
			info.first = Record.FirstName;
			info.last = Record.LastName;
			info.address = new CDAddress();
			info.address.Line1 = Record.Line1;
			info.address.Line2 = Record.Line2;
			info.address.City = Record.City;
			info.address.State = Record.State;
			info.address.Zip = Record.Zip;
			info.phone = Record.Phone;
			info.email = Record.Email;
			return info;
		}

		private EnrichData FromPersonatorResult(Personator.RequestRecord Record)
		{
			EnrichData info = new EnrichData();
			info.address = new CDAddress();
			Record.OutputData.TryGetValue(Personator.Column.NameFirst, out info.first);
			Record.OutputData.TryGetValue(Personator.Column.NameLast, out info.last);
			Record.OutputData.TryGetValue(Personator.Column.AddressLine1, out info.address.Line1);
			Record.OutputData.TryGetValue(Personator.Column.AddressLine2, out info.address.Line2);
			Record.OutputData.TryGetValue(Personator.Column.City, out info.address.City);
			Record.OutputData.TryGetValue(Personator.Column.State, out info.address.State);
			Record.OutputData.TryGetValue(Personator.Column.PostalCode, out info.address.Zip);
			Record.OutputData.TryGetValue(Personator.Column.CountyName, out info.address.County);
			Record.OutputData.TryGetValue(Personator.Column.PhoneNumber, out info.phone);
			Record.OutputData.TryGetValue(Personator.Column.EmailAddress, out info.email);

			// classify the address and phone number
			info.address.AddressType = MelissaDataValidator.GetAddressType(Record.Results);
			info.address.GeocodeType = MelissaDataValidator.GetGeocodeType(Record.Results);
			info.phoneclass = MelissaDataValidator.GetPhoneExchange(Record.Results);
			info.phonedesignation = MelissaDataValidator.GetPhoneType(Record.Results);
			return info;
		}

		public void SendToPersonator(UpdateMemberDelegate UpdateCallback)
		{
			StartTime = DateTime.Now;
			if (PersonatorData.BatchCount == 0)
			{
				BatchTime = DateTime.Now - StartTime;
				BatchComplete = true;
				return;
			}

			// TestMode: command line -Test=Max,Min
			if (TestModeMax > 0)
			{
				// Fake Personator - just sleep for a random time
				int Wait = TestModeMax > 0 ? rand.Next(TestModeMin, TestModeMax) : 0;
				Thread.Sleep(Wait);
				foreach (PMMember Member in MemberData.Where(x => x.NeedsEnrichment.Any()))
				{
					EnrichData Sent = EnrichData.FromMember(Member);
					EnrichData Rcvd = EnrichData.FromMember(Member);
					Rcvd.address.Zip = "99999";
					Rcvd.phone = "9999999999";
					Rcvd.email = "me@foobar.com";
					UpdateCallback(Member, Sent, Rcvd, "Fake enrichment", false);
				}
				BatchTime = DateTime.Now - StartTime;
				BatchComplete = true;
				return;
			}

			PersonatorData.CustomerID = MelissaDataConfig.ConfigSingleton.LicenseCode;
			PersonatorData.SaveXML = MelissaDataConfig.ConfigSingleton.SavePersonatorIO;
			PersonatorData.ActionCheck = true;
			PersonatorData.ActionAppend = true;
			PersonatorData.ActionVerify = true;
			PersonatorData.UsePreferredCity = true;
			PersonatorData.AdvancedAddressCorrection = true;
			PersonatorData.SetColumnGroups(Personator.ColumnGroup.AddressDetails, Personator.ColumnGroup.ParsedEmail, Personator.ColumnGroup.ParsedPhone, Personator.ColumnGroup.GeoCode);

			bool Success = false;
			for (int Retry = 1; Retry <= 5 && !Success; Retry++)
			{
				try
				{
					// Transmit the data and wait for the response
					Success = Personator.SendPersonatorRequest(PersonatorData);
					if (Success == false)
						Logger.LogString(string.Format("Personator error (batch {0}, retry {1}) - {2}", BatchNumber, Retry, PersonatorData.Message), LogLevel.Error);
				}
				catch (Exception ex)
				{
					Logger.LogException(string.Format("Personator error (batch {0}, retry {1})", BatchNumber, Retry), ex);
				}
				if (Success == false)
					Thread.Sleep(30000);
			}
			if (Success == false)
			{
				Logger.LogString(string.Format("Personator error (batch {0} failed all retries)", BatchNumber));
				BatchTime = DateTime.Now - StartTime;
				BatchComplete = true;
				return;
			}

			// Unpack the Personator results
			Dictionary<string, long> FailedCounts = new Dictionary<string, long>();
			for (int n = 0; n < PersonatorData.BatchCount; n++)
			{
				// Get the response data for this record
				Personator.RequestRecord PersonatorResult = PersonatorData.GetRequestRecord(n);
				if (PersonatorResult.Success == false)
				{
					// Personator data not received for this record
					if (FailedCounts.Keys.Contains(PersonatorResult.Results))
						FailedCounts[PersonatorResult.Results]++;
					else
						FailedCounts.Add(PersonatorResult.Results, 1);
					Logger.LogString(string.Format("Personator: data not received, ID = {0}", PersonatorResult.RecordID), LogLevel.Verbose);
					continue;
				}

				// Get the member associated with this record
				PMMember Member = MemberData.FirstOrDefault(x => x.RecordID == PersonatorResult.RecordID);
				if (Member == null)
				{
					// Can't happen (fatal problem with queueing/unqueueing logic)
					Logger.LogString(string.Format("Personator: member not found!! ({0})", PersonatorResult.RecordID), LogLevel.Error);
					continue;
				}

				// Add the Member ID, MBI, and DOB to the sent data (needed by UpdateMember)
				EnrichData Sent = FromPersonatorRequest(PersonatorResult);
				EnrichData Rcvd = FromPersonatorResult(PersonatorResult);
				Sent.memberid = Member.GetStringData(PMMember.MEMBERID);
				Sent.mbi = Member.GetStringData(PMMember.MBI);
				Sent.dob = Member.GetStringData(PMMember.DOB);

				// Save the Personator results back to the member data
				UpdateCallback(Member, Sent, Rcvd, "Personator enrichment", true);
			}
			foreach (KeyValuePair<string, long> kvp in FailedCounts)
			{
				Logger.LogString(string.Format("Personator: Failed - {0} ({1} occurences)", kvp.Key, kvp.Value), LogLevel.Error);
			}

			BatchTime = DateTime.Now - StartTime;
			BatchComplete = true;
		}
	}

	public class EnrichData
	{
		public string memberid = string.Empty;
		public string mbi = string.Empty;
		public string first = string.Empty;
		public string last = string.Empty;
		public string dob = string.Empty;
		public CDAddress address = new CDAddress();
		public string phone = string.Empty;
		public ExchangeType phoneclass = ExchangeType.Unknown;
		public PhoneType phonedesignation = PhoneType.Unknown;
		public string email = string.Empty;

		private const char Delimiter = '|';

		public override string ToString()
		{
			return ToEnrichHistoryKey();
		}

		public string ToEnrichHistoryKey()
		{
			StringBuilder s = new StringBuilder(500);
			s.Append(memberid + Delimiter);
			s.Append(mbi + Delimiter);
			s.Append(first + Delimiter);
			s.Append(last + Delimiter);
			s.Append(dob);
			return s.ToString();
		}

		public static EnrichData FromEnrichHistoryKey(string Value)
		{
			EnrichData data = null;
			string[] parts = Value.Split(Delimiter);
			if (parts.Count() == 5)
			{
				int n = 0;
				data = new EnrichData();
				data.memberid = parts[n++];
				data.mbi = parts[n++];
				data.first = parts[n++];
				data.last = parts[n++];
				data.dob = parts[n++];
			}
			return data;
		}

		public string ToEnrichHistoryValue()
		{
			StringBuilder s = new StringBuilder(500);
			s.Append(address.Line1 + Delimiter);
			s.Append(address.Line2 + Delimiter);
			s.Append(address.City + Delimiter);
			s.Append(address.State + Delimiter);
			s.Append(address.Zip5 + Delimiter);
			s.Append(address.Zip11 + Delimiter);
			s.Append(phone + Delimiter);
			s.Append(((int) phoneclass).ToString() + Delimiter);
			s.Append(((int) phonedesignation).ToString() + Delimiter);
			s.Append(email);
			return s.ToString();
		}

		public static EnrichData FromEnrichHistoryValue(string Value)
		{
			EnrichData data = null;
			string[] parts = Value.Split(Delimiter);
			if (parts.Count() == 10)
			{
				int n = 0;
				data = new EnrichData();
				data.address.Line1 = parts[n++];
				data.address.Line2 = parts[n++];
				data.address.City = parts[n++];
				data.address.State = parts[n++];
				data.address.Zip = parts[n++];
				data.address.Zip11 = parts[n++];
				data.phone = parts[n++];
				data.phoneclass = (ExchangeType) Convert.ToInt32(parts[n++]);
				data.phonedesignation = (PhoneType) Convert.ToInt32(parts[n++]);
				data.email = parts[n++];
			}
			return data;
		}

		public static EnrichData FromMember(PMMember Member)
		{
			EnrichData data = new EnrichData();
			data.memberid = Member.GetStringData(PMMember.MEMBERID);
			data.mbi = Member.GetStringData(PMMember.MBI);
			data.last = Member.GetStringData(PMMember.NAMELAST);
			data.first = Member.GetStringData(PMMember.NAMEFIRST);
			data.dob = Member.GetStringData(PMMember.DOB);
			data.address = Member.GetAddress();
			data.email = Member.GetStringData(PMMember.EMAILADDRESS);
			data.phone = Member.GetStringData(PMMember.PHONENUMBERPRIMARY);
			return data;
		}
	}
}
