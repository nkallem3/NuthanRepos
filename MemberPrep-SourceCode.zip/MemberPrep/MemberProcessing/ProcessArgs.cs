﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Serialization;

using ContactDataLib;
using Logging;

namespace MemberProcessing
{
	public class ProcessArgs
	{
		public static ProcessArgs Config = new ProcessArgs(); // Singleton

		public static string MelissaDataPath { get { return MelissaDataConfig.ConfigSingleton.DataFilePath; } }
		public static MelissaDataValidator MelissaData { get; private set; }

		public string RootFolder = "";
		public string InputFolder = "";
		public string OutputFolder = "";
		public string LogFileViewer = "";
		public string MelissaUpdaterStartTime = "";
		public int MaxPersonatorThreads = 20;
		public int MaxPersonatorBatchsize = 100;
		public int MelissaUpdaterDuration = 0;

		[XmlIgnore]
		public string InputFile = "";
		[XmlIgnore]
		public string TestMode = "";
		[XmlIgnore]
		public LogLevel LoggingLevel = LogLevel.Default;
		[XmlIgnore]
		public bool ConsoleExecute = false;
		[XmlIgnore]
		public bool ForceUpdate = false;

		[XmlIgnore]
		public string ConfigFolder { get { return Path.Combine(RootFolder, "Config"); } }
		[XmlIgnore]
		public string ArchiveFolder { get { return Path.Combine(RootFolder, "Archive"); } }
		[XmlIgnore]
		public string HistoryFolder { get { return Path.Combine(RootFolder, "History"); } }
		[XmlIgnore]
		public string ErrorFolder { get { return Path.Combine(InputFolder, "Error"); } }
		[XmlIgnore]
		public string EnrichFolder { get { return Path.Combine(InputFolder, "Enrich"); } }
		[XmlIgnore]
		public string DemoRootFolder { get { return Path.Combine(ConfigFolder, "DEMO"); } }
		[XmlIgnore]
		public string MBIHICNRootFolder { get { return Path.Combine(ConfigFolder, "MBIHICN"); } }
		[XmlIgnore]
		public string OutputFormatFolder { get { return Path.Combine(ConfigFolder, "OUTPUT"); } }
		[XmlIgnore]
		public string ProcessLogFile { get { return Path.Combine(ConfigFolder, "Process.log"); } }
		[XmlIgnore]
		public List<LoadOption> ProcessOptions = new List<LoadOption>()
		{
			LoadOption.ValidateAddress, LoadOption.ValidatePhone, LoadOption.EnrichAddress, LoadOption.EnrichPhone, LoadOption.EnrichEmail, LoadOption.EnrichDeferred
		};

		public static void Initialize(string[] args)
		{
			try
			{
				string configfile = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + "\\MemberPrep.config";
				using (Stream fs = new FileStream(configfile, FileMode.Open, FileAccess.Read))
				{
					XmlSerializer serializer = new XmlSerializer(typeof(ProcessArgs));
					Config = (ProcessArgs) serializer.Deserialize(fs);
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Failed to read MemberPrep.config file");
			}
			Config.Startup(args);
		}

		private void Startup(string[] args)
		{
			// Establish the root, input, and output folders (everything else is relative to the root folder)
			string path = Path.GetDirectoryName(RootFolder);
			if (Path.IsPathRooted(RootFolder) == false)
				RootFolder = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), RootFolder));
			if (Path.IsPathRooted(InputFolder) == false)
				InputFolder = Path.Combine(RootFolder, InputFolder);
			if (Path.IsPathRooted(OutputFolder) == false)
				OutputFolder = Path.Combine(RootFolder, OutputFolder);

			// Process the command line arguments (overrides the config file)
			foreach (string arg in args)
			{
				if (arg.StartsWith("-") | arg.StartsWith("/"))
				{
					string[] subargs = arg.Substring(1).Split('=');
					switch (subargs[0].ToUpper())
					{
						case "I":
							if (subargs.Count() != 2)
								throw new Exception("Invalid command line argument - " + arg);
							InputFile = subargs[1];
							break;
						case "LV":
							if (subargs.Count() != 2)
								throw new Exception("Invalid command line argument - " + arg);
							LoggingLevel = (LogLevel) int.Parse(subargs[1]);
							break;
						case "PO":
							if (subargs.Count() != 2)
								throw new Exception("Invalid command line argument - " + arg);
							ProcessOptions.Clear();
							foreach (string option in subargs[1].Split(','))
							{
								if (option.ToUpper() == "VA") ProcessOptions.Add(LoadOption.ValidateAddress);
								if (option.ToUpper() == "VP") ProcessOptions.Add(LoadOption.ValidatePhone);
								if (option.ToUpper() == "VX") ProcessOptions.Add(LoadOption.NoValidation);
								if (option.ToUpper() == "EA") ProcessOptions.Add(LoadOption.EnrichAddress);
								if (option.ToUpper() == "EP") ProcessOptions.Add(LoadOption.EnrichPhone);
								if (option.ToUpper() == "EE") ProcessOptions.Add(LoadOption.EnrichEmail);
								if (option.ToUpper() == "EX") ProcessOptions.Add(LoadOption.NoEnrichment);
								if (option.ToUpper() == "ED") ProcessOptions.Add(LoadOption.EnrichDeferred);
								if (option.ToUpper() == "IT") ProcessOptions.Add(LoadOption.IncludeTermed);
								if (option.ToUpper() == "NH") ProcessOptions.Add(LoadOption.NoHistory);
							}
							break;
						case "TEST":
							if (subargs.Count() != 2)
								throw new Exception("Invalid command line argument - " + arg);
							TestMode = subargs[1];
							break;
						case "FORCEUPDATE":
							ForceUpdate = true;
							break;
						case "X":
							ConsoleExecute = true;
							break;
					}
				}
			}

			if (!string.IsNullOrEmpty(InputFile) && string.IsNullOrEmpty(Path.GetPathRoot(InputFile)))
				InputFile = Path.Combine(InputFolder, InputFile);
			if (Directory.Exists(InputFolder) == false)
				Directory.CreateDirectory(InputFolder);
			if (Directory.Exists(OutputFolder) == false)
				Directory.CreateDirectory(OutputFolder);
			if (Directory.Exists(ArchiveFolder) == false)
				Directory.CreateDirectory(ArchiveFolder);
			if (Directory.Exists(HistoryFolder) == false)
				Directory.CreateDirectory(HistoryFolder);
			if (Directory.Exists(ErrorFolder) == false)
				Directory.CreateDirectory(ErrorFolder);
			if (Directory.Exists(EnrichFolder) == false)
				Directory.CreateDirectory(EnrichFolder);
			if (Directory.Exists(DemoRootFolder) == false)
				Directory.CreateDirectory(DemoRootFolder);
			if (Directory.Exists(MBIHICNRootFolder) == false)
				Directory.CreateDirectory(MBIHICNRootFolder);
			if (Directory.Exists(OutputFormatFolder) == false)
				Directory.CreateDirectory(OutputFormatFolder);

			// Initialize Melissa Data
			try
			{
				MelissaDataConfig.ReadConfig(null);
				MelissaData = new MelissaDataValidator();
				MelissaData.Initialize();
				MelissaData.ResetStats();
				Personator.MAX_PERSONATOR_BATCH_SIZE = MaxPersonatorBatchsize;
			}
			catch (Exception ex)
			{
				MelissaData = null;
			}

			// Initialize the NPANXX phone validator
			FieldValidator.PrimePhoneValidator(Path.Combine(ConfigFolder, "npa-nxx*"));
		}
	}
}
