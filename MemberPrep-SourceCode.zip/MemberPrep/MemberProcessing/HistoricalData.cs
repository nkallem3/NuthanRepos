﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

using ContactDataLib;
using Logging;

namespace MemberProcessing
{
	public class HistoricalData
	{
		private Dictionary<string, string> PhoneHistory = null;
		private Dictionary<string, string> AddressHistory = null;
		private Dictionary<string, string> EnrichHistory = null;
		private long PhoneHistoryChangedCount = 0;
		private long AddressHistoryChangedCount = 0;
		private long EnrichHistoryChangedCount = 0;
		private const string HistorySplit = ":=:";

		public void LogStats()
		{
			Logger.LogString("Historical data stats:");
			if (PhoneHistory != null)
				Logger.LogString(FormatStat("Phone", PhoneHistoryChangedCount, PhoneHistory.Count));
			if (AddressHistory != null)
				Logger.LogString(FormatStat("Address", AddressHistoryChangedCount, AddressHistory.Count));
			if (EnrichHistory != null)
				Logger.LogString(FormatStat("Enrichment", EnrichHistoryChangedCount, EnrichHistory.Count));
		}

		private string FormatStat(string msg, long number, long total)
		{
			string result = "     " + msg + " - ";
			if (total == 0)
				result += "(none)";
			else
				result += string.Format("{0:N0} updated of {1:N0} total records ({2:0.0}%)", number, total, (double) number * 100 / total);
			return result;
		}

		private FileStream GetFileStreamLocked(string fullPath, FileMode mode)
		{
			DateTime dtFailed = DateTime.Now.AddSeconds(60);
			FileAccess access = mode == FileMode.Open ? FileAccess.Read : FileAccess.Write;
			while (DateTime.Now < dtFailed)
			{
				FileStream fs = null;
				try
				{
					fs = new FileStream(fullPath, mode, access, FileShare.None);
					return fs;
				}
				catch (IOException)
				{
					if (fs != null)
					{
						fs.Dispose();
					}
					Thread.Sleep(100);
				}
			}
			return null;
		}

		///////////////////////////////////////////////////////////////////////////////////////////
		// Phone history
		///////////////////////////////////////////////////////////////////////////////////////////

		public void ReadPhoneHistory(string Filename)
		{
			PhoneHistory = new Dictionary<string, string>();
			PhoneHistoryChangedCount = 0;
			if (File.Exists(Filename) == false)
				return;

			using (StreamReader reader = new StreamReader(GetFileStreamLocked(Filename, FileMode.Open)))
			{
				while (!reader.EndOfStream)
				{
					string Line = reader.ReadLine();
					int split = Line.IndexOf(HistorySplit);
					if (split > 0)
					{
						string key = Line.Substring(0, split);
						string value = Line.Substring(split + HistorySplit.Length);
						if (PhoneHistory.ContainsKey(key))
						{
							PhoneHistory[key] = value;
						}
						else
						{
							PhoneHistory.Add(key, value);
						}
					}
				}
			}
		}

		public void WritePhoneHistory(string Filename, bool Append = false)
		{
			if (PhoneHistory == null || PhoneHistoryChangedCount == 0)
				return;
			if (Directory.Exists(Path.GetDirectoryName(Filename)) == false)
				Directory.CreateDirectory(Path.GetDirectoryName(Filename));

			FileMode mode = Append ? FileMode.Append : FileMode.Create;
			using (StreamWriter writer = new StreamWriter(GetFileStreamLocked(Filename, mode)))
			{
				foreach (KeyValuePair<string, string> kvp in PhoneHistory)
				{
					string output = string.Format("{0}{1}{2}", kvp.Key, HistorySplit, kvp.Value);
					writer.WriteLine(output);
				}
			}
		}

		public CDPhone GetPhoneHistory(CDPhone PhoneIn)
		{
			if (PhoneHistory == null)
				return null;

			CDPhone PhoneOut = null;
			string key = PhoneIn.ToCacheKey();
			string value = null;
			if (!string.IsNullOrEmpty(key))
			{
				lock (PhoneHistory)
				{
					if (PhoneHistory.TryGetValue(key, out value))
					{
						PhoneOut = CDPhone.FromCacheValue(value);
					}
				}
			}
			return PhoneOut;
		}

		public void SetPhoneHistory(CDPhone Original, CDPhone Updated)
		{
			if (PhoneHistory == null)
				return;

			string key = Original.ToCacheKey();
			string value = Updated.ToCacheValue();
			lock (PhoneHistory)
			{
				string CurrValue = null;
				if (PhoneHistory.TryGetValue(key, out CurrValue) == true)
				{
					if (CurrValue != value)
					{
						PhoneHistory[key] = value;
						PhoneHistoryChangedCount++;
					}
				}
				else
				{
					PhoneHistory.Add(key, value);
					PhoneHistoryChangedCount++;
				}
			}
		}

		public void UpdateAllPhoneHistory(string Filename)
		{
			ReadPhoneHistory(Filename);
			foreach (string key in PhoneHistory.Keys.ToList())
			{
				CDPhone PhoneIn = CDPhone.FromCacheKey(key);
				CDPhone PhoneOut;
				ProcessArgs.MelissaData.PhoneVerify(PhoneIn, out PhoneOut);
				string value = PhoneOut.ToCacheValue();
				SetPhoneHistory(PhoneIn, PhoneOut);
			}
			WritePhoneHistory(Filename);
			string logmsg = string.Format("Phone history updated: Data source = {0}, Total records = {1}, Updated = {2}",
				Path.GetFileName(Filename).Substring(0, 6), PhoneHistory.Count, PhoneHistoryChangedCount);
			Logger.LogString(logmsg, LogLevel.Info);
		}

		///////////////////////////////////////////////////////////////////////////////////////////
		// Address history
		///////////////////////////////////////////////////////////////////////////////////////////

		public void ReadAddressHistory(string Filename)
		{
			AddressHistory = new Dictionary<string, string>();
			AddressHistoryChangedCount = 0;
			if (File.Exists(Filename) == false)
				return;

			using (StreamReader reader = new StreamReader(GetFileStreamLocked(Filename, FileMode.Open)))
			{
				while (!reader.EndOfStream)
				{
					string Line = reader.ReadLine();
					int split = Line.IndexOf(HistorySplit);
					if (split > 0)
					{
						string key = Line.Substring(0, split);
						string value = Line.Substring(split + HistorySplit.Length);
						if (AddressHistory.ContainsKey(key))
						{
							AddressHistory[key] = value;
						}
						else
						{
							AddressHistory.Add(key, value);
						}
					}
				}
			}
		}

		public void WriteAddressHistory(string Filename, bool Append = false)
		{
			if (AddressHistory == null || AddressHistoryChangedCount == 0)
				return;
			if (Directory.Exists(Path.GetDirectoryName(Filename)) == false)
				Directory.CreateDirectory(Path.GetDirectoryName(Filename));

			FileMode mode = Append ? FileMode.Append : FileMode.Create;
			using (StreamWriter writer = new StreamWriter(GetFileStreamLocked(Filename, mode)))
			{
				foreach (KeyValuePair<string, string> kvp in AddressHistory)
				{
					string output = string.Format("{0}{1}{2}", kvp.Key, HistorySplit, kvp.Value);
					writer.WriteLine(output);
				}
			}
		}

		public CDAddress GetAddressHistory(CDAddress AddressIn)
		{
			if (AddressHistory == null)
				return null;

			CDAddress AddressOut = null;
			string key = AddressIn.ToCacheKey();
			string value = null;
			if (!string.IsNullOrEmpty(key))
			{
				lock (AddressHistory)
				{
					if (AddressHistory.TryGetValue(key, out value))
					{
						AddressOut = CDAddress.FromCacheValue(value);
					}
				}
			}
			return AddressOut;
		}

		public void SetAddressHistory(CDAddress Original, CDAddress Updated)
		{
			if (AddressHistory == null)
				return;

			string key = Original.ToCacheKey();
			string value = Updated.ToCacheValue();
			lock (AddressHistory)
			{
				string CurrValue = null;
				if (AddressHistory.TryGetValue(key, out CurrValue) == true)
				{
					if (CurrValue != value)
					{
						AddressHistory[key] = value;
						AddressHistoryChangedCount++;
					}
				}
				else
				{
					AddressHistory.Add(key, value);
					AddressHistoryChangedCount++;
				}
			}
		}

		public void UpdateAllAddressHistory(string Filename)
		{
			ReadAddressHistory(Filename);
			foreach (string key in AddressHistory.Keys.ToList())
			{
				CDAddress AddressIn = CDAddress.FromCacheKey(key);
				CDAddress AddressOut;
				ProcessArgs.MelissaData.AddressVerify(AddressIn, out AddressOut);
				string value = AddressOut.ToCacheValue();
				SetAddressHistory(AddressIn, AddressOut);
			}
			WriteAddressHistory(Filename);
			string logmsg = string.Format("Address history updated: Data source = {0}, Total records = {1}, Updated = {2}",
				Path.GetFileName(Filename).Substring(0, 6), PhoneHistory.Count, PhoneHistoryChangedCount);
			Logger.LogString(logmsg, LogLevel.Info);
		}

		///////////////////////////////////////////////////////////////////////////////////////////
		// Enrich history
		///////////////////////////////////////////////////////////////////////////////////////////

		public void ReadEnrichHistory(string Filename)
		{
			EnrichHistory = new Dictionary<string, string>();
			EnrichHistoryChangedCount = 0;
			if (File.Exists(Filename) == false)
				return;

			using (StreamReader reader = new StreamReader(GetFileStreamLocked(Filename, FileMode.Open)))
			{
				while (!reader.EndOfStream)
				{
					string Line = reader.ReadLine();
					int split = Line.IndexOf(HistorySplit);
					if (split > 0)
					{
						string key = Line.Substring(0, split);
						string value = Line.Substring(split + HistorySplit.Length);
						if (EnrichHistory.ContainsKey(key))
						{
							EnrichHistory[key] = value;
						}
						else
						{
							EnrichHistory.Add(key, value);
						}
					}
				}
			}
		}

		public void WriteEnrichHistory(string Filename, bool Append = false)
		{
			if (EnrichHistory == null || EnrichHistoryChangedCount == 0)
				return;
			if (Directory.Exists(Path.GetDirectoryName(Filename)) == false)
				Directory.CreateDirectory(Path.GetDirectoryName(Filename));

			FileMode mode = Append ? FileMode.Append : FileMode.Create;
			using (StreamWriter writer = new StreamWriter(GetFileStreamLocked(Filename, mode)))
			{
				foreach (KeyValuePair<string, string> kvp in EnrichHistory)
				{
					string output = string.Format("{0}{1}{2}", kvp.Key, HistorySplit, kvp.Value);
					writer.WriteLine(output);
				}
			}
		}

		public EnrichData GetEnrichHistory(EnrichData EnrichIn)
		{
			if (EnrichHistory == null)
				return null;

			EnrichData EnrichOut = null;
			string key = EnrichIn.ToEnrichHistoryKey();
			string value = null;
			if (!string.IsNullOrEmpty(key))
			{
				lock (EnrichHistory)
				{
					if (EnrichHistory.TryGetValue(key, out value) == true)
					{
						EnrichOut = EnrichData.FromEnrichHistoryValue(value);
					}
				}
			}
			return EnrichOut;
		}

		public void SetEnrichHistory(EnrichData Original, EnrichData Updated)
		{
			if (EnrichHistory == null)
				return;

			string key = Original.ToEnrichHistoryKey();
			string value = Updated.ToEnrichHistoryValue();
			lock (EnrichHistory)
			{
				string CurrValue = null;
				if (EnrichHistory.TryGetValue(key, out CurrValue) == true)
				{
					if (CurrValue != value)
					{
						EnrichHistory[key] = value;
						EnrichHistoryChangedCount++;
					}
				}
				else
				{
					EnrichHistory.Add(key, value);
					EnrichHistoryChangedCount++;
				}
			}
		}
	}
}
