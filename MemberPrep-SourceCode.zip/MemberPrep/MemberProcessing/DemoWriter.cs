﻿using System;
using System.IO;

using Logging;

namespace MemberProcessing
{
	public class DemoWriter
	{
		private FormatFile OutputFormat = null;
		private StreamWriter OutputFileStream = null;
		private StreamWriter ChangeFileStream = null;

		public void Initialize(LoadInfo Load)
		{
			Close();

			try
			{
				// Create the output file and write the header
				OutputFormat = Load.OutputFormat;
				OutputFileStream = new StreamWriter(Load.OutputFile, false);
				OutputFileStream.WriteLine(OutputFormat.GetHeader());
				if (!string.IsNullOrEmpty(Load.ExtraFileInfo))
				{
					OutputFileStream.WriteLine(string.Format("<<<<{0}>>>>", Load.ExtraFileInfo));
				}

				// Create the change log file
				if (Load.Loadtype == LoadType.DEMO)
				{
					ChangeFileStream = new StreamWriter(Load.ChangeFile, false);
					ChangeFileStream.WriteLine("RecordID,MemberID,Field,OldValue,NewValue,Note");
				}
			}
			catch (Exception ex)
			{
				Logger.LogException("Failed to create output: ", ex);
				throw;
			}
		}

		public void Close()
		{
			if (OutputFileStream != null)
			{
				OutputFileStream.Close();
				OutputFileStream = null;
			}
			if (ChangeFileStream != null)
			{
				ChangeFileStream.Close();
				ChangeFileStream = null;
			}
		}

		public void OutputMember(PMMember Member)
		{
			// Process each field in the output format to construct the output line
			string OutputLine = "";
			foreach (FieldDefinition fielddef in OutputFormat.FieldDefinitions)
			{
				string fieldname = fielddef.InternalFieldName;
				string fieldvalue = Member.GetStringData(fieldname);

				// Truncate the output field
				if (fielddef.MaxLength > 0 && fieldvalue.Length > fielddef.MaxLength)
				{
					fieldvalue = fieldvalue.Substring(0, fielddef.MaxLength);
					Member.RecordPair(fieldname, fieldvalue, "Field truncated");
				}

				// Handle the case where the field value contains the field delimiter
				if (fieldvalue.Contains(OutputFormat.FieldDelimiter))
				{
					fieldvalue = "\"" + fieldvalue.Replace("\"", "\"\"") + "\"";
				}
				OutputLine += string.IsNullOrEmpty(OutputLine) ? fieldvalue : OutputFormat.FieldDelimiter + fieldvalue;
			}

			OutputFileStream.WriteLine(OutputLine);

			// Add any field changes to the change log
			if (ChangeFileStream != null)
			{
				foreach (FieldChange change in Member.FieldChanges)
				{
					string Line = string.Format("{0},{1},{2},{3},{4},{5}", change.RecordID, change.MemberID, change.Field, change.OldValue, change.NewValue, change.Note);
					ChangeFileStream.WriteLine(Line);
				}
			}
		}
	}
}
