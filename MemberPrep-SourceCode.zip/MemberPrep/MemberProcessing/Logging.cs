﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading;

namespace Logging
{
	public enum LogLevel
	{
		Default = 0,
		Error = 1,
		Warning = 2,
		Info = 3,
		Verbose = 4,
		Debug = 5,
		Always = -1,
		Never = 99,
	}

	public enum LogDestination
	{
		Default = 0,
		File = 1,
		Console = 2,
		Callback = 3,
	}

	public delegate void LoggingDelegate(string str, LogLevel level);

	public static class Logger
	{
		private static LoggerClass logger = new LoggerClass();

		public static bool IsActive { get { return logger.IsActive; } }
		public static LogLevel LogLevel { get { return logger.GetLogLevel(LogDestination.Default); } set { logger.SetLogLevel(LogDestination.Default, value); } }
		public static bool LogToConsole { get { return logger.LogToConsole; } set { logger.LogToConsole = value; } }
		public static LoggingDelegate LoggingCallback { get { return logger.LoggingCallback; } set { logger.LoggingCallback = value; } }

		public static bool WillLog(LogLevel level)
		{
			return logger.WillLog(level);
		}
		public static LogLevel GetLogLevel(LogDestination Dest)
		{
			return logger.GetLogLevel(Dest);
		}
		public static void SetLogLevel(LogDestination Dest, LogLevel Level)
		{
			logger.SetLogLevel(Dest, Level);
		}
		public static void LoggerInit(string File, bool? Console = null, LogLevel Level = LogLevel.Default)
		{
			logger.LoggerInit(File, Console, Level = LogLevel.Default);
		}
		public static void LoggerClose(LogDestination dest = LogDestination.Default)
		{
			logger.LoggerClose(dest);
		}
		public static void LogString(string str, LogLevel level = LogLevel.Default, LogDestination dest = LogDestination.Default)
		{
			logger.LogString(str, level, dest);
		}
		public static void LogException(string str, Exception ex, LogLevel level = LogLevel.Error, bool stacktrace = true)
		{
			logger.LogException(str, ex, level, stacktrace);
		}
	}

	public class LoggerClass
	{
		public bool LogToConsole { get; set; }
		public LoggingDelegate LoggingCallback { get; set; }
		public bool IsActive { get { return LogToConsole || LogFile != null || LoggingCallback != null; } }

		private LogLevel LogLevelFile = LogLevel.Info;
		private LogLevel LogLevelConsole = LogLevel.Info;
		private LogLevel LogLevelCallback = LogLevel.Info;
		private LogLevel LogLevelOverall = LogLevel.Never;
		private string LogFileName = "";
		private StreamWriter LogFile = null;

		public bool WillLog(LogLevel level)
		{
			return (IsActive && LogLevelOverall != LogLevel.Never && LogLevelOverall >= level);
		}

		public LogLevel GetLogLevel(LogDestination Dest)
		{
			switch (Dest)
			{
				case LogDestination.Default: return LogLevelOverall;
				case LogDestination.File: return LogLevelFile;
				case LogDestination.Console: return LogLevelConsole;
				case LogDestination.Callback: return LogLevelCallback;
			}
			return LogLevel.Never;
		}

		public void SetLogLevel(LogDestination Dest, LogLevel Level)
		{
			switch (Dest)
			{
				case LogDestination.Default: LogLevelFile = LogLevelConsole = LogLevelCallback = Level; break;
				case LogDestination.File: LogLevelFile = Level; break;
				case LogDestination.Console: LogLevelConsole = Level; break;
				case LogDestination.Callback: LogLevelCallback = Level; break;
			}
			LogLevelOverall = (LogLevel) Math.Max((int) LogLevelFile, Math.Max((int) LogLevelConsole, (int) LogLevelCallback));
		}

		public void LoggerInit(string File, bool? Console, LogLevel Level)
		{
			bool FileAppend = true;
			LogFileName = null;

			// No file logging if File = null (or "{none}")
			if (File != null)
			{
				if (File.StartsWith("@"))
				{
					LogFileName = File.Substring(1);
					FileAppend = false;
				}
				else if (File != "{none}")
					LogFileName = File;
			}
			if (Level == LogLevel.Default)
				Level = LogLevel.Info;

			if (Console.HasValue)
			{
				LogToConsole = Console.Value;
				SetLogLevel(LogDestination.Console, Level);
			}

			if (LogFile != null)
			{
				LogFile.Close();
				LogFile = null;
			}

			if (LogFileName != null)
			{
				SetLogLevel(LogDestination.File, Level);
				try
				{
					LogFileName = LogFileName.Replace("{date}", DateTime.Now.ToString("yyyy-MM-dd"));
					LogFileName = LogFileName.Replace("{time}", DateTime.Now.ToString("HH-mm-ss"));
					string path = string.IsNullOrEmpty(LogFileName) ? "" : Path.GetDirectoryName(LogFileName);
					if (string.IsNullOrEmpty(path))
						path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
					string name = Path.GetFileNameWithoutExtension(LogFileName);
					if (string.IsNullOrEmpty(name))
						name = Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().Location);
					string ext = Path.GetExtension(LogFileName);
					if (string.IsNullOrEmpty(ext))
						ext += ".log";
					LogFileName = Path.Combine(path, name) + ext;
					if (!Directory.Exists(Path.GetDirectoryName(LogFileName)))
						Directory.CreateDirectory(Path.GetDirectoryName(LogFileName));
					LogFile = new StreamWriter(LogFileName, FileAppend);
				}
				catch (Exception ex)
				{
					LogFile = null;
					LogException("Failed to open logfile '" + LogFileName + "'", ex);
				}
			}
		}

		public void LoggerClose(LogDestination dest = LogDestination.Default)
		{
			if (dest == LogDestination.Default || dest == LogDestination.File)
			{
				if (LogFile != null)
				{
					LogFile.Close();
					LogFile = null;
				}
			}
			if (dest == LogDestination.Default || dest == LogDestination.Console)
			{
				LogToConsole = false;
			}
			if (dest == LogDestination.Default || dest == LogDestination.Callback)
			{
				LoggingCallback = null;
			}
		}

		public void LogString(string str, LogLevel level = LogLevel.Default, LogDestination dest = LogDestination.Default)
		{
			if (level == LogLevel.Default)
				level = LogLevel.Info;
			if (!WillLog(level))
				return;

			if (LogFile != null && level <= LogLevelFile && (dest == LogDestination.Default || dest == LogDestination.File))
			{
				lock (LogFile)
				{
					LogFile.WriteLine(string.Format("{0:yyyy-MM-dd HH:mm:ss.fff} <{1:00}> {2}", DateTime.Now, Thread.CurrentThread.ManagedThreadId, str));
					LogFile.Flush();
				}
			}

			if (LogToConsole && level <= LogLevelConsole && (dest == LogDestination.Default || dest == LogDestination.Console))
			{
				lock (this)
				{
					ConsoleColor ExistingForeground = Console.ForegroundColor;
					ConsoleColor ExistingBackground = Console.BackgroundColor;
					ConsoleColor Foreground = ExistingForeground;
					ConsoleColor Background = ExistingBackground;
					switch (level)
					{
						case LogLevel.Error:
							Foreground = ConsoleColor.Yellow;
							Background = ConsoleColor.Red;
							break;
						case LogLevel.Warning:
							Foreground = ConsoleColor.White;
							Background = ConsoleColor.DarkYellow;
							break;
						case LogLevel.Info:
							Foreground = ConsoleColor.Gray;
							break;
						case LogLevel.Verbose:
							Foreground = ConsoleColor.DarkGray;
							break;
						case LogLevel.Debug:
							Foreground = ConsoleColor.DarkGray;
							break;
						case LogLevel.Default:
							Foreground = ConsoleColor.Gray;
							break;
					}
					Console.ForegroundColor = Foreground;
					Console.BackgroundColor = Background;
					Console.WriteLine(str);
					Console.ForegroundColor = ExistingForeground;
					Console.BackgroundColor = ExistingBackground;
				}
			}

			if (LoggingCallback != null && level <= LogLevelCallback && (dest == LogDestination.Default || dest == LogDestination.Callback))
			{
				lock (LoggingCallback)
				{
					LoggingCallback(str, level);
				}
			}
		}

		public void LogException(string str, Exception ex, LogLevel level = LogLevel.Error, bool stacktrace = true)
		{
			if (ex != null)
			{
				LogString(str + " (Exception: " + ex.Message + ")", level);
				if (stacktrace)
					LogString("Stacktrace: " + ex.StackTrace, level);
			}
			else
			{
				LogString(str, level);
			}
		}
	}
}
