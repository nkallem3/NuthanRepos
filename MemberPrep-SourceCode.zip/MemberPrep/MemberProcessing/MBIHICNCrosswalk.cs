﻿using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;

using Logging;

namespace MemberProcessing
{
	public class MBIHICNCrosswalk
	{
		public long DataSourceID { get; set; }
		public long ActiveRecords { get { return MBItoHICLookup != null ? MBItoHICLookup.Count : 0; } }
		public long FileCount { get; private set; }
		public long TotalRecords { get; private set; }
		public long BadLineCount { get; private set; }
		public long BadMBICount { get; private set; }
		public long BadHICCount { get; private set; }
		public long ErrorCount { get { return BadLineCount + BadMBICount + BadHICCount; } }
		public long MBIConflictCount { get; private set; }
		public long HICConflictCount { get; private set; }
		public long ConflictCount { get { return MBIConflictCount + HICConflictCount; }  }
		public long DuplicateCount { get; private set; }
		public long HICLookupCount { get; private set; }
		public long MBILookupCount { get; private set; }
		public List<string> Errors = new List<string>();

		private ConcurrentDictionary<string, string> MBItoHICLookup = new ConcurrentDictionary<string, string>();
		private ConcurrentDictionary<string, string> HICtoMBILookup = new ConcurrentDictionary<string, string>();

		public void Clear()
		{
			FileCount = 0;
			TotalRecords = 0;
			BadLineCount = 0;
			BadMBICount = 0;
			BadHICCount = 0;
			MBIConflictCount = 0;
			HICConflictCount = 0;
			DuplicateCount = 0;
			HICLookupCount = 0;
			MBILookupCount = 0;
			MBItoHICLookup = new ConcurrentDictionary<string, string>();
			HICtoMBILookup = new ConcurrentDictionary<string, string>();
		}

		public bool LoadFromFolder(string FolderName, string MBIHICNFormatFile)
		{
			// Load each of the crosswalk files in timestamp order so any values are always the most recent 
			DirectoryInfo di = new DirectoryInfo(FolderName);
			foreach (FileInfo fi in di.GetFiles().OrderBy(x => x.LastWriteTime))
			{
				if (!LoadFromFile(fi.FullName, MBIHICNFormatFile))
					return false;
			}
			return true;
		}

		public bool LoadFromFile(string CrosswalkFile, string MBIHICNFormatFile)
		{
			if (string.IsNullOrEmpty(MBIHICNFormatFile))
			{
				Logger.LogString("MBI-HICN format file not specified", LogLevel.Error);
				return false;
			}
			if (File.Exists(MBIHICNFormatFile) == false)
			{
				Logger.LogString("MBI-HICN format file not found - " + MBIHICNFormatFile, LogLevel.Error);
				return false;
			}
			if (!File.Exists(CrosswalkFile))
			{
				Logger.LogString("MBI-HICN crosswalk file not found - " + CrosswalkFile, LogLevel.Error);
				return false;
			}

			// Get the configuration of the crosswalk file
			FixedFieldDescriptor MBIField = null;
			FixedFieldDescriptor HICField = null;
			DemoConfig Config = DemoConfig.ReadConfig(MBIHICNFormatFile);
			foreach (DemoColumn col in Config.Columns.Values.Where(x => x.Position.HasValue))
			{
				if (col.DataBureauFieldName.ToUpper() == "MBI")
					MBIField =  FixedFieldDescriptor.Create("MBI", col.Offset.Value, col.Length.Value);
				else if (col.DataBureauFieldName.ToUpper() == "HICNUMBER")
					HICField =  FixedFieldDescriptor.Create("HICN", col.Offset.Value, col.Length.Value);
			}

			Stream inputstream = File.OpenRead(CrosswalkFile);

			// Load the crosswalk records
			long FileRecordCount = 0;
			long FileBadLineCount = 0;
			long FileBadMBICount = 0;
			long FileBadHICCount = 0;
			long FileMBIConflictCount = 0;
			long FileHICConflictCount = 0;
			long FileDuplicateCount = 0;
			Logger.LogString("Loading MBI-HICN crosswalk data from file: " + Path.GetFileName(CrosswalkFile));
			using (IOFixedCommand crosswalkcmd = new IOFixedCommand(inputstream))
			{
				crosswalkcmd.HeaderPresent = Config.hasHeader.HasValue && Config.hasHeader.Value;
				crosswalkcmd.FooterPresent = Config.hasFooter.HasValue && Config.hasFooter.Value;
				crosswalkcmd.AddFieldDescriptor(MBIField);
				crosswalkcmd.AddFieldDescriptor(HICField);

				DataIOReader crosswalkReader = crosswalkcmd.ExecuteReader();
				FileCount++;
				long Line = 0;
				while (crosswalkReader.Read(null))
				{
					Line++;
					FileRecordCount++;
					if (!crosswalkReader.IsRowValid(Config.StrictColumnCount))
					{
						FileBadLineCount++;
						string msg = string.Format("Bad record in crosswalk - line {0}", Line);
						Errors.Add(msg);
						Logger.LogString(msg, LogLevel.Error);
					}
					else
					{
						// get fields in the order they are added to the FixedCommand
						string MBI = crosswalkReader.GetString(0).Trim();
						string HIC = crosswalkReader.GetString(1).Trim();
						if (!FieldValidator.IsFieldValid(MBI, FieldType.TMBI))
						{
							FileBadMBICount++;
							string msg = string.Format("Invalid MBI value - {0}", MBI);
							Errors.Add(msg);
							Logger.LogString(msg, LogLevel.Error);
							continue;
						}
						if (!FieldValidator.IsFieldValid(HIC, FieldType.THICNumber))
						{
							FileBadHICCount++;
							string msg = string.Format("Invalid HIC value - {0}", HIC);
							Errors.Add(msg);
							Logger.LogString(msg, LogLevel.Error);
							continue;
						}

						string val;
						if (MBItoHICLookup.TryGetValue(MBI, out val))
						{
							// crosswalk already has this MBI - warn if different HIC
							if (val != HIC)
							{
								FileHICConflictCount++;
								string msg = string.Format("Conflicting HIC values: MBI = {0}, HIC = {1} and {2}", MBI, HIC, val);
								Logger.LogString(msg, LogLevel.Warning);
							}
							else
							{
								FileDuplicateCount++;
							}
						}
						else if (HICtoMBILookup.TryGetValue(HIC, out val))
						{
							// crosswalk already has this HIC - conflict if different MBI
							if (val != MBI)
							{
								FileMBIConflictCount++;
								string msg = string.Format("Conflicting MBI values: HIC = {0}, MBI = {1} and {2}", HIC, MBI, val);
								Errors.Add(msg);
								Logger.LogString(msg, LogLevel.Error);
							}
							else
							{
								FileDuplicateCount++;
							}
						}
						else
						{
							MBItoHICLookup[MBI] = HIC;
							HICtoMBILookup[HIC] = MBI;
						}
					}
				}
			}
			// Update the counts for the overall crosswalk
			TotalRecords += FileRecordCount;
			BadLineCount += FileBadLineCount;
			BadMBICount += FileBadMBICount;
			BadHICCount += FileBadHICCount;
			MBIConflictCount += FileMBIConflictCount;
			HICConflictCount += FileHICConflictCount;
			DuplicateCount += FileDuplicateCount;
			return true;
		}

		public string MBItoHIC(string MBI)
		{
			string HIC;
			if (MBItoHICLookup.TryGetValue(MBI, out HIC))
			{
				HICLookupCount++;
				return HIC;
			}
			return string.Empty;
		}

		public string HICtoMBI(string HIC)
		{
			try
			{
				string MBI;
				if (HICtoMBILookup.TryGetValue(HIC, out MBI))
				{
					HICLookupCount++;
					return MBI;
				}
			}
			catch (Exception ex)
			{
			}
			return string.Empty;
		}
	}
}
