﻿namespace MelissaDataClient
{
    partial class addressform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private TextBox tbAddressLine1;
        private TextBox tbAddressLine2;
        private TextBox tbSuitNumber;
        private TextBox tbCity;
        private TextBox tbState;
        private TextBox tbZip;
        private TextBox tbPlus4;
        private Label lblAddressLine1;
        private Label lblAddressLine2;
        private Label lblSuitNumber;
        private Label lblCity;
        private Label lblState;
        private Label lblZip;
        private Label lblPlus4;
        private Button button1;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tbAddressLine1 = new TextBox();
            tbAddressLine2 = new TextBox();
            tbSuitNumber = new TextBox();
            tbCity = new TextBox();
            tbState = new TextBox();
            tbZip = new TextBox();
            tbPlus4 = new TextBox();
            lblAddressLine1 = new Label();
            lblAddressLine2 = new Label();
            lblSuitNumber = new Label();
            lblCity = new Label();
            lblState = new Label();
            lblZip = new Label();
            lblPlus4 = new Label();
            button1 = new Button();
            lblCountry = new Label();
            tbCountry = new TextBox();
            lblEmail = new Label();
            tbEmail = new TextBox();
            lblPhone = new Label();
            tbPhone = new TextBox();
            lblLastName = new Label();
            lblFirstName = new Label();
            tbLastName = new TextBox();
            tbFirstName = new TextBox();
            tbResult = new RichTextBox();
            tbresultcodes = new RichTextBox();
            label1 = new Label();
            button2 = new Button();
            btnMultiple = new Button();
            tbmultipleAddresses = new RichTextBox();
            SuspendLayout();
            // 
            // tbAddressLine1
            // 
            tbAddressLine1.Location = new Point(189, 60);
            tbAddressLine1.Name = "tbAddressLine1";
            tbAddressLine1.Size = new Size(150, 31);
            tbAddressLine1.TabIndex = 0;
            tbAddressLine1.Text = "3191 medicalcenter dr";
            // 
            // tbAddressLine2
            // 
            tbAddressLine2.Location = new Point(189, 125);
            tbAddressLine2.Name = "tbAddressLine2";
            tbAddressLine2.Size = new Size(150, 31);
            tbAddressLine2.TabIndex = 1;
            tbAddressLine2.Text = "Apt 47206";
            // 
            // tbSuitNumber
            // 
            tbSuitNumber.Location = new Point(189, 188);
            tbSuitNumber.Name = "tbSuitNumber";
            tbSuitNumber.Size = new Size(150, 31);
            tbSuitNumber.TabIndex = 2;
            // 
            // tbCity
            // 
            tbCity.Location = new Point(189, 244);
            tbCity.Name = "tbCity";
            tbCity.Size = new Size(150, 31);
            tbCity.TabIndex = 3;
            tbCity.Text = "McKinney";
            // 
            // tbState
            // 
            tbState.Location = new Point(568, 236);
            tbState.Name = "tbState";
            tbState.Size = new Size(150, 31);
            tbState.TabIndex = 4;
            tbState.Text = "Texas";
            // 
            // tbZip
            // 
            tbZip.Location = new Point(568, 175);
            tbZip.Name = "tbZip";
            tbZip.Size = new Size(150, 31);
            tbZip.TabIndex = 5;
            tbZip.Text = "75069";
            // 
            // tbPlus4
            // 
            tbPlus4.Location = new Point(980, 51);
            tbPlus4.Name = "tbPlus4";
            tbPlus4.Size = new Size(150, 31);
            tbPlus4.TabIndex = 6;
            // 
            // lblAddressLine1
            // 
            lblAddressLine1.AutoSize = true;
            lblAddressLine1.Location = new Point(44, 66);
            lblAddressLine1.Name = "lblAddressLine1";
            lblAddressLine1.Size = new Size(128, 25);
            lblAddressLine1.TabIndex = 7;
            lblAddressLine1.Text = "Address Line 1";
            // 
            // lblAddressLine2
            // 
            lblAddressLine2.AutoSize = true;
            lblAddressLine2.Location = new Point(44, 131);
            lblAddressLine2.Name = "lblAddressLine2";
            lblAddressLine2.Size = new Size(128, 25);
            lblAddressLine2.TabIndex = 8;
            lblAddressLine2.Text = "Address Line 2";
            // 
            // lblSuitNumber
            // 
            lblSuitNumber.AutoSize = true;
            lblSuitNumber.Location = new Point(53, 194);
            lblSuitNumber.Name = "lblSuitNumber";
            lblSuitNumber.Size = new Size(112, 25);
            lblSuitNumber.TabIndex = 9;
            lblSuitNumber.Text = "Suit Number";
            // 
            // lblCity
            // 
            lblCity.AutoSize = true;
            lblCity.Location = new Point(53, 250);
            lblCity.Name = "lblCity";
            lblCity.Size = new Size(42, 25);
            lblCity.TabIndex = 10;
            lblCity.Text = "City";
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.Location = new Point(432, 242);
            lblState.Name = "lblState";
            lblState.Size = new Size(51, 25);
            lblState.TabIndex = 11;
            lblState.Text = "State";
            // 
            // lblZip
            // 
            lblZip.AutoSize = true;
            lblZip.Location = new Point(438, 181);
            lblZip.Name = "lblZip";
            lblZip.Size = new Size(37, 25);
            lblZip.TabIndex = 12;
            lblZip.Text = "ZIP";
            // 
            // lblPlus4
            // 
            lblPlus4.AutoSize = true;
            lblPlus4.Location = new Point(844, 57);
            lblPlus4.Name = "lblPlus4";
            lblPlus4.Size = new Size(59, 25);
            lblPlus4.TabIndex = 13;
            lblPlus4.Text = "Plus 4";
            // 
            // button1
            // 
            button1.Location = new Point(115, 309);
            button1.Name = "button1";
            button1.Size = new Size(929, 62);
            button1.TabIndex = 14;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // lblCountry
            // 
            lblCountry.AutoSize = true;
            lblCountry.Location = new Point(844, 117);
            lblCountry.Name = "lblCountry";
            lblCountry.Size = new Size(75, 25);
            lblCountry.TabIndex = 15;
            lblCountry.Text = "Country";
            // 
            // tbCountry
            // 
            tbCountry.Location = new Point(980, 111);
            tbCountry.Name = "tbCountry";
            tbCountry.Size = new Size(150, 31);
            tbCountry.TabIndex = 16;
            tbCountry.Text = "United States";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(855, 182);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(54, 25);
            lblEmail.TabIndex = 17;
            lblEmail.Text = "Email";
            // 
            // tbEmail
            // 
            tbEmail.Location = new Point(980, 175);
            tbEmail.Name = "tbEmail";
            tbEmail.Size = new Size(150, 31);
            tbEmail.TabIndex = 18;
            tbEmail.Text = "nuthan.kallem@gmail.com";
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Location = new Point(851, 236);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(62, 25);
            lblPhone.TabIndex = 19;
            lblPhone.Text = "Phone";
            // 
            // tbPhone
            // 
            tbPhone.Location = new Point(980, 234);
            tbPhone.Name = "tbPhone";
            tbPhone.Size = new Size(150, 31);
            tbPhone.TabIndex = 20;
            tbPhone.Text = "8137293232";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Location = new Point(423, 117);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(95, 25);
            lblLastName.TabIndex = 24;
            lblLastName.Text = "Last Name";
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Location = new Point(423, 63);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(97, 25);
            lblFirstName.TabIndex = 23;
            lblFirstName.Text = "First Name";
            // 
            // tbLastName
            // 
            tbLastName.Location = new Point(568, 111);
            tbLastName.Name = "tbLastName";
            tbLastName.Size = new Size(150, 31);
            tbLastName.TabIndex = 22;
            tbLastName.Text = "Kallem";
            // 
            // tbFirstName
            // 
            tbFirstName.Location = new Point(568, 57);
            tbFirstName.Name = "tbFirstName";
            tbFirstName.Size = new Size(150, 31);
            tbFirstName.TabIndex = 21;
            tbFirstName.Text = "Nuthan Reddy";
            // 
            // tbResult
            // 
            tbResult.Location = new Point(53, 416);
            tbResult.Name = "tbResult";
            tbResult.Size = new Size(1090, 144);
            tbResult.TabIndex = 25;
            tbResult.Text = "";
            // 
            // tbresultcodes
            // 
            tbresultcodes.Location = new Point(53, 640);
            tbresultcodes.Name = "tbresultcodes";
            tbresultcodes.Size = new Size(1099, 83);
            tbresultcodes.TabIndex = 26;
            tbresultcodes.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 597);
            label1.Name = "label1";
            label1.Size = new Size(282, 25);
            label1.TabIndex = 27;
            label1.Text = "Result Codes recieved from Server";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlLight;
            button2.Location = new Point(1192, 8);
            button2.Name = "button2";
            button2.Size = new Size(22, 725);
            button2.TabIndex = 28;
            button2.UseVisualStyleBackColor = false;
            // 
            // btnMultiple
            // 
            btnMultiple.Location = new Point(1262, 12);
            btnMultiple.Name = "btnMultiple";
            btnMultiple.Size = new Size(377, 159);
            btnMultiple.TabIndex = 29;
            btnMultiple.Text = "Enrich Multiple Addresses";
            btnMultiple.UseVisualStyleBackColor = true;
            btnMultiple.Click += btnMultiple_Click;
            // 
            // tbmultipleAddresses
            // 
            tbmultipleAddresses.Location = new Point(1262, 194);
            tbmultipleAddresses.Name = "tbmultipleAddresses";
            tbmultipleAddresses.Size = new Size(368, 520);
            tbmultipleAddresses.TabIndex = 30;
            tbmultipleAddresses.Text = "";
            // 
            // addressform
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1663, 745);
            Controls.Add(tbmultipleAddresses);
            Controls.Add(btnMultiple);
            Controls.Add(button2);
            Controls.Add(label1);
            Controls.Add(tbresultcodes);
            Controls.Add(tbResult);
            Controls.Add(lblLastName);
            Controls.Add(lblFirstName);
            Controls.Add(tbLastName);
            Controls.Add(tbFirstName);
            Controls.Add(tbPhone);
            Controls.Add(lblPhone);
            Controls.Add(tbEmail);
            Controls.Add(lblEmail);
            Controls.Add(tbCountry);
            Controls.Add(lblCountry);
            Controls.Add(button1);
            Controls.Add(lblPlus4);
            Controls.Add(lblZip);
            Controls.Add(lblState);
            Controls.Add(lblCity);
            Controls.Add(lblSuitNumber);
            Controls.Add(lblAddressLine2);
            Controls.Add(lblAddressLine1);
            Controls.Add(tbPlus4);
            Controls.Add(tbZip);
            Controls.Add(tbState);
            Controls.Add(tbCity);
            Controls.Add(tbSuitNumber);
            Controls.Add(tbAddressLine2);
            Controls.Add(tbAddressLine1);
            Name = "addressform";
            Text = "Address Enrichment";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCountry;
        private TextBox tbCountry;
        private Label lblEmail;
        private TextBox tbEmail;
        private Label lblPhone;
        private TextBox tbPhone;
        private Label lblLastName;
        private Label lblFirstName;
        private TextBox tbLastName;
        private TextBox tbFirstName;
        private RichTextBox richTextBox1;
        private RichTextBox richTextBox2;
        private Label label1;
        private RichTextBox tbresultcodes;
        private RichTextBox tbResult;
        private Button button2;
        private Button btnMultiple;
        private RichTextBox tbmultipleAddresses;
    }
}