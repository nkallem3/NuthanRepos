﻿using MelissaDataClient.Models;
using Newtonsoft.Json;
using PersonatorService;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using static System.Windows.Forms.AxHost;

namespace MelissaDataClient.Services
{
    public class Personator
    {
        public ServicemdContactVerifySOAPClient PersonatorSoapClient { get; set; }

        public Personator()
        {
            PersonatorSoapClient = new ServicemdContactVerifySOAPClient();
        }

        public EnrichedAddressModel EnrichAddressOfContact(AddressModel addressModel)
        {

            var request = new PersonatorService.Request();
            var response = new PersonatorService.Response();

            request.CustomerID = "105553741";
            request.TransmissionReference = "CHC Personator Request";
            request.Actions = GetActions();
            request.Options = GetOptions();
            request.Columns = GetColumns();


            // Add each of the records
            RequestRecord record = new RequestRecord();
            record.RecordID = "1";
            record.FullName = addressModel.FirstName + " " + addressModel.LastName;
            record.CompanyName = "";
            record.AddressLine1 = addressModel.AddressLine1;
            record.AddressLine2 = addressModel.AddressLine2;
            record.City = addressModel.City;
            record.State = addressModel.State;
            record.PostalCode = addressModel.Zip;
            record.Country = addressModel.Country;
            record.FirstName = addressModel.FirstName;
            record.LastName = addressModel.LastName;
            record.EmailAddress = addressModel.Email;
            record.PhoneNumber = addressModel.Phone;
            request.Records = new List<RequestRecord>()
            {
                record
            }
            .ToArray();

            // Send the request
            response = PersonatorSoapClient.doContactVerifyAsync(request).Result;

            // Find the response record that corresponds with this request record
            PersonatorService.ResponseRecord responseRecord = response.Records[0];

            if (responseRecord == null)
            {
                throw new Exception("No records returned.");
            }

            
            return ParseResult(responseRecord);
        }

        public List<EnrichedAddressModel> EnrichMultipleAddressOfContact(List<AddressModel> addressModels)
        {

            var request = new PersonatorService.Request();
            var response = new PersonatorService.Response();

            request.CustomerID = "105553741";
            request.TransmissionReference = "CHC Personator Request";
            request.Actions = GetActions();
            request.Options = GetOptions();
            request.Columns = GetColumns();

            var requestRecords = new List<RequestRecord>();
            var counter = 0;
            foreach (var addressModel in addressModels)
            {
                counter++;
                // Add each of the records
                RequestRecord record = new RequestRecord();
                record.RecordID = counter.ToString();
                record.FullName = addressModel.FirstName + " " + addressModel.LastName;
                record.CompanyName = "";
                record.AddressLine1 = addressModel.AddressLine1;
                record.AddressLine2 = addressModel.AddressLine2;
                record.City = addressModel.City;
                record.State = addressModel.State;
                record.PostalCode = addressModel.Zip;
                record.Country = addressModel.Country;
                record.FirstName = addressModel.FirstName;
                record.LastName = addressModel.LastName;
                record.EmailAddress = addressModel.Email;
                record.PhoneNumber = addressModel.Phone;

                requestRecords.Add(record);
            }
            
            request.Records = requestRecords.ToArray();

            // Send the request
            response = PersonatorSoapClient.doContactVerifyAsync(request).Result;

            if (response == null)
            {
                throw new Exception("No records returned.");
            }

            return ParseResult(response);
        }

        private EnrichedAddressModel ParseResult(ResponseRecord responseRecord)
        {
            var result = new EnrichedAddressModel();

            result.AddressLine1 = responseRecord.AddressLine1;
            result.AddressLine2 = (string)responseRecord.AddressLine2;
            result.City = responseRecord.City;
            result.State = responseRecord.State;
            result.PostalCode = responseRecord.PostalCode;
            result.Plus4 = responseRecord.Plus4;
            result.AddressHouseNumber = responseRecord.AddressHouseNumber;
            result.PhoneNumber = responseRecord.PhoneNumber;
            result.PhoneCountryCode = responseRecord.PhoneCountryCode;
            result.PhoneExtension = responseRecord.PhoneExtension;

            result.AreaCode = responseRecord.AreaCode;
            result.AddressStreetName = responseRecord.AddressStreetName;
            result.AddressSuiteNumber = responseRecord.AddressSuiteNumber;

            result.CountryCode = responseRecord.CountryCode;
            result.CountryName= responseRecord.CountryName;
            result.Longitude = responseRecord.Longitude;
            result.Latitude = responseRecord.Latitude;
            result.Results = responseRecord.Results;

            return result;
        }

        private List<EnrichedAddressModel> ParseResult(Response response)
        {
            var addresses = new List<EnrichedAddressModel>();

            foreach (var responseRecord in response.Records)
            {
                var address = new EnrichedAddressModel();

                address.AddressLine1 = responseRecord.AddressLine1;
                address.AddressLine2 = (string)responseRecord.AddressLine2;
                address.City = responseRecord.City;
                address.State = responseRecord.State;
                address.PostalCode = responseRecord.PostalCode;
                address.Plus4 = responseRecord.Plus4;
                address.AddressHouseNumber = responseRecord.AddressHouseNumber;
                address.PhoneNumber = responseRecord.PhoneNumber;
                address.PhoneCountryCode = responseRecord.PhoneCountryCode;
                address.PhoneExtension = responseRecord.PhoneExtension;

                address.AreaCode = responseRecord.AreaCode;
                address.AddressStreetName = responseRecord.AddressStreetName;
                address.AddressSuiteNumber = responseRecord.AddressSuiteNumber;

                address.CountryCode = responseRecord.CountryCode;
                address.CountryName = responseRecord.CountryName;
                address.Longitude = responseRecord.Longitude;
                address.Latitude = responseRecord.Latitude;
                address.Results = responseRecord.Results;

                addresses.Add(address);
            }

            return addresses;
        }

        public string GetActions()
        {
            string actions = "";
            //if (ActionCheck)
            actions += "Check,";
            //if (ActionVerify)
            actions += "Verify,";
            //if (ActionAppend)
            actions += "Append,";
            //if (ActionMove)
            actions += "Move,";
            actions = actions.TrimEnd(',');
            return actions;
        }

        public string GetOptions()
        {
            string options = "";
            //if (UsePreferredCity)
                options += "UsePreferredCity:on;";
            //if (AdvancedAddressCorrection)
                options += "AdvancedAddressCorrection:on;";
            //switch (CentricHint)
            //{
                //case Hint.Auto: options += "CentricHint:Auto;"; break;
                options += "CentricHint:Address;";
                //case Hint.Phone: options += "CentricHint:Phone;"; break;
                //case Hint.Email: options += "CentricHint:Email;"; break;
            //}
            //switch (AppendMode)
            //{
                //case Append.CheckError: options += "Append:CheckError;"; break;
                options += "Append:Always;";
                //case Append.Blank: options += "Append:Blank;"; break;
            //}
            options = options.TrimEnd(';');
            return options;
        }

        public string GetColumns()
        {
            var result = string.Empty;
            result += "AddressLine1,";
            result += "AddressLine2,";
            result += "City,";
            result += "CompanyName,";
            result += "EmailAddress,";
            result += "PhoneNumber,";
            result += "PostalCode,";
            result += "State,";
            result += "Plus4,";
            result += "Suit,";
            result += "MelissaAddressKey,";
            //result += "MelissaAddressKeyBase,";
            //result += "RecordID,";
            result += "Results,";
            result += "MelissaIdentityKey,";
            //result += "MoveDate,";
            //result += "Occupation,";
            //result += "PhoneCountryCode,";
            //result += "PhoneCountryName,";
            result += "AddressTypeCode,";
            result += "CountryCode,";
            result += "CountryName,";
            //result += "AddressHouseNumber,";
            //result += "AddressStreetName,";
            result += "Latitude,";
            result += "Longitude,";
            //result += "AreaCode,";
            //result += "PhoneExtension,";
            result += "Gender,";
            //result += "NameFirst,";
            //result += "NameLast,";
            //result += "Salutation,";
            //result += "DateOfBirth,";
            //result += "Education,";
            //result += "EthnicGroup,";
            //result += "MaritalStatus,";

            //result = result.TrimEnd(',');

            return result;

        }
    }

    public enum Column
    {
        // Column Name                       Group
        AddressExtras,                    // Default
        AddressKey,                       // Default
        AddressLine1,                     // Default
        AddressLine2,                     // Default
        City,                             // Default
        CompanyName,                      // Default
        EmailAddress,                     // Default
        MelissaAddressKey,                // Default
        MelissaAddressKeyBase,            // Default
        NameFull,                         // Default
        PhoneNumber,                      // Default
        PostalCode,                       // Default
        RecordID,                         // Default
        Results,                          // Default
        State,                            // Default
        DateLastConfirmed,                // N/A
        EstimatedHomeValue,               // N/A
        MelissaIdentityKey,               // N/A
        MoveDate,                         // N/A
        Occupation,                       // N/A
        OwnRent,                          // N/A
        PhoneCountryCode,                 // N/A
        PhoneCountryName,                 // N/A
        Plus4,                            // N/A
        PrivateMailBox,                   // N/A
        Suite,                            // N/A
        AddressTypeCode,                  // AddressDetails
        CarrierRoute,                     // AddressDetails
        CityAbbreviation,                 // AddressDetails
        CountryCode,                      // AddressDetails
        CountryName,                      // AddressDetails
        DeliveryIndicator,                // AddressDetails
        DeliveryPointCheckDigit,          // AddressDetails
        DeliveryPointCode,                // AddressDetails
        StateName,                        // AddressDetails
        UrbanizationName,                 // AddressDetails
        UTC,                              // AddressDetails
        AddressDeliveryInstallation,      // ParsedAddress
        AddressHouseNumber,               // ParsedAddress
        AddressLockBox,                   // ParsedAddress
        AddressPostDirection,             // ParsedAddress
        AddressPreDirection,              // ParsedAddress
        AddressPrivateMailboxName,        // ParsedAddress
        AddressPrivateMailboxRange,       // ParsedAddress
        AddressRouteService,              // ParsedAddress
        AddressStreetName,                // ParsedAddress
        AddressStreetSuffix,              // ParsedAddress
        AddressSuiteName,                 // ParsedAddress
        AddressSuiteNumber,               // ParsedAddress
        Latitude,                         // Geocode
        Longitude,                        // Geocode
        AreaCode,                         // ParsedPhone
        NewAreaCode,                      // ParsedPhone
        PhoneExtension,                   // ParsedPhone
        PhonePrefix,                      // ParsedPhone
        PhoneSuffix,                      // ParsedPhone
        DomainName,                       // ParsedEmail
        MailboxName,                      // ParsedEmail
        TopLevelDomain,                   // ParsedEmail
        Gender,                           // NameDetails
        Gender2,                          // NameDetails
        NameFirst,                        // NameDetails
        NameFirst2,                       // NameDetails
        NameLast,                         // NameDetails
        NameLast2,                        // NameDetails
        NameMiddle,                       // NameDetails
        NameMiddle2,                      // NameDetails
        NamePrefix,                       // NameDetails
        NamePrefix2,                      // NameDetails
        NameSuffix,                       // NameDetails
        NameSuffix2,                      // NameDetails
        Salutation,                       // NameDetails
        CBSACode,                         // Census
        CBSADivisionCode,                 // Census
        CBSADivisionLevel,                // Census
        CBSADivisionTitle,                // Census
        CBSALevel,                        // Census
        CBSATitle,                        // Census
        CensusBlock,                      // Census
        CensusTract,                      // Census
        CongressionalDistrict,            // Census
        CountyFIPS,                       // Census
        CountyName,                       // Census
        PlaceCode,                        // Census
        PlaceName,                        // Census
        CensusKey,                        // Census2
        CountySubdivisionCode,            // Census2
        CountySubdivisionName,            // Census2
        ElementarySchoolDistrictCode,     // Census2
        ElementarySchoolDistrictName,     // Census2
        SecondarySchoolDistrictCode,      // Census2
        SecondarySchoolDistrictName,      // Census2
        StateDistrictLower,               // Census2
        StateDistrictUpper,               // Census2
        UnifiedSchoolDistrictCode,        // Census2
        UnifiedSchoolDistrictName,        // Census2
        ChildrenAgeRange,                 // DemographicBasic
        CreditCardUser,                   // DemographicBasic
        DateOfBirth,                      // DemographicBasic
        DateOfDeath,                      // DemographicBasic
        DemographicsGender,               // DemographicBasic
        DemographicsResults,              // DemographicBasic
        Education,                        // DemographicBasic
        EthnicCode,                       // DemographicBasic
        EthnicGroup,                      // DemographicBasic
        HouseholdIncome,                  // DemographicBasic
        HouseholdSize,                    // DemographicBasic
        LengthOfResidence,                // DemographicBasic
        MaritalStatus,                    // DemographicBasic
        PoliticalParty,                   // DemographicBasic
        PresenceOfChildren,               // DemographicBasic
        PresenceOfSenior,                 // DemographicBasic
        DistanceAddressToIP,              // IPAddress
        IPAddress,                        // IPAddress
        IPCity,                           // IPAddress
        IPConnectionSpeed,                // IPAddress
        IPConnectionType,                 // IPAddress
        IPContinent,                      // IPAddress
        IPCountryAbbreviation,            // IPAddress
        IPCountryName,                    // IPAddress
        IPDomainName,                     // IPAddress
        IPISPName,                        // IPAddress
        IPLatitude,                       // IPAddress
        IPLongitude,                      // IPAddress
        IPPostalCode,                     // IPAddress
        IPProxyDescription,               // IPAddress
        IPProxyType,                      // IPAddress
        IPRegion,                         // IPAddress
        IPUTC,                            // IPAddress

        AddressCodes,
        PhoneCodes,
        EmailCodes,
        NameCodes,
        OtherCodes,
        AddressType,
        GeocodeType,
        PhoneType,
        PhoneExchange,
    }

    public enum ColumnGroup
    {
        ParsedAddress,
        AddressDetails,
        GeoCode,
        ParsedPhone,
        ParsedEmail,
        NameDetails,
        Census,
        Census2,
        DemographicBasic,
        IPAddress,
    }
}
