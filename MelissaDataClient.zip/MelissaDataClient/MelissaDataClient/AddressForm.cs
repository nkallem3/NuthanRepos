﻿using MelissaDataClient.Models;
using MelissaDataClient.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MelissaDataClient
{
    public partial class addressform : Form
    {
        public Personator Personator { get; set; }
        public addressform()
        {
            InitializeComponent();
            Personator = new Personator();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var addressModel = new AddressModel();
            addressModel.AddressLine1 = tbAddressLine1.Text;
            addressModel.AddressLine2 = tbAddressLine2.Text;
            addressModel.SuitNumber = string.IsNullOrEmpty(tbSuitNumber.Text) ? 0 : Convert.ToInt32(tbSuitNumber.Text);
            addressModel.City = tbCity.Text;
            addressModel.State = tbState.Text;
            addressModel.Zip = tbZip.Text;
            addressModel.Plus4 = tbPlus4.Text;
            addressModel.Country = tbCountry.Text;

            addressModel.Email = tbEmail.Text;
            addressModel.Phone = tbPhone.Text;
            addressModel.FirstName = tbFirstName.Text;
            addressModel.LastName = tbLastName.Text;

            var response = Personator.EnrichAddressOfContact(addressModel);

            tbResult.Text = JsonConvert.SerializeObject(response);
            tbresultcodes.Text = response.Results;
        }

        private void btnMultiple_Click(object sender, EventArgs e)
        {
            string rootDir = Directory.GetCurrentDirectory();
            var fileName = "AddressFile.txt";
            var textLines = File.ReadAllLines(Path.Combine(rootDir, fileName));

            var addresses = new List<AddressModel>();
            var counter = 0;
            foreach ( var line in textLines )
            {
                counter++;
                if (counter == 1)
                {
                    continue;   // Skip header
                }

                var strings = line.Split(',');

                // Count should be 12 there may be empty strings
                if (strings.Length == 12)
                {
                    addresses.Add(new AddressModel
                    {
                        AddressLine1 = strings[0],
                        AddressLine2 = strings[1],
                        SuitNumber = string.IsNullOrEmpty(strings[2]) ? 0 : Convert.ToInt32(strings[2]),
                        City = strings[3],
                        FirstName = strings[4],
                        LastName = strings[5],
                        Zip = strings[6],
                        State = strings[7],
                        Plus4 = strings[8],
                        Country = strings[9],
                        Email = strings[10],
                        Phone = strings[11],
                    });
                }
                else
                {
                    throw new Exception("Invalid file, check address: " + line);
                }
            }

            var response = Personator.EnrichMultipleAddressOfContact(addresses);

            tbmultipleAddresses.Text = JsonConvert.SerializeObject(response);
        }
    }
}
